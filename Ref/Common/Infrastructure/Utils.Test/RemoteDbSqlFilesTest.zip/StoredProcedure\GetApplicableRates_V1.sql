CREATE PROC [dbo].[GetApplicableRates_V1] @parentPK UNIQUEIDENTIFIER
	, @tradeGroupCountry VARCHAR(2)
	, @dataGrouping VARCHAR(3)
	, @preference VARCHAR(10)
	, @additionalCodesXml XML
	, @ordernumber NVARCHAR(15)
	, @effectiveDate SMALLDATETIME
	, @rateType VARCHAR(3)
	, @rateCode VARCHAR(5)
AS

SELECT DISTINCT ZZ2_PK
	, ZZ2_ZZ1_ParentTariffOrNationalCode
	, ZZ2_ParentTableType
	, ZZ2_StartDate
	, ZZ2_EndDate
	, ZZ2_ZY1_RateCode
	, ZZ2_RateFormula
	, ZZ2_ZZS_Preference
	, ZZ2_RateFormulaDerivedFrom
	, ZZ2_ZZZ_NKDataGrouping
	, ZZ2_RX_NKCurrencyOverride
FROM RateView_V1 AS ZZ2
LEFT JOIN (SELECT C.ZZZ_DataGrouping ChildDataGrouping, P.ZZZ_DataGrouping ParentDataGrouping FROM RefDataGrouping C JOIN RefDataGrouping P ON C.ZZZ_ZZZ_Grouping = P.ZZZ_PK) B ON B.ChildDataGrouping = @dataGrouping
INNER JOIN RefCusApplicability ON ZZT_ZZ2_Rate = ZZ2_PK
INNER JOIN RefCusRateCode ON ZY1_PK = ZZ2_ZY1_RateCode
INNER JOIN RefCusRateType ON ZZR_PK = ZY1_ZZR_RateType AND ZZR_ZZZ_NKDataGrouping IN (@dataGrouping, ParentDataGrouping)
LEFT JOIN (
	SELECT ZZC_ZZT_Applicability
	FROM RefCusExcludedTradeGroup
	INNER JOIN RefCusTradeGroup ON ZZC_ZZA_TradeGroup = ZZA_PK
	INNER JOIN RefCusTradeGroupCountry ON ZZA_PK = ZZB_ZZA_TradeGroup
	WHERE ZZB_RN_NKTradeGroupCountryCode = @tradeGroupCountry
		AND ZZA_StartDate <= @effectiveDate AND @effectiveDate <= ZZA_EndDate
		AND ZZB_StartDate <= @effectiveDate AND @effectiveDate <= ZZB_EndDate
	) AS exc ON ZZT_PK = ZZC_ZZT_Applicability
LEFT JOIN RefCusTradeGroup ON ZZT_ZZA_TradeGroup = ZZA_PK
LEFT JOIN RefCusTradeGroupCountry ON ZZA_PK = ZZB_ZZA_TradeGroup
LEFT JOIN RefCusPreference ON ZZ2_ZZS_Preference = ZZS_PK
WHERE (
		ZZB_RN_NKTradeGroupCountryCode IS NULL
		OR (
			ZZB_RN_NKTradeGroupCountryCode = @tradeGroupCountry
			AND ZZA_StartDate <= @effectiveDate AND @effectiveDate <= ZZA_EndDate
			AND ZZB_StartDate <= @effectiveDate AND @effectiveDate <= ZZB_EndDate
			)
		)
	AND ZZC_ZZT_Applicability IS NULL
	AND ZZT_AdditionalCode IN (SELECT '' UNION SELECT Value = Tbl.Col.value('.', 'NVARCHAR(100)') FROM @additionalCodesXml.nodes('//v') Tbl(Col))
	AND ZZT_OrderNumber = @ordernumber
	AND ZZ2_StartDate <= @effectiveDate AND @effectiveDate <= ZZ2_EndDate
	AND ZZT_StartDate <= @effectiveDate AND @effectiveDate <= ZZT_EndDate
	AND ZZ2_ZZ1_ParentTariffOrNationalCode = @parentPK
	AND ZZ2_ZZZ_NKDataGrouping IN (@dataGrouping, ParentDataGrouping)
	AND (ZZ2_ZZS_Preference IS NULL OR ISNULL(ZZS_Preference, '') = @preference)
	AND (@rateType = '' OR ISNULL(ZZR_RateType, '') = @rateType)
	AND (@rateCode = '' OR ISNULL(ZY1_RateCode, '') = @rateCode)