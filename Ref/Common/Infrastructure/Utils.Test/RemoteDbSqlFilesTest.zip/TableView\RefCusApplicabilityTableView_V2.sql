CREATE VIEW RefCusApplicabilityTableView_V2 AS
SELECT ZZT_PK,
ZZT_ZZ2_Rate,
ZZT_ZX1_Conditions,
ZZT_ZY2_AdditionalCode,
ZZT_StartDate,
ZZT_EndDate,
ZZT_ZZA_TradeGroup,
ZZT_AdditionalCode,
ZZT_OrderNumber,
ZZT_ZZA_SecondTradeGroup
FROM RefCusApplicability
