CREATE FUNCTION GetRatesBySingleCriteriaSet_V1
(
	@parentPK UNIQUEIDENTIFIER
	, @tradeGroupCountry VARCHAR(2)
	, @dataGrouping VARCHAR(3)
	, @preference VARCHAR(10)
	, @additionalCodesXml XML
	, @ordernumber NVARCHAR(15)
	, @effectiveDate SMALLDATETIME
	, @rateType VARCHAR(3)
	, @rateCode VARCHAR(5)
)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN

SELECT DISTINCT
	rv.ZZ2_PK
	, rv.ZZ2_ZZ1_ParentTariffOrNationalCode
	, rv.ZZ2_ParentTableType
	, rv.ZZ2_StartDate
	, rv.ZZ2_EndDate
	, rv.ZZ2_ZY1_RateCode
	, rv.ZZ2_RateFormula
	, rv.ZZ2_ZZS_Preference
	, rv.ZZ2_RateFormulaDerivedFrom
	, rv.ZZ2_ZZZ_NKDataGrouping
	, rv.ZZ2_RX_NKCurrencyOverride
FROM
	dbo.RateView_V1 AS rv
	LEFT JOIN (
		SELECT
			ChildDataGrouping = cdg.ZZZ_DataGrouping,
			ParentDataGrouping = pdg.ZZZ_DataGrouping
		FROM
			dbo.RefDataGrouping AS pdg
			INNER JOIN dbo.RefDataGrouping AS cdg ON cdg.ZZZ_ZZZ_Grouping = pdg.ZZZ_PK
	) AS dg ON dg.ChildDataGrouping = @dataGrouping
	INNER JOIN dbo.RefCusApplicability AS ca ON ca.ZZT_ZZ2_Rate = rv.ZZ2_PK
	INNER JOIN dbo.RefCusRateCode AS crc ON crc.ZY1_PK = rv.ZZ2_ZY1_RateCode
	INNER JOIN dbo.RefCusRateType AS crt ON crt.ZZR_PK = crc.ZY1_ZZR_RateType AND crt.ZZR_ZZZ_NKDataGrouping IN (@dataGrouping, dg.ParentDataGrouping)
	LEFT JOIN dbo.RefCusTradeGroup AS ctg ON ctg.ZZA_PK = ca.ZZT_ZZA_TradeGroup
	LEFT JOIN dbo.RefCusTradeGroupCountry AS ctgc ON ctgc.ZZB_ZZA_TradeGroup = ctg.ZZA_PK
	LEFT JOIN dbo.RefCusPreference AS cp ON cp.ZZS_PK = rv.ZZ2_ZZS_Preference
	LEFT JOIN (
		SELECT
			ExcludedTradeGroupApplicability = cetg.ZZC_ZZT_Applicability
		FROM
			dbo.RefCusTradeGroup AS ctg2
			INNER JOIN dbo.RefCusTradeGroupCountry AS ctgc2 ON ctgc2.ZZB_ZZA_TradeGroup = ctg2.ZZA_PK
			INNER JOIN dbo.RefCusExcludedTradeGroup AS cetg ON cetg.ZZC_ZZA_TradeGroup = ctg2.ZZA_PK
		WHERE
			ctgc2.ZZB_RN_NKTradeGroupCountryCode = @tradeGroupCountry
			AND ctg2.ZZA_StartDate <= @effectiveDate AND @effectiveDate <= ctg2.ZZA_EndDate
			AND ctgc2.ZZB_StartDate <= @effectiveDate AND @effectiveDate <= ctgc2.ZZB_EndDate
	) AS exc ON exc.ExcludedTradeGroupApplicability = ca.ZZT_PK
WHERE
	(
		ctgc.ZZB_RN_NKTradeGroupCountryCode IS NULL
		OR (
			ctgc.ZZB_RN_NKTradeGroupCountryCode = @tradeGroupCountry
			AND ctg.ZZA_StartDate <= @effectiveDate AND @effectiveDate <= ctg.ZZA_EndDate
			AND ctgc.ZZB_StartDate <= @effectiveDate AND @effectiveDate <= ctgc.ZZB_EndDate
		)
	)
	AND exc.ExcludedTradeGroupApplicability IS NULL
	AND ca.ZZT_AdditionalCode IN (SELECT '' UNION SELECT Value = Tbl.Col.value('.', 'NVARCHAR(100)') FROM @additionalCodesXml.nodes('//v') Tbl(Col))
	AND ca.ZZT_OrderNumber = @ordernumber
	AND rv.ZZ2_StartDate <= @effectiveDate AND @effectiveDate <= rv.ZZ2_EndDate
	AND ca.ZZT_StartDate <= @effectiveDate AND @effectiveDate <= ca.ZZT_EndDate
	AND rv.ZZ2_ZZ1_ParentTariffOrNationalCode = @parentPK
	AND rv.ZZ2_ZZZ_NKDataGrouping IN (@dataGrouping, ParentDataGrouping)
	AND (
		rv.ZZ2_ZZS_Preference IS NULL
		OR (@preference = '' AND cp.ZZS_Preference IS NULL)
		OR cp.ZZS_Preference = @preference
	)
	AND (@rateType = '' OR crt.ZZR_RateType = @rateType)
	AND (@rateCode = '' OR crc.ZY1_RateCode = @rateCode)