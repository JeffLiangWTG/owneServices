﻿CREATE TRIGGER [dbo].[TG_RefCusCodeListAttribute_INS_UPD] ON [dbo].[RefCusCodeListAttribute]
FOR INSERT, UPDATE
AS
BEGIN
	IF UPDATE(ZZE_ZXE_NKName)
	BEGIN
		IF EXISTS 
		(
			SELECT TOP 1 1 
			FROM inserted
				LEFT JOIN RefCusCodeList ON ZZE_ZZD_CodeList = ZZD_PK
				LEFT JOIN RefCusCodeListAttributeName ON ZXE_Name = ZZE_ZXE_NKName AND ZXE_ZZZ_NKDataGrouping = ZZD_ZZZ_NKDataGrouping
			WHERE ZXE_PK IS NULL
		)
		THROW 502082019, 'A RefCusCodeListAttribute was inserted/updated with an invalid/non-existent RefCusListAttributeName', 1;
	END
END