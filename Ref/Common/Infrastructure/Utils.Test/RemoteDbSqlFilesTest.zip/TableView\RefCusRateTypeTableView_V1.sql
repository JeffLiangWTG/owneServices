CREATE VIEW RefCusRateTypeTableView_V1 AS
SELECT ZZR_PK,
ZZR_RateType,
ZZR_Description,
ZZR_IsPayable,
ZZR_ZZZ_NKDataGrouping,
ZZR_CustomsValueFormula
FROM RefCusRateType