CREATE TABLE [RefSysConfig]
(
[ZRC_PK] [UNIQUEIDENTIFIER] NOT NULL,
[ZRC_ZRT_NKConfigCode] [VARCHAR](10) NOT NULL,
[ZRC_DecimalValue] [DECIMAL](19, 8) NOT NULL CONSTRAINT DF_RefSysConfig_ZRC_DecimalValue DEFAULT (0),
[ZRC_StringValue] [NVARCHAR](4000) NOT NULL CONSTRAINT DF_RefSysConfig_ZRC_StringValue  DEFAULT (''),
[ZRC_BitValue] [BIT] NOT NULL CONSTRAINT DF_RefSysConfig_ZRC_BitValue DEFAULT (0),
[ZRC_BinaryValue] VARBINARY(MAX) NULL,
[ZRC_StartDate] [DATETIME] NOT NULL,
[ZRC_EndDate] [DATETIME] NULL,

CONSTRAINT PK_RefSysConfig PRIMARY KEY NONCLUSTERED (ZRC_PK),
CONSTRAINT Constraint_ZRC_SingleFieldValue CHECK (([ZRC_StringValue] <> '' AND [ZRC_BitValue] = (0) AND [ZRC_DecimalValue] = (0) AND [ZRC_BinaryValue] IS NULL) OR ([ZRC_BitValue] <> (0) AND [ZRC_StringValue] = '' AND [ZRC_DecimalValue] = (0) AND [ZRC_BinaryValue] IS NULL) OR ([ZRC_DecimalValue] <> (0) AND [ZRC_StringValue] = '' AND [ZRC_BitValue] = (0) AND [ZRC_BinaryValue] IS NULL) OR ([ZRC_BinaryValue] IS NOT NULL AND [ZRC_StringValue] = '' AND [ZRC_BitValue] = (0) AND [ZRC_DecimalValue] = (0))),
CONSTRAINT Constraint_ZRC_EndDate CHECK  ((ZRC_EndDate > ZRC_StartDate OR ZRC_EndDate IS NULL)),
CONSTRAINT Constraint_ZRC_StringValue CHECK  ((right(ZRC_StringValue,(1)) <> '>' AND left(ZRC_StringValue,(1)) <> '<')),
CONSTRAINT FK_RefSysConfig_RefSysConfigType FOREIGN KEY (ZRC_ZRT_NKConfigCode) REFERENCES RefSysConfigType (ZRT_ConfigCode)
)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_RefSysConfig_ZRC_ZRT_NKConfigCode] ON [RefSysConfig] ([ZRC_ZRT_NKConfigCode] ASC)
GO
