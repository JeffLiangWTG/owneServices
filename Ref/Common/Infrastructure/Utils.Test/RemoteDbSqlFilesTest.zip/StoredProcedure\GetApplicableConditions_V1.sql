CREATE PROC [dbo].[GetApplicableConditions_V1]
	@tariffPK UNIQUEIDENTIFIER,
	@preference VARCHAR(10),
	@directionFlag INT, 
	@conditionClass VARCHAR(5),
	@conditionType VARCHAR(5),
	@effectiveDate SMALLDATETIME,
	@tradeGroupCountry CHAR(2), 
	@additionalCodesXml XML,
	@orderNumber NVARCHAR(15),
	@dataGrouping NVARCHAR(3)
AS

WITH CTE_ParentDataGrouping(ParentDataGrouping) AS
(
	SELECT parent.ZZZ_DataGrouping as ParentDataGrouping
	FROM RefDataGrouping as parent 
	INNER JOIN RefDataGrouping as child ON parent.ZZZ_PK = child.ZZZ_ZZZ_Grouping
	WHERE child.ZZZ_DataGrouping = @dataGrouping
),
CTE_AdditionalCodes(Code) AS
(
	SELECT Tbl.Col.value('.', 'NVARCHAR(100)') AS Code
	FROM @additionalCodesXml.nodes('//v') Tbl(Col)
)

SELECT ZX1_PK
	,ZX1_ZX2_ConditionType
	,ZX1_ZZ1_Tariff
	,ZX1_ZZ5_Nomenclature
	,ZX1_StartDate
	,ZX1_EndDate
	,ZX1_Source
	,ZX1_Comment
	,ZX1_IsImport
	,ZX1_IsExport
	,ZX1_ConditionValueTrueMeansStop
	,ZX1_ZZS_Preference
	,ZX1_ZZZ_NKDataGrouping
	,ZX1_LogicalANDWithinGroup
FROM RefCusCondition AS ZX1
INNER JOIN RefCusConditionType ON ZX1_ZX2_ConditionType = ZX2_PK
LEFT JOIN RefCusPreference on ZX1_ZZS_Preference = ZZS_PK
LEFT JOIN CTE_ParentDataGrouping on ZX1_ZZZ_NKDataGrouping = ParentDataGrouping
LEFT JOIN 
(
	SELECT ZZT_ZX1_Conditions FROM RefCusApplicability
	JOIN RefCusCondition ON ZX1_PK = ZZT_ZX1_Conditions
	LEFT JOIN RefCusTradeGroup AS includeTradeGroup ON ZZT_ZZA_TradeGroup = includeTradeGroup.ZZA_PK
	LEFT JOIN RefCusTradeGroupCountry AS includeTradeGroupCountries ON includeTradeGroup.ZZA_PK = includeTradeGroupCountries.ZZB_ZZA_TradeGroup
	LEFT JOIN (
		SELECT ZZC_ZZT_Applicability
		FROM RefCusExcludedTradeGroup
		INNER JOIN RefCusTradeGroup ON ZZC_ZZA_TradeGroup = ZZA_PK
		INNER JOIN RefCusTradeGroupCountry ON ZZA_PK = ZZB_ZZA_TradeGroup
		WHERE ZZB_RN_NKTradeGroupCountryCode = @tradeGroupCountry
			AND ZZA_StartDate <= @effectiveDate
			AND @effectiveDate <= ZZA_EndDate
			AND ZZB_StartDate <= @effectiveDate
			AND @effectiveDate <= ZZB_EndDate
		) AS exc ON ZZT_PK = ZZC_ZZT_Applicability
	WHERE 
		(
			ZZB_RN_NKTradeGroupCountryCode = @tradeGroupCountry
			AND ZZA_StartDate <= @effectiveDate AND @effectiveDate <= ZZA_EndDate
			AND ZZB_StartDate <= @effectiveDate AND @effectiveDate <= ZZB_EndDate
			AND ZZC_ZZT_Applicability IS NULL
			AND (ZZT_AdditionalCode = '' OR ZZT_AdditionalCode IN (SELECT Code FROM CTE_AdditionalCodes))
			AND ((ZX1_ZZS_Preference IS NULL AND ZZT_OrderNumber = '') OR ZZT_OrderNumber = @ordernumber)
			AND ZZT_StartDate <= @effectiveDate AND @effectiveDate <= ZZT_EndDate
		)
	GROUP BY ZZT_ZX1_Conditions
) AS apps ON apps.ZZT_ZX1_Conditions = ZX1_PK
LEFT JOIN 
(
	SELECT ZZT_ZX1_Conditions FROM RefCusApplicability
	GROUP BY ZZT_ZX1_Conditions
) AS allApps ON allApps.ZZT_ZX1_Conditions = ZX1_PK
WHERE
	(@conditionClass = '' OR ZX2_ConditionClass = @conditionClass)
	AND (@conditionType ='' OR ZX2_ConditionType = @conditionType)
	AND ZX1_StartDate <= @effectiveDate AND @effectiveDate <= ZX1_EndDate
	AND (@directionFlag = 0
		OR (@directionFlag = 1 AND ZX1_IsImport = 1)
		OR (@directionFlag = 2 AND ZX1_IsExport = 1))
	AND ((ZX1_ZZ1_Tariff = @tariffPK AND (ZZS_Preference IS NULL OR ZZS_Preference = @preference))
		OR (ZX1_ZZ1_Tariff IS NULL AND ZX1_ZZ5_Nomenclature IS NULL AND ZZS_Preference = @preference))
	AND (ZX1_ZZZ_NKDataGrouping = @dataGrouping OR ParentDataGrouping IS NOT NULL)
	AND (apps.ZZT_ZX1_Conditions IS NOT NULL OR allApps.ZZT_ZX1_Conditions IS NULL)