CREATE VIEW RefCusCodeListAttributeNameTableView_V1 AS
SELECT ZXE_PK,
ZXE_Name,
ZXE_Description,
ZXE_ZZK_NKCodeType,
ZXE_ZZZ_NKDataGrouping,
ZXE_IsMandatory,
ZXE_AllowDuplicates,
ZXE_IsValueMandatory,
ZXE_ZZK_NKCodeTypeForValueList,
ZXE_ValueDataType,
ZXE_MinLengthOrValue,
ZXE_MaxLengthOrValue,
ZXE_DecimalPlaces,
ZXE_ColumnCaption
FROM RefCusCodeListAttributeName