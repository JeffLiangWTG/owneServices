﻿CREATE PROC [dbo].[GetApplicableRatesWithoutDataGrouping_V1] @parentPK UNIQUEIDENTIFIER
	, @tradeGroupCountry CHAR(2)
	, @preference VARCHAR(10)
	, @additionalCode NVARCHAR(15)
	, @ordernumber NVARCHAR(15)
	, @effectiveDate SMALLDATETIME
AS
SELECT ZZ2_PK
	, ZZ2_ZZ1_ParentTariffOrNationalCode
	, ZZ2_ParentTableType
	, ZZ2_StartDate
	, ZZ2_EndDate
	, ZZ2_ZY1_RateCode
	, ZZ2_RateFormula
	, ZZ2_ZZS_Preference
	, ZZ2_RateFormulaDerivedFrom
	, ZZ2_ZZZ_NKDataGrouping
	, ZZ2_RX_NKCurrencyOverride
FROM RateView_V1 AS ZZ2
INNER JOIN RefCusApplicability ON ZZT_ZZ2_Rate = ZZ2_PK
LEFT JOIN (
	SELECT ZZC_ZZT_Applicability
	FROM RefCusExcludedTradeGroup
	INNER JOIN RefCusTradeGroup ON ZZC_ZZA_TradeGroup = ZZA_PK
	INNER JOIN RefCusTradeGroupCountry ON ZZA_PK = ZZB_ZZA_TradeGroup
	WHERE ZZB_RN_NKTradeGroupCountryCode = @tradeGroupCountry
		AND ZZA_StartDate <= @effectiveDate AND @effectiveDate <= ZZA_EndDate
		AND ZZB_StartDate <= @effectiveDate AND @effectiveDate <= ZZB_EndDate
	) AS exc ON ZZT_PK = ZZC_ZZT_Applicability
LEFT JOIN RefCusTradeGroup ON ZZT_ZZA_TradeGroup = ZZA_PK
LEFT JOIN RefCusTradeGroupCountry ON ZZA_PK = ZZB_ZZA_TradeGroup
LEFT JOIN RefCusPreference ON ZZ2_ZZS_Preference = ZZS_PK
WHERE (
		ZZB_RN_NKTradeGroupCountryCode IS NULL
		OR (
			ZZB_RN_NKTradeGroupCountryCode = @tradeGroupCountry
			AND ZZA_StartDate <= @effectiveDate AND @effectiveDate <= ZZA_EndDate
			AND ZZB_StartDate <= @effectiveDate AND @effectiveDate <= ZZB_EndDate
			)
		)
	AND ZZC_ZZT_Applicability IS NULL
	AND ZZT_AdditionalCode = @additionalCode
	AND ZZT_OrderNumber = @ordernumber
	AND ZZ2_StartDate <= @effectiveDate AND @effectiveDate <= ZZ2_EndDate
	AND ZZT_StartDate <= @effectiveDate AND @effectiveDate <= ZZT_EndDate
	AND ZZ2_ZZ1_ParentTariffOrNationalCode = @parentPK
	AND (
		@preference = ''
		OR ISNULL(ZZS_Preference, '') = @preference
		)