CREATE VIEW RefCusConditionLanguageTableView_V1 AS
SELECT ZXJ_PK,
ZXJ_ZX6_NKLanguage,
ZXJ_Comment,
ZXJ_Source,
ZXJ_ZX1_Condition
FROM RefCusConditionLanguage