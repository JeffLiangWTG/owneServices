# Agenda

Having many hosted services across the WiseCloud we need a mechanism that allows a service to use the other one without knowing its exact location.
Consumer service needs to know the location (host name, IP address, port) of every service it communicates with.
If we do not employ a Service Discovery mechanism, service locations become coupled, leading to a repetition of codes, maintenance difficulties, and strong coupling of the components, where the change of one can break everything.

We need a service discovery pattern to be taken onboard, and CargoWise Cloud Discovery Service (CCDS) is an implementation of it.

# How it works

Service Discovery is a tactics helping consumer to reveal where the exact service instance is located.
The instances are dynamically assigned or registered in the Service Discovery provider.

![DiscoveryServiceInAction](docs/images/DiscoveryServiceInAction.png)

(external picture is used, thus the floating terminology)

1. The location of the Service Provider is sent to the Service Registry.
1. The Service Consumer asks the Service Registry for the location of the Service Provider.
1. The location of the Service Provider is returned to the Service Consumer in ready to use way.
1. The Service Consumer can now make direct requests to the Service Provider.

## Registration options
1. Self registration\
![DiscoveryServiceInAction](docs/images/SelfRegistration.png)\
Service Provider instance is responsible for registering and unregistering itself in the Service Registry and sends heartbeat requests to keep its registration alive.

1. Discovery registration\
![DiscoveryServiceInAction](docs/images/DiscoveryRegistration.png)\
The Service Register itself is responsible for registration of Service Providers. The Service Register keeps track of changes to running instances by polling the deployment environment or subscribing to events. The Service Registry also unregisters terminated Service Provider instances.

## Endpoints
- [/wtg/ready](docs/Ready.md)
- [/wtg/status](docs/Status.md) 
