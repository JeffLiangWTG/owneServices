using NUnit.Framework;

namespace TestFramework
{
	public static class Paths
	{
		public static string SourcePath => GetPathFromEnvironmentVariableOrSourcePath();

		static string GetPathFromEnvironmentVariableOrSourcePath()
		{
			var sourcePath = Environment.GetEnvironmentVariable("NUnit3TestSourcePath");
			if (!string.IsNullOrEmpty(sourcePath))
			{
				return sourcePath;
			}

			sourcePath = Environment.GetEnvironmentVariable("DAT_TestSourcePath");
			if (!string.IsNullOrEmpty(sourcePath))
			{
				return sourcePath;
			}

			sourcePath = TestContext.CurrentContext.TestDirectory;
			while (!File.Exists(Path.Combine(sourcePath!, BuildXmlFileName)) && sourcePath != Path.GetPathRoot(sourcePath))
			{
				sourcePath = Path.GetDirectoryName(sourcePath);
			}

			return sourcePath!;
		}

		const string BuildXmlFileName = "Build.xml";
	}
}
