using Dat.Integration;
using Deployment.Implementation;
using Deployment.Interfaces;
using Moq;
using NUnit.Framework;

namespace Deployment.Test
{
	[TestFixture]
	class SiteControllerTest
	{
		[SetUp]
		public void SetUp()
		{
			taskLoggerMock = new Mock<ITaskLogger>();
			fileSystemAdapterMock = new Mock<IFileSystemAdapter>();
			deploymentConfigurationMock = new Mock<IDeploymentConfiguration>();
			siteController = new SiteController(taskLoggerMock.Object, fileSystemAdapterMock.Object);
		}

		Mock<ITaskLogger> taskLoggerMock;
		Mock<IDeploymentConfiguration> deploymentConfigurationMock;
		Mock<IFileSystemAdapter> fileSystemAdapterMock;
		SiteController siteController;

		static readonly IEnumerable<TestCaseData> Source = new[]
		{
			new TestCaseData("sydco-wmgv-1", "SharedBuild", "user1"),
			new TestCaseData("sydsp-sweb-2.sand.wtg.zone", "TmsAdmin", "tlmadmin"),
			new TestCaseData("sydco-sweb-1.wtg.zone", "tmsadmin.wtg.zone", "s_tmsadmin"),
			new TestCaseData("sydsp-sweb-3.sand.wtg.zone", "tmsadmin-test.sand.wtg.zone", "s_tmsadmin"),
		};

		[TestCaseSource(nameof(Source))]
		public void StartSite(string remoteHost, string siteName, string userName)
		{
			// Arrange
			var password = DateTime.Now.ToLongTimeString();
			var remotePath = $@"\\{remoteHost}\{siteName}";
			var uri = new Uri(remotePath);
			deploymentConfigurationMock.SetupGet(configuration => configuration.Uri).Returns(uri);
			deploymentConfigurationMock.SetupGet(configuration => configuration.MachineName).Returns(remoteHost);
			deploymentConfigurationMock.SetupGet(configuration => configuration.UserName).Returns(userName);
			deploymentConfigurationMock.SetupGet(configuration => configuration.RemotePath).Returns(remotePath);
			deploymentConfigurationMock.Setup(configuration => configuration.DecryptPassword()).Returns(password);

			// Act
			siteController.StartSite(deploymentConfigurationMock.Object);

			// Assert
			fileSystemAdapterMock.Verify(utils => utils.DeleteFile("app_offline.htm", deploymentConfigurationMock.Object), Times.Once);
		}

		[TestCaseSource(nameof(Source))]
		public void StopSite(string remoteHost, string siteName, string userName)
		{
			// Arrange
			var password = DateTime.Now.ToLongTimeString();
			var remotePath = $@"\\{remoteHost}\{siteName}";
			var uri = new Uri(remotePath);
			deploymentConfigurationMock.SetupGet(configuration => configuration.Uri).Returns(uri);
			deploymentConfigurationMock.SetupGet(configuration => configuration.MachineName).Returns(remoteHost);
			deploymentConfigurationMock.SetupGet(configuration => configuration.UserName).Returns(userName);
			deploymentConfigurationMock.SetupGet(configuration => configuration.BinPath).Returns("u:\\f1");
			deploymentConfigurationMock.SetupGet(configuration => configuration.RemotePath).Returns(remotePath);
			deploymentConfigurationMock.Setup(configuration => configuration.DecryptPassword()).Returns(password);

			// Act
			siteController.StopSite(deploymentConfigurationMock.Object);

			// Assert
			fileSystemAdapterMock.Verify(utils => utils.CopyFileOverNetwork("u:\\f1\\Deployment\\app_offline.htm", deploymentConfigurationMock.Object), Times.Once);
		}

		[Test]
		public void WrongConstructorParamsCall()
		{
			// Arrange
			// Act
			// Assert
			Assert.That(() => new SiteController(null, fileSystemAdapterMock.Object), Throws.ArgumentNullException.With.Message.Contains("taskLogger"));
			Assert.That(() => new SiteController(taskLoggerMock.Object, null), Throws.ArgumentNullException.With.Message.Contains("fileSystemAdapter"));
		}

		[Test]
		public void WrongParamsCallStartSite()
		{
			// Arrange
			// Act
			// Assert
			Assert.That(() => siteController.StartSite(null), Throws.ArgumentNullException.With.Message.Contains("configuration"));
		}

		[Test]
		public void WrongParamsCallStopSite()
		{
			// Arrange
			// Act
			// Assert
			Assert.That(() => siteController.StopSite(null), Throws.ArgumentNullException.With.Message.Contains("configuration"));
		}
	}
}
