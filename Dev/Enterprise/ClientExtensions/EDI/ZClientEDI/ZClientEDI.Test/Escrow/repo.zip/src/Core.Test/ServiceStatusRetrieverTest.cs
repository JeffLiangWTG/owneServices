using System.Diagnostics.CodeAnalysis;
using Interfaces.Core;
using NUnit.Framework;

namespace Core.Test
{
	[TestFixture]
	public class ServiceStatusRetrieverTest
	{
		[SetUp]
		public void SetUp()
		{
			builder = new ServiceStatusRetriever();
		}

		[Test]
		public void BuildServiceStatus()
		{
			// Arrange
			var expectedStatus = new[]
			{
				new ServiceStatusRecord(ServiceStatusRecordType.Ccds, ServiceStatusRecordState.Info, null),
			};

			// Act
			var status = builder!.Retrieve();

			// Assert
			Assert.That(status, Is.EqualTo(expectedStatus).Using(new ServiceStatusRecordEqualityComparer()));
		}

		ServiceStatusRetriever? builder;

		record ServiceStatusRecord(
				ServiceStatusRecordType Type,
				ServiceStatusRecordState State,
				string? Message)
			: IServiceStatusRecord;

		class ServiceStatusRecordEqualityComparer : IEqualityComparer<IServiceStatusRecord>
		{
			public bool Equals(IServiceStatusRecord? x, IServiceStatusRecord? y)
			{
				return x!.State == y!.State
					&& x.Message == y.Message
					&& x.Type == y.Type;
			}

			public int GetHashCode([DisallowNull] IServiceStatusRecord obj)
			{
				throw new NotImplementedException();
			}
		}
	}
}
