using Dat.Integration;
using Deployment.Interfaces;
using WTG.DeploymentUtils.FileSystem;
using WTG.DeploymentUtils.NetworkShare;

namespace Deployment.Implementation
{
	class FileSystemAdapter : IFileSystemAdapter
	{
		public FileSystemAdapter(ITaskLogger logger, INetworkShareAccessor networkShareAccessor, IFileSystemUtils fileSystemUtils)
		{
			this.networkShareAccessor = networkShareAccessor ?? throw new ArgumentNullException(nameof(networkShareAccessor));
			this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
			this.fileSystemUtils = fileSystemUtils ?? throw new ArgumentNullException(nameof(fileSystemUtils));
		}

		public void CopyFileOverNetwork(string fileName, IDeploymentConfiguration configuration)
		{
			logger.RecordInfo("Copying file...");
			using (networkShareAccessor.NetworkShare(configuration.MachineName, configuration.UserName, configuration.DecryptPassword(), false))
			{
				var remotePath = Path.Combine(configuration.RemotePath, Path.GetFileName(fileName));
				logger.RecordInfo(FormattableString.Invariant($"Copying file [{fileName}] to {remotePath}"));
				fileSystemUtils.Copy(fileName, remotePath, true, logger);
			}
		}

		public void CopyDirectoryOverNetwork(IDeploymentConfiguration configuration)
		{
			logger.RecordInfo("Copying directory...");
			using (networkShareAccessor.NetworkShare(configuration.MachineName, configuration.UserName, configuration.DecryptPassword(), false))
			{
				logger.RecordInfo(FormattableString.Invariant($"Copying source [{configuration.PublishPath}] to {configuration.RemotePath}"));
				fileSystemUtils.Copy(configuration.PublishPath, configuration.RemotePath, logger);
			}
		}

		public void DeleteFilesInDirectory(IDeploymentConfiguration configuration)
		{
			logger.RecordInfo(FormattableString.Invariant($"Deleting files in [{configuration.RemotePath}]..."));
			using (networkShareAccessor.NetworkShare(configuration.MachineName, configuration.UserName, configuration.DecryptPassword(), false))
			{
				var directoryInfo = new DirectoryInfo(configuration.RemotePath);
				foreach (var file in directoryInfo.EnumerateFiles()
							.Where(file => !Path.GetFileName(file.Name).Equals(SiteController.AppOfflineFileName, StringComparison.OrdinalIgnoreCase)))
				{
					file.Delete();
				}

				foreach (var directory in directoryInfo.EnumerateDirectories())
				{
					foreach (var file in directory.EnumerateFiles())
					{
						file.Delete();
					}
					directory.Delete();
				}
			}
		}

		public void DeleteFile(string fileName, IDeploymentConfiguration configuration)
		{
			logger.RecordInfo(FormattableString.Invariant($"Deleting file [{fileName}] in [{configuration.RemotePath}]..."));
			using (networkShareAccessor.NetworkShare(configuration.MachineName, configuration.UserName, configuration.DecryptPassword(), false))
			{
				File.Delete($"{configuration.RemotePath}\\{fileName}");
			}
		}

		readonly IFileSystemUtils fileSystemUtils;
		readonly ITaskLogger logger;
		readonly INetworkShareAccessor networkShareAccessor;
	}
}
