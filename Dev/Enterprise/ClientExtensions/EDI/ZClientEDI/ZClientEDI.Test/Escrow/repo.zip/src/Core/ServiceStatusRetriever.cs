using Interfaces.Core;

namespace Core
{
	public class ServiceStatusRetriever : IServiceStatusRetriever
	{
		public IEnumerable<IServiceStatusRecord> Retrieve()
		{
			return new[]
			{
				new ServiceStatusRecord(ServiceStatusRecordType.Ccds, ServiceStatusRecordState.Info, null),
			};
		}

		record ServiceStatusRecord(
				ServiceStatusRecordType Type,
				ServiceStatusRecordState State,
				string? Message)
			: IServiceStatusRecord;
	}
}
