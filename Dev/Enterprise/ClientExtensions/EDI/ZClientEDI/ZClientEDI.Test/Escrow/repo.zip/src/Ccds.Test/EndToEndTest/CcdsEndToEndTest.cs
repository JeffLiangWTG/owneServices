using System.Collections.Concurrent;
using System.Diagnostics;
using NUnit.Framework;

namespace Ccds.Test.EndToEndTest
{
	[TestFixture]
	class CcdsEndToEndTest
	{
		[TestCaseSource(nameof(WorkingPaths))]
		[Property("DAT:RequiresAdminPrivileges", 1)]
		public void StartProgramFromDifferenPlaceWithoutError(string workingPath)
		{
			// Arrange
			Process? process = null;
			var outputMessageBag = new ConcurrentBag<string>();

			try
			{
				// Act
				process = StartCcds(outputMessageBag, workingPath);

				// Assert
				var errorMessage = outputMessageBag.Where(x => x.StartsWith("Error", StringComparison.OrdinalIgnoreCase));
				var exceptionMessage = outputMessageBag.Where(x => x.Contains("Exception", StringComparison.OrdinalIgnoreCase));

				Assert.That(outputMessageBag, Is.Not.Empty);
				Assert.That(errorMessage, Is.Empty);
				Assert.That(exceptionMessage, Is.Empty);
			}
			finally
			{
				process?.Kill();
			}
		}

		[Test]
		public void StartListeningToTargetPort()
		{
			// Arrange
			const string hostName = "localhost";
			const int port = 5000;

			var pokeStartInfo = new ProcessStartInfo()
			{
				RedirectStandardError = true,
				RedirectStandardOutput = true,
				FileName = "powershell.exe",
				UseShellExecute = false,
				Arguments = $"Test-NetConnection {hostName} -port {port}",
			};

			Process? ccdsProcess = null;
			Process? pokeProcess = null;
			var pokeOutputMessage = new ConcurrentBag<string>();

			try
			{
				ccdsProcess = StartCcds(new ConcurrentBag<string>(), Environment.CurrentDirectory);

				// Act
				pokeProcess = StartNewProcess(pokeStartInfo, pokeOutputMessage);

				// Assert
				Assert.That(pokeProcess.WaitForExit(TimeSpan.FromSeconds(10)), Is.True);
				Assert.That(pokeOutputMessage, Has.One.EqualTo("TcpTestSucceeded : True"));
			}
			finally
			{
				if (!pokeProcess?.HasExited ?? false)
				{
					pokeProcess?.Kill();
				}

				ccdsProcess?.Kill();
			}
		}

		static IEnumerable<string> WorkingPaths
		{
			get
			{
				yield return "C:\\";
				yield return "C:\\Users";
			}
		}

		static Process StartNewProcess(ProcessStartInfo processStartInfo, ConcurrentBag<string> outputMessageBag)
		{
			var messages = new ConcurrentBag<string>();
			var process = Process.Start(processStartInfo);
			process!.OutputDataReceived += (s, e) => outputMessageBag.Add(e!.Data ?? string.Empty);
			process!.ErrorDataReceived += (s, e) => outputMessageBag.Add(e!.Data ?? string.Empty);
			process!.BeginOutputReadLine();
			process!.BeginErrorReadLine();

			Thread.Sleep(TimeSpan.FromSeconds(5));
			return process;
		}

		static Process StartCcds(ConcurrentBag<string> outputMessageBag, string workingDirectory)
		{
			var startInfo = new ProcessStartInfo()
			{
				RedirectStandardError = true,
				RedirectStandardOutput = true,
				FileName = Path.Combine(Environment.CurrentDirectory, "Ccds.exe"),
				UseShellExecute = false,
				CreateNoWindow = true,
				WorkingDirectory = workingDirectory,
			};

			return StartNewProcess(startInfo, outputMessageBag);
		}
	}
}
