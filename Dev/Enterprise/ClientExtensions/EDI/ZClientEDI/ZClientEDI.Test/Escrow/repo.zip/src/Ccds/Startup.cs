using System.Diagnostics.CodeAnalysis;
using Ccds.Controllers;
using Microsoft.AspNetCore.Authentication.Negotiate;

namespace Ccds
{
	[SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "CA1506:Avoid excessive class coupling", Justification = "WebService Ctor")]
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		public void ConfigureServices(IServiceCollection services)
		{
			services.AddSingleton(_ => Configuration);
			services
				.AddControllers()
				.AddApplicationPart(typeof(StatusController).Assembly);

			// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
			services.AddEndpointsApiExplorer();
			services.AddSwaggerGen();

			services
				.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
				.AddNegotiate();

			services.AddAuthorization(options =>
			{
				options.FallbackPolicy = options.DefaultPolicy;
			});

			services.RegisterInterfaceImplementations();
		}

		public void SetupServiceProvider(IHostBuilder host)
		{
			host.UseDefaultServiceProvider(options =>
			 {
				 options.ValidateOnBuild = true;
				 options.ValidateScopes = true;
			 });
		}

		public static void Configure(IApplicationBuilder application, IWebHostEnvironment environment)
		{
			if (environment.IsDevelopment() || environment.IsStaging())
			{
				application.UseSwagger();
				application.UseSwaggerUI();
			}

			application.UseAuthentication();
			application.UseRouting();
			application.UseAuthorization();
			application.UseEndpoints(endpoints =>
			{
				endpoints.MapControllers();
			});
		}
	}
}
