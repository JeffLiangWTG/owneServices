using System.Reflection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using NUnit.Framework;

namespace Ccds.Test
{
	[TestFixture]
	public class AssemblyTests
	{
		[Test]
		public void AllControllersRequireAuthorization()
		{
			// Arrange
			new Startup(Mock.Of<IConfiguration>())
				.ConfigureServices(Mock.Of<IServiceCollection>());

			var controllers = AppDomain.CurrentDomain.GetAssemblies()
				.SelectMany(assembly => assembly.GetTypes())
				.Where(type => typeof(ControllerBase).IsAssignableFrom(type))
				.Where(type => type != typeof(ControllerBase))
				.ToList();

			// Act
			var result = controllers
				.Where(controller => controller.GetCustomAttribute<AuthorizeAttribute>(true) == null);

			// Assert
			Assert.That(controllers, Is.Not.Empty);
			Assert.That(result, Is.Empty);
		}
	}
}
