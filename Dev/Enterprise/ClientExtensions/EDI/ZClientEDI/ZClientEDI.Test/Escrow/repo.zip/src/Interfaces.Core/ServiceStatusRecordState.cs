namespace Interfaces.Core
{
	public enum ServiceStatusRecordState
	{
		Info,
		Warning,
		Error,
	}
}
