using System.Globalization;
using System.Net;
using System.Reflection;
using System.Text.Json;
using Deployment.Interfaces;
using WTG.DeploymentUtils.SecureStore;

namespace Deployment.Implementation
{
	public sealed class CcdsDeploymentConfiguration : IDeploymentConfiguration
	{
		CcdsDeploymentConfiguration(ISecureStore secureStore)
		{
			this.secureStore = secureStore ?? throw new ArgumentNullException(nameof(secureStore));
		}

		public static IDeploymentConfiguration FromConfigurationString(string deploymentConfiguration, string sourcePath, string binPath, ISecureStore secureStore)
		{
			_ = deploymentConfiguration ?? throw new ArgumentNullException(nameof(deploymentConfiguration));
			_ = binPath ?? throw new ArgumentNullException(nameof(binPath));
			_ = sourcePath ?? throw new ArgumentNullException(nameof(sourcePath));
			_ = secureStore ?? throw new ArgumentNullException(nameof(secureStore));

			var configFileName = Path.Combine(Path.GetDirectoryName(Assembly.GetCallingAssembly().Location), "DeploymentConfigs", $"deployment.{deploymentConfiguration}.json");
			var parsedConfig = JsonSerializer.Deserialize<DeploymentConfigFile>(File.ReadAllText(configFileName));
			var uri = new Uri(parsedConfig!.Uri);

			return new CcdsDeploymentConfiguration(secureStore)
			{
				Uri = uri,
				UserName = parsedConfig.UserName,
				EncryptedPassword = parsedConfig.EncryptedPassword,
				BinPath = binPath,
				SourcePath = Path.Combine(sourcePath, "src"),
				MachineName = string.Format(CultureInfo.InvariantCulture, "\\\\{0}", (uri.IsUnc ? uri.Host : Dns.GetHostName()).ToUpperInvariant()),
				RemotePath = uri.OriginalString,
				ConfigurationName = deploymentConfiguration,
				Environment = parsedConfig.Environment,
			};
		}

		public string? EncryptedPassword { get; private set; }
		public string? UserName { get; private set; }
		public Uri? Uri { get; private set; }
		public string? SourcePath { get; private set; }
		public string? BinPath { get; private set; }
		public string? MachineName { get; private set; }
		public string? RemotePath { get; private set; }
		public string? ConfigurationName { get; private set; }
		public string? Environment { get; private set; }
		public string? PublishPath => Path.Combine(BinPath, "Publish");

		public string DecryptPassword()
		{
			return secureStore.Decrypt(EncryptedPassword);
		}

		readonly ISecureStore secureStore;
	}

	class DeploymentConfigFile
	{
		public string? Uri { get; set; }
		public string? UserName { get; set; }
		public string? EncryptedPassword { get; set; }
		public string? Environment { get; set; }
	}
}
