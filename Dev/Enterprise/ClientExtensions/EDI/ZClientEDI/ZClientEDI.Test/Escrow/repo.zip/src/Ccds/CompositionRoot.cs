using Core;
using Interfaces.Core;

namespace Ccds
{
	public static class CompositionRoot
	{
		public static void RegisterInterfaceImplementations(this IServiceCollection services)
		{
			services
				.AddTransient<IServiceStatusRetriever, ServiceStatusRetriever>();
		}
	}
}
