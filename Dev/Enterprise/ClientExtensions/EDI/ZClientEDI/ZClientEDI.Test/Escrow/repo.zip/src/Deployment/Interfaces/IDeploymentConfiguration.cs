namespace Deployment.Interfaces
{
	public interface IDeploymentConfiguration
	{
		string? EncryptedPassword { get; }
		string? UserName { get; }
		Uri? Uri { get; }
		string? SourcePath { get; }
		string? BinPath { get; }
		string? MachineName { get; }
		string? RemotePath { get; }
		string? ConfigurationName { get; }
		string? Environment { get; }
		string? PublishPath { get; }
		string? DecryptPassword();
	}
}
