using System.Reflection;
using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;

namespace Ccds.Test
{
	[TestFixture]
	public abstract class IntegrationTestBase<TCcdsStartUp> : IDisposable
		where TCcdsStartUp : class
	{
		[SetUp]
		public virtual void SetUp()
		{
			TestClientFactory = new TestClientFactory<TCcdsStartUp>();
		}

		public void Dispose()
		{
			TestClientFactory?.Dispose();
		}

		protected void DisableAuthentication()
		{
			var authenticationScheme = new AuthenticationScheme("Test", "Test", typeof(MockAuthenticationHandler));
			var mockProvider = new Mock<IAuthenticationSchemeProvider>();
			mockProvider
				.Setup(provider => provider.GetSchemeAsync(It.IsAny<string>()))
				.ReturnsAsync(authenticationScheme);
			mockProvider
				.Setup(provider => provider.GetDefaultAuthenticateSchemeAsync())
				.ReturnsAsync(authenticationScheme);
			TestClientFactory!.ServiceMocks.AddMock(typeof(IAuthenticationSchemeProvider), mockProvider);
		}

		class MockAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
		{
			public MockAuthenticationHandler(
				IOptionsMonitor<AuthenticationSchemeOptions> options,
				ILoggerFactory logger,
				UrlEncoder encoder,
				ISystemClock clock)
				: base(options, logger, encoder, clock)
			{
			}

			protected override Task<AuthenticateResult> HandleAuthenticateAsync()
			{
				var claims = Array.Empty<Claim>();
				var identity = new ClaimsIdentity(claims, "Test");
				var principal = new ClaimsPrincipal(identity);
				var ticket = new AuthenticationTicket(principal, "Test");

				return Task.FromResult(AuthenticateResult.Success(ticket));
			}
		}

		protected TestClientFactory<TCcdsStartUp>? TestClientFactory { get; private set; }
	}

	public class TestClientFactory<TStartup> : IDisposable
		where TStartup : class
	{
		public TestClientFactory()
		{
			ServiceMocks = new ServiceMocks();
			webApplicationFactory = new CcdsWebApplicationFactory<TStartup>(ServiceMocks);
		}

		public void Dispose()
		{
			webApplicationFactory.Dispose();
		}

		public HttpClient GetClient() => webApplicationFactory.CreateClient();

		public ServiceMocks ServiceMocks { get; }

		readonly CcdsWebApplicationFactory<TStartup> webApplicationFactory;

		class CcdsWebApplicationFactory<T> : WebApplicationFactory<T>
			where T : class
		{
			public CcdsWebApplicationFactory(ServiceMocks serviceMocks)
			{
				this.serviceMocks = serviceMocks;
			}

			protected override IHost CreateHost(IHostBuilder builder)
			{
				_ = builder ?? throw new ArgumentNullException(nameof(builder));
				builder.ConfigureHostConfiguration(configuration =>
				{
					configuration.Sources.Clear();
					var testAssemblyLocation = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)!;
					configuration.AddJsonFile(Path.Combine(testAssemblyLocation, "appsettings.IntegrationTesting.json"));
				});
				return base.CreateHost(builder);
			}

			protected override IHostBuilder CreateHostBuilder()
			{
				return Host.CreateDefaultBuilder()
					.ConfigureWebHostDefaults(webBuilder =>
					{
						webBuilder
							.UseStartup<T>()
							.UseTestServer()
							.UseDefaultServiceProvider(options =>
							{
								options.ValidateOnBuild = true;
								options.ValidateScopes = true;
							});
					});
			}

			protected override void ConfigureWebHost(IWebHostBuilder builder)
			{
				_ = builder ?? throw new ArgumentNullException(nameof(builder));
				builder.UseEnvironment("IntegrationTesting");
				base.ConfigureWebHost(builder);

				_ = builder.ConfigureServices(services =>
				{
					services
						.AddMvc()
						.AddApplicationPart(typeof(T).Assembly);
					foreach (var (interfaceType, serviceMock) in serviceMocks.Mocks)
					{
						services.Remove(services.Single(d => d.ServiceType == interfaceType));
						services.AddSingleton(interfaceType, serviceMock);
					}
				});
			}

			readonly ServiceMocks serviceMocks;
		}
	}

	public class ServiceMocks
	{
		public ServiceMocks()
		{
			mocks = new Dictionary<Type, object>();
		}

		public void AddMock(Type type, Mock mock)
		{
			_ = mock ?? throw new ArgumentNullException(nameof(mock));
			mocks.Add(type, mock.Object);
		}

		public IReadOnlyDictionary<Type, object> Mocks => mocks;
		readonly Dictionary<Type, object> mocks;
	}
}
