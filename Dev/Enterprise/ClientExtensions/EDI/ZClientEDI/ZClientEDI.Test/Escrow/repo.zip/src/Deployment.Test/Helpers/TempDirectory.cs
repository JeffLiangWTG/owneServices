using System.Globalization;

namespace Deployment.Test.Helpers
{
	sealed class TempDirectory : IDisposable
	{
		public static TempDirectory Create()
		{
			return new TempDirectory();
		}

		TempDirectory()
		{
			TempDirectoryPath = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("D", CultureInfo.InvariantCulture));
			Directory.CreateDirectory(TempDirectoryPath);
		}

		public void Dispose()
		{
			Directory.Delete(TempDirectoryPath, true);
		}

		public string TempDirectoryPath { get; }
	}
}
