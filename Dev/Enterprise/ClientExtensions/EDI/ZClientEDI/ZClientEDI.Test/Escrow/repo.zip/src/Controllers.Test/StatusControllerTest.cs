using System.Net;
using Ccds.Controllers;
using Interfaces.Core;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;

namespace Ccds.Test.ControllerTest
{
	[TestFixture]
	public class StatusControllerTest
	{
		[SetUp]
		public void SetUp()
		{
			serviceStatusBuilderMock = new Mock<IServiceStatusRetriever>();
			controller = new StatusController(serviceStatusBuilderMock.Object);
		}

		static IEnumerable<TestCaseData> GetSource()
		{
			yield return new TestCaseData(
				new[]
				{
					new ServiceStatusRecord(ServiceStatusRecordType.Ccds, ServiceStatusRecordState.Info, null),
				},
				"INFO(Ccds): OK");
			yield return new TestCaseData(
				new[]
				{
					new ServiceStatusRecord(ServiceStatusRecordType.Ccds, ServiceStatusRecordState.Warning, "Some warning message"),
				},
				"WARNING(Ccds): [Some warning message]");
			yield return new TestCaseData(
				new[]
				{
					new ServiceStatusRecord(ServiceStatusRecordType.Ccds, ServiceStatusRecordState.Error, "Some error message"),
				},
				"ERROR(Ccds): [Some error message]");
		}

		[TestCaseSource(nameof(GetSource))]
		public void Get(IEnumerable<ServiceStatusRecord> serviceStatusRecords, string expectedStatusMessage)
		{
			// Arrange
			serviceStatusBuilderMock!
				.Setup(builder => builder.Retrieve())
				.Returns(serviceStatusRecords);

			// Act
			var result = controller!.Get();

			// Assert
			Assert.That(result, Is.TypeOf<OkObjectResult>());
			Assert.That(result.Value, Is.EqualTo(expectedStatusMessage));
		}

		Mock<IServiceStatusRetriever>? serviceStatusBuilderMock;
		StatusController? controller;

		[TestFixture]
		[System.Diagnostics.CodeAnalysis.SuppressMessage("Usage", "CA2234:Pass system uri objects instead of strings", Justification = "Test")]
		class StatusIntegrationTest : IntegrationTestBase<Startup>
		{
			[SetUp]
			public override void SetUp()
			{
				base.SetUp();
				DisableAuthentication();
			}

			[TestCaseSource(nameof(SupportedRequestHeaders))]
			public void ResponseUsesHttp11(HttpMethod httpMethod)
			{
				// Arrange
				var client = TestClientFactory!.GetClient();
				using var requestMessage = new HttpRequestMessage(httpMethod, "/wtg/status");

				// Act
				var result = client.SendAsync(requestMessage).Result;

				// Assert
				Assert.That(result.Version, Is.EqualTo(HttpVersion.Version11));
			}

			[TestCaseSource(nameof(SupportedRequestHeaders))]
			public void ResponseIsNotCached(HttpMethod httpMethod)
			{
				// Arrange
				var client = TestClientFactory!.GetClient();
				using var requestMessage = new HttpRequestMessage(httpMethod, "/wtg/status");

				// Act
				var result = client.SendAsync(requestMessage).Result;

				// Assert
				Assert.That(result.Headers.CacheControl!.NoCache, Is.EqualTo(true));
				Assert.That(result.Headers.CacheControl!.NoStore, Is.EqualTo(true));
			}

			static IEnumerable<TestCaseData> SupportedRequestHeaders()
			{
				yield return new TestCaseData(HttpMethod.Get);
				yield return new TestCaseData(HttpMethod.Head);
			}
		}
	}

	public record ServiceStatusRecord(
			ServiceStatusRecordType Type,
			ServiceStatusRecordState State,
			string? Message)
		: IServiceStatusRecord;
}
