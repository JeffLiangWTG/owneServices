using System.Globalization;
using System.Net;
using Deployment.Implementation;
using Moq;
using NUnit.Framework;
using WTG.DeploymentUtils.SecureStore;

namespace Deployment.Test
{
	[TestFixture]
	class CcdsDeploymentConfigurationTest
	{
		[SetUp]
		public void SetUp()
		{
			secureStoreMock = new Mock<ISecureStore>(MockBehavior.Strict);
		}

		Mock<ISecureStore> secureStoreMock;

		static IEnumerable<TestCaseData> DeploymentConfigSource()
		{
			yield return new TestCaseData("test1", "\\\\wherefore\\art\\thou", "Romeo", "qwerty", "\\\\WHEREFORE").SetName("{M} test1");
			yield return new TestCaseData("test2", "C:\\pagefile.sys", "Juliet", "dvorak", @"\\" + Dns.GetHostName().ToUpper(CultureInfo.InvariantCulture)).SetName("{M} test2");
		}

		[TestCaseSource(nameof(DeploymentConfigSource))]
		public void FromConfigurationString(string testName, string uriInFile, string userNameInFile, string encryptedPassword, string expectedMachineName)
		{
			// Arrange
			var expectedUri = new Uri(uriInFile);
			var decryptedPassword = "decryptedPassword";
			secureStoreMock.Setup(store => store.Decrypt(It.IsAny<string>())).Returns(decryptedPassword);

			// Act
			var configuration = CcdsDeploymentConfiguration.FromConfigurationString(testName, "sourcePath", "binPath", secureStoreMock.Object);

			// Assert
			Assert.That(configuration, Is.Not.Null);
			Assert.That(configuration.Uri, Is.EqualTo(expectedUri));
			Assert.That(configuration.RemotePath, Is.EqualTo(uriInFile));
			Assert.That(configuration.BinPath, Is.EqualTo("binPath").IgnoreCase);
			Assert.That(configuration.SourcePath, Is.EqualTo("sourcePath\\src"));
			Assert.That(configuration.UserName, Is.EqualTo(userNameInFile));
			Assert.That(configuration.EncryptedPassword, Is.EqualTo(encryptedPassword));
			Assert.That(configuration.ConfigurationName, Is.EqualTo(testName));
			Assert.That(configuration.DecryptPassword(), Is.EqualTo(decryptedPassword));
			Assert.That(configuration.MachineName, Is.EqualTo(expectedMachineName));
		}

		[Test]
		public void WrongParamCalls()
		{
			// Arrange
			// Act
			// Assert
			Assert.That(() => CcdsDeploymentConfiguration.FromConfigurationString(null, "c:", "d:", secureStoreMock.Object), Throws.ArgumentNullException.With.Message.Contains("deploymentConfiguration"));
			Assert.That(() => CcdsDeploymentConfiguration.FromConfigurationString("SandAu2A", null, "d:", secureStoreMock.Object), Throws.ArgumentNullException.With.Message.Contains("sourcePath"));
			Assert.That(() => CcdsDeploymentConfiguration.FromConfigurationString("SandAu2A", "c:", null, secureStoreMock.Object), Throws.ArgumentNullException.With.Message.Contains("binPath"));
			Assert.That(() => CcdsDeploymentConfiguration.FromConfigurationString("SandAu2A", "c:", "d:", null), Throws.ArgumentNullException.With.Message.Contains("secureStore"));
		}
	}
}
