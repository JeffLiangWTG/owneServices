namespace Deployment.Interfaces
{
	public interface IFileSystemAdapter
	{
		void CopyFileOverNetwork(string fileName, IDeploymentConfiguration configuration);
		void CopyDirectoryOverNetwork(IDeploymentConfiguration configuration);
		void DeleteFilesInDirectory(IDeploymentConfiguration configuration);
		void DeleteFile(string fileName, IDeploymentConfiguration configuration);
	}
}
