namespace Interfaces.Core
{
	public interface IServiceStatusRecord
	{
		ServiceStatusRecordType Type { get; }
		ServiceStatusRecordState State { get; }
		string? Message { get; }
	}
}
