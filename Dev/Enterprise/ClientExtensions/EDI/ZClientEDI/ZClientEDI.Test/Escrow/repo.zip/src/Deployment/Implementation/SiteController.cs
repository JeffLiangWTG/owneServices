using Dat.Integration;
using Deployment.Interfaces;

namespace Deployment.Implementation
{
	public class SiteController : ISiteController
	{
		public SiteController(
			ITaskLogger taskLogger,
			IFileSystemAdapter fileSystemAdapter)
		{
			this.taskLogger = taskLogger ?? throw new ArgumentNullException(nameof(taskLogger));
			this.fileSystemAdapter = fileSystemAdapter ?? throw new ArgumentNullException(nameof(fileSystemAdapter));
		}

		public void StopSite(IDeploymentConfiguration configuration)
		{
			_ = configuration ?? throw new ArgumentNullException(nameof(configuration));

			var host = configuration.Uri!.Host;
			var siteName = Path.GetFileName(configuration.Uri.AbsolutePath);
			using (taskLogger.RecordTask($"Stopping site [{siteName}] on [{host}]"))
			{
				fileSystemAdapter.CopyFileOverNetwork(
					Path.Combine(configuration.BinPath, "Deployment", AppOfflineFileName),
					configuration);
			}
			Thread.Sleep(TimeSpan.FromSeconds(10)); // Wait for IIS to pickup the App_offline file
		}

		public void StartSite(IDeploymentConfiguration configuration)
		{
			_ = configuration ?? throw new ArgumentNullException(nameof(configuration));

			var host = configuration.Uri!.Host;
			var siteName = Path.GetFileName(configuration.Uri.AbsolutePath);
			using (taskLogger.RecordTask($"Starting site [{siteName}] on [{host}]"))
			{
				fileSystemAdapter.DeleteFile(AppOfflineFileName, configuration);
			}
		}

		public const string AppOfflineFileName = "app_offline.htm";
		readonly ITaskLogger taskLogger;
		readonly IFileSystemAdapter fileSystemAdapter;
	}
}
