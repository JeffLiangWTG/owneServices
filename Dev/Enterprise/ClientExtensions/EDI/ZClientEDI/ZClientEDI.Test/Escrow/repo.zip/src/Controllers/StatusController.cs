using System.Globalization;
using Interfaces.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ccds.Controllers
{
	[ApiController]
	[Authorize]
	[Route("wtg")]
	[ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]
	public class StatusController : ControllerBase
	{
		public StatusController(IServiceStatusRetriever serviceStatusRetriever)
		{
			this.serviceStatusRetriever = serviceStatusRetriever ?? throw new ArgumentNullException(nameof(serviceStatusRetriever));
		}

		[HttpGet]
		[HttpHead]
		[Route("status")]
		public ObjectResult Get()
		{
			var status = serviceStatusRetriever.Retrieve();
			var formattedStatus = status.Select(FormatRepositoryCount);
			var result = string.Join(Environment.NewLine, formattedStatus);
			return new OkObjectResult(result);
		}

		static string FormatRepositoryCount(IServiceStatusRecord record)
		{
			return record.State switch
			{
				ServiceStatusRecordState.Info => FormattableString.Invariant($"{Enum.GetName(record.State)?.ToUpper(CultureInfo.InvariantCulture):G}({record.Type:G}): {record.Message ?? "OK"}"),
				_ => FormattableString.Invariant($"{Enum.GetName(record.State)?.ToUpper(CultureInfo.InvariantCulture):G}({record.Type:G}): [{record.Message}]"),
			};
		}

		readonly IServiceStatusRetriever serviceStatusRetriever;
	}
}
