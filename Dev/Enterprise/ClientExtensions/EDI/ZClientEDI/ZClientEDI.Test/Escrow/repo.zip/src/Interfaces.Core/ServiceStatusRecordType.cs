namespace Interfaces.Core
{
	public enum ServiceStatusRecordType
	{
		Ccds,
	}
}
