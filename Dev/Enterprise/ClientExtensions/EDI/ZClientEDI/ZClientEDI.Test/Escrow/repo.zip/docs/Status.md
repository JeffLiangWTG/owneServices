## /wtg/status
Endpoint used to indicate various status information of the web service. Primarily used to indicate system health for SCOM monitoring \
Format of the endpoint follows [SCOM guidelines](https://wisetechglobal.sharepoint.com/:w:/r/Development/Development%20Team%20Workspace/_layouts/15/Doc.aspx?sourcedoc=%7B4D08400C-B08E-4E5B-86FD-9DD057EEE1F2%7D&file=WiseTech%20Global%20Web%20Monitoring.docx&action=default&mobileredirect=true&cid=0053824e-ebb4-41a2-89c0-1026727b7adb) \
Example formats: 
```
INFO(Ccds): OK
```
```
WARNING(Ccds): Some warning message
```
```
ERROR(Ccds): Some error message
```