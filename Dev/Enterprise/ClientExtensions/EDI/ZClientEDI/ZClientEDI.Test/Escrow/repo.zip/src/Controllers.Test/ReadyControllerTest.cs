using Ccds.Controllers;
using Microsoft.AspNetCore.Mvc;
using NUnit.Framework;

namespace Ccds.Test.ControllerTest
{
	[TestFixture]
	public class ReadyControllerTest
	{
		[SetUp]
		public void SetUp()
		{
			controller = new ReadyController();
		}

		[Test]
		public void Get()
		{
			// Arrange
			// Act
			var result = controller!.Get();

			// Assert
			Assert.That(result, Is.TypeOf<OkResult>());
		}

		ReadyController? controller;
	}
}
