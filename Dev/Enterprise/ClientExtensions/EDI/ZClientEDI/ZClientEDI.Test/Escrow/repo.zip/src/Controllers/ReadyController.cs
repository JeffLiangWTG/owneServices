using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Ccds.Controllers
{
	[ApiController]
	[Authorize]
	[Route("wtg")]
	public class ReadyController : ControllerBase
	{
		[HttpGet]
		[HttpHead]
		[Route("ready")]
		public OkResult Get()
		{
			return Ok();
		}
	}
}
