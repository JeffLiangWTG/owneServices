namespace Ccds
{
	public static class Program
	{
		[System.Diagnostics.CodeAnalysis.SuppressMessage("Reliability", "CA2000:Dispose objects before losing scope", Justification = "Main Entry")]
		public static void Main(string[] args)
		{
			CreateHostBuilder(args)
				.Run();
		}

		public static WebApplication CreateHostBuilder(string[] args)
		{
			var builder = WebApplication.CreateBuilder(args);
			var startup = new Startup(builder.Configuration);

			startup.ConfigureServices(builder.Services);
			startup.SetupServiceProvider(builder.Host);

			var application = builder.Build();

			Startup.Configure(application, application.Environment);

			return application;
		}
	}
}
