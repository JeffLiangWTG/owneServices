using System;
using Dat.Integration;
using Deployment.Interfaces;
using Moq;
using NUnit.Framework;
using WTG.DeploymentUtils.Builder;
using WTG.DeploymentUtils.SecureStore;

namespace Deployment.Test
{
	[TestFixture]
	public class BuildDeployerTest
	{
		[SetUp]
		public void SetUp()
		{
			loggerMock = new Mock<ITaskLogger>();
			fileSystemAdapterMock = new Mock<IFileSystemAdapter>();
			secureStoreMock = new Mock<ISecureStore>();
			siteControllerMock = new Mock<ISiteController>();
			configurationMock = new Mock<IDeploymentConfiguration>();
			publishBuilderMock = new Mock<IPublishBuilder>();
			buildDeployer = new BuildDeployer(loggerMock.Object, secureStoreMock.Object, fileSystemAdapterMock.Object, siteControllerMock.Object, publishBuilderMock.Object);
		}

		Mock<ISiteController> siteControllerMock;
		Mock<ITaskLogger> loggerMock;
		Mock<IFileSystemAdapter> fileSystemAdapterMock;
		Mock<ISecureStore> secureStoreMock;
		Mock<IDeploymentConfiguration> configurationMock;
		Mock<IPublishBuilder> publishBuilderMock;
		BuildDeployer buildDeployer;

		[Test]
		public void DeployFiles()
		{
			// Arrange
			var sourcePath = "src";
			var binPath = "bin";
			var deploymentPath = "deployment";
			var configurationName = "Test";
			var environment = "Testing";
			configurationMock.Setup(c => c.Uri).Returns(new Uri(@"\\sydco-wmgv-1\SharedBuild"));
			configurationMock.Setup(c => c.UserName).Returns("user");
			configurationMock.Setup(c => c.SourcePath).Returns(sourcePath);
			configurationMock.Setup(c => c.BinPath).Returns(binPath);
			configurationMock.Setup(c => c.PublishPath).Returns(deploymentPath);
			configurationMock.Setup(c => c.ConfigurationName).Returns(configurationName);
			configurationMock.Setup(c => c.Environment).Returns(environment);
			var sequence = new MockSequence();
			publishBuilderMock
				.InSequence(sequence)
				.Setup(builder => builder.Build(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>(), It.IsAny<string[]>()));
			siteControllerMock
				.InSequence(sequence)
				.Setup(controller => controller.StopSite(It.IsAny<IDeploymentConfiguration>()));
			fileSystemAdapterMock
				.InSequence(sequence)
				.Setup(adapter => adapter.DeleteFilesInDirectory(configurationMock.Object));
			fileSystemAdapterMock
				.InSequence(sequence)
				.Setup(adapter => adapter.CopyDirectoryOverNetwork(configurationMock.Object));
			siteControllerMock
				.InSequence(sequence)
				.Setup(controller => controller.StartSite(It.IsAny<IDeploymentConfiguration>()));

			// Act
			buildDeployer.Deploy(configurationMock.Object);

			// Assert
			publishBuilderMock.Verify(builder => builder.Build(sourcePath, "win10-x64", "Release", deploymentPath, binPath, environment, false, "Ccds"));
			fileSystemAdapterMock.Verify(adapter => adapter.DeleteFilesInDirectory(configurationMock.Object), Times.Once);
			fileSystemAdapterMock.Verify(adapter => adapter.CopyDirectoryOverNetwork(configurationMock.Object), Times.Once);
			siteControllerMock.Verify(controller => controller.StopSite(configurationMock.Object), Times.Once);
			siteControllerMock.Verify(controller => controller.StartSite(configurationMock.Object), Times.Once);
		}

		[Test]
		public void DeploymentFailureLeavesSiteOffline()
		{
			// Arrange
			var exception = new InvalidOperationException("oh no!");
			var sourcePath = "src";
			var binPath = "bin";
			var deploymentPath = "deployment";
			var configurationName = "Test";
			var environment = "Testing";
			configurationMock.Setup(c => c.Uri).Returns(new Uri(@"\\sydco-wmgv-1\SharedBuild"));
			configurationMock.Setup(c => c.UserName).Returns("user");
			configurationMock.Setup(c => c.SourcePath).Returns(sourcePath);
			configurationMock.Setup(c => c.BinPath).Returns(binPath);
			configurationMock.Setup(c => c.PublishPath).Returns(deploymentPath);
			configurationMock.Setup(c => c.ConfigurationName).Returns(configurationName);
			configurationMock.Setup(c => c.Environment).Returns(environment);
			var sequence = new MockSequence();
			publishBuilderMock
				.InSequence(sequence)
				.Setup(builder => builder.Build(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>(), It.IsAny<string[]>()));
			siteControllerMock
				.InSequence(sequence)
				.Setup(controller => controller.StopSite(It.IsAny<IDeploymentConfiguration>()));
			fileSystemAdapterMock
				.InSequence(sequence)
				.Setup(adapter => adapter.DeleteFilesInDirectory(configurationMock.Object))
				.Throws(exception);
			fileSystemAdapterMock
				.InSequence(sequence)
				.Setup(adapter => adapter.CopyDirectoryOverNetwork(configurationMock.Object));
			siteControllerMock
				.InSequence(sequence)
				.Setup(controller => controller.StartSite(It.IsAny<IDeploymentConfiguration>()));

			// Act
			Assert.That(() => buildDeployer.Deploy(configurationMock.Object), Throws.Exception.EqualTo(exception));

			// Assert
			publishBuilderMock.Verify(builder => builder.Build(sourcePath, "win10-x64", "Release", deploymentPath, binPath, environment, false, "Ccds"));
			fileSystemAdapterMock.Verify(adapter => adapter.DeleteFilesInDirectory(configurationMock.Object), Times.Once);
			fileSystemAdapterMock.Verify(adapter => adapter.CopyDirectoryOverNetwork(configurationMock.Object), Times.Never);
			siteControllerMock.Verify(controller => controller.StopSite(configurationMock.Object), Times.Once);
			siteControllerMock.Verify(controller => controller.StartSite(configurationMock.Object), Times.Never);
		}
	}
}
