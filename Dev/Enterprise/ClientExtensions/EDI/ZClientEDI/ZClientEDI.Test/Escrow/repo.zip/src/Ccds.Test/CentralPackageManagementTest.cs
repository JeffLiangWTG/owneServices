using NUnit.Framework;
using TestFramework;

namespace Ccds.Test
{
	[TestFixture]
	public class CentralPackageManagementTest
	{
		[Test]
		public void HasDirectoryPackagesProps()
		{
			// Arrange

			// Act
			var result = File.Exists(filePath);

			// Assert
			Assert.That(result, Is.True, () => filePath);
		}

		[Test]
		public void EnablesCentralPackageManagement()
		{
			// Arrange
			var content = File
				.ReadAllText(filePath)
				.Replace(" ", string.Empty, StringComparison.OrdinalIgnoreCase)
				.ReplaceLineEndings(string.Empty);

			// Act
			var result = content
				.Contains("<PropertyGroup><ManagePackageVersionsCentrally>true</ManagePackageVersionsCentrally></PropertyGroup>", StringComparison.OrdinalIgnoreCase);

			// Assert
			Assert.That(result, Is.True);
		}

		readonly string filePath = Path.Combine(Paths.SourcePath, "src", "Directory.Packages.props");
	}
}
