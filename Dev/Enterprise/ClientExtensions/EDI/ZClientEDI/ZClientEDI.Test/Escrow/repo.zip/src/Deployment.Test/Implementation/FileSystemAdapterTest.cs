using System.Globalization;
using Dat.Integration;
using Deployment.Implementation;
using Deployment.Interfaces;
using Deployment.Test.Helpers;
using Moq;
using NUnit.Framework;
using WTG.DeploymentUtils.FileSystem;
using WTG.DeploymentUtils.NetworkShare;

namespace Deployment.Test.Implementation
{
	[TestFixture]
	class FileSystemAdapterTest
	{
		[SetUp]
		public void SetUp()
		{
			loggerMock = new Mock<ITaskLogger>();
			networkShareAccessorMock = new Mock<INetworkShareAccessor>();
			deploymentConfigurationMock = new Mock<IDeploymentConfiguration>();
			disposableMock = new Mock<IDisposable>();
			networkShareAccessorMock
				.Setup(accessor => accessor.NetworkShare(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()))
				.Returns(disposableMock.Object);
			fileSystemAdapter = new FileSystemAdapter(loggerMock.Object, networkShareAccessorMock.Object, new FileSystemUtils());
		}

		Mock<ITaskLogger> loggerMock;
		Mock<INetworkShareAccessor> networkShareAccessorMock;
		Mock<IDeploymentConfiguration> deploymentConfigurationMock;
		Mock<IDisposable> disposableMock;
		FileSystemAdapter fileSystemAdapter;

		[Test]
		public void CopyFileOverNetwork()
		{
			// Arrange
			using var sourceTempDir = TempDirectory.Create();
			using var destTempDir = TempDirectory.Create();
			deploymentConfigurationMock
				.SetupGet(config => config.RemotePath)
				.Returns(destTempDir.TempDirectoryPath);
			var file = File.Create(Path.Combine(sourceTempDir.TempDirectoryPath, "someFile"));
			file.WriteByte((byte)1);
			file.Close();

			// Act
			fileSystemAdapter.CopyFileOverNetwork(file.Name, deploymentConfigurationMock.Object);

			// Assert
			Assert.That(
				Path.GetFileName(Directory.EnumerateFiles(destTempDir.TempDirectoryPath, "*", SearchOption.AllDirectories).Single()),
				Is.EqualTo("someFile"));
			Assert.That(
				Directory.EnumerateDirectories(sourceTempDir.TempDirectoryPath, "*", SearchOption.AllDirectories),
				Is.Empty);
		}

		[Test]
		public void CopyDirectoryOverNetwork()
		{
			// Arrange
			using var sourceTempDir = TempDirectory.Create();
			using var destTempDir = TempDirectory.Create();
			deploymentConfigurationMock
				.SetupGet(config => config.RemotePath)
				.Returns(destTempDir.TempDirectoryPath);
			deploymentConfigurationMock
				.SetupGet(config => config.PublishPath)
				.Returns(sourceTempDir.TempDirectoryPath);
			var innerSourceDirectory = Directory.CreateDirectory(Path.Combine(sourceTempDir.TempDirectoryPath, "someDirectory"));
			var file = File.Create(Path.Combine(innerSourceDirectory.FullName, "someFile1"));
			file.Close();
			var file2 = File.Create(Path.Combine(sourceTempDir.TempDirectoryPath, "someFile2"));
			file2.Close();

			// Act
			fileSystemAdapter.CopyDirectoryOverNetwork(deploymentConfigurationMock.Object);

			// Assert
			Assert.That(
				Directory.EnumerateFiles(destTempDir.TempDirectoryPath, "*", SearchOption.AllDirectories)
					.Select(file => Path.GetFileName(file))
					.OrderBy(n => n),
				Is.EqualTo(new[] { "someFile1", "someFile2" }));
			Assert.That(
				Directory.EnumerateDirectories(sourceTempDir.TempDirectoryPath, "*", SearchOption.AllDirectories)
					.Select(path => new DirectoryInfo(path).Name),
				Is.EqualTo(new[] { "someDirectory" }));
		}

		[TestCase(1, 1)]
		[TestCase(3, 3)]
		public void DeleteFilesInDirectory(int files, int directories)
		{
			// Arrange
			using var tempDir = TempDirectory.Create();
			deploymentConfigurationMock
				.SetupGet(config => config.RemotePath)
				.Returns(tempDir.TempDirectoryPath);
			for (var i = 0; i < directories; i++)
			{
				var directory = Directory.CreateDirectory(Path.Combine(tempDir.TempDirectoryPath, i.ToString(CultureInfo.InvariantCulture)));
				for (var j = 0; j < files; j++)
				{
					var file = File.Create(Path.Combine(directory.FullName, j.ToString(CultureInfo.InvariantCulture)));
					file.WriteByte((byte)j);
					file.Close();
				}
			}

			// Act
			fileSystemAdapter.DeleteFilesInDirectory(deploymentConfigurationMock.Object);

			// Assert
			Assert.That(
				Directory.EnumerateFiles(tempDir.TempDirectoryPath, "*", SearchOption.AllDirectories),
				Is.Empty);
			Assert.That(
				Directory.EnumerateDirectories(tempDir.TempDirectoryPath, "*", SearchOption.AllDirectories),
				Is.Empty);
		}

		[TestCase("app_offline.htm")]
		[TestCase("App_offlinE.htm")]
		[TestCase("APP_OFFLINE.htm")]
		public void DeleteFilesInDirectoryIgnoresAppOffline(string appOffline)
		{
			// Arrange
			using var tempDir = TempDirectory.Create();
			deploymentConfigurationMock
				.SetupGet(config => config.RemotePath)
				.Returns(tempDir.TempDirectoryPath);
			var directory = Directory.CreateDirectory(Path.Combine(tempDir.TempDirectoryPath, "directory1"));
			var file1 = File.Create(Path.Combine(tempDir.TempDirectoryPath, appOffline));
			var file2 = File.Create(Path.Combine(tempDir.TempDirectoryPath, "file2"));
			var file3 = File.Create(Path.Combine(directory.FullName, "file3"));
			file1.Close();
			file2.Close();
			file3.Close();

			// Act
			fileSystemAdapter.DeleteFilesInDirectory(deploymentConfigurationMock.Object);

			// Assert
			Assert.That(
				Directory.EnumerateFiles(tempDir.TempDirectoryPath, "*", SearchOption.AllDirectories).Select(file => Path.GetFileName(file)),
				Is.EqualTo(new[] { appOffline }));
		}

		[TestCase("SomeName")]
		public void DeleteFile(string fileName)
		{
			// Arrange
			using var tempDir = TempDirectory.Create();
			deploymentConfigurationMock
				.SetupGet(config => config.RemotePath)
				.Returns(tempDir.TempDirectoryPath);
			var file = File.Create(Path.Combine(tempDir.TempDirectoryPath, fileName));
			file.WriteByte((byte)1);
			file.Close();

			// Act
			fileSystemAdapter.DeleteFile(fileName, deploymentConfigurationMock.Object);

			// Assert
			Assert.That(
				Directory.EnumerateFiles(tempDir.TempDirectoryPath, "*", SearchOption.AllDirectories),
				Is.Empty);
			Assert.That(
				Directory.EnumerateDirectories(tempDir.TempDirectoryPath, "*", SearchOption.AllDirectories),
				Is.Empty);
		}
	}
}
