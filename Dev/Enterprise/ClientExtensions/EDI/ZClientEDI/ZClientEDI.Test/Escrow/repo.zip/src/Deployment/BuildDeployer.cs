using System.ComponentModel;
using System.Reflection;
using Dat.Integration;
using Dat.Integration.Deployment;
using Deployment.Implementation;
using Deployment.Interfaces;
using WTG.DeploymentUtils.Builder;
using WTG.DeploymentUtils.CommandInvocation;
using WTG.DeploymentUtils.FileSystem;
using WTG.DeploymentUtils.NetworkShare;
using WTG.DeploymentUtils.SecureStore;

namespace Deployment
{
	public class BuildDeployer : IBuildDeployer
	{
		public BuildDeployer(ITaskLogger logger)
			: this(
				logger,
				new SecureStore(),
				new FileSystemAdapter(
					logger,
					new NetworkShareAccessor(),
					new FileSystemUtils()))
		{
		}

		BuildDeployer(
			ITaskLogger logger,
			ISecureStore secureStore,
			IFileSystemAdapter fileSystemAdapter)
			: this(
				logger,
				secureStore,
				fileSystemAdapter,
				new SiteController(logger, fileSystemAdapter),
				new DotnetPublishBuilder(logger, new LocalCommandInvoker(), new FileSystemUtils()))
		{
		}

		internal BuildDeployer(
			ITaskLogger logger,
			ISecureStore secureStore,
			IFileSystemAdapter fileSystemAdapter,
			ISiteController siteController,
			IPublishBuilder publishBuilder)
		{
			this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
			this.secureStore = secureStore ?? throw new ArgumentNullException(nameof(secureStore));
			this.fileSystemAdapter = fileSystemAdapter ?? throw new ArgumentNullException(nameof(fileSystemAdapter));
			this.siteController = siteController ?? throw new ArgumentNullException(nameof(siteController));
			this.publishBuilder = publishBuilder ?? throw new ArgumentNullException(nameof(publishBuilder));
		}

		internal void Deploy(IDeploymentConfiguration configuration)
		{
			_ = configuration ?? throw new ArgumentNullException(nameof(configuration));

			logger.RecordInfo($"Deploying to [{configuration.Uri!.LocalPath}] with configuration [{configuration.ConfigurationName}]");

			publishBuilder.Build(configuration.SourcePath, "win10-x64", "Release", configuration.PublishPath, configuration.BinPath, configuration.Environment, false, "Ccds");
			siteController.StopSite(configuration);
			fileSystemAdapter.DeleteFilesInDirectory(configuration);
			fileSystemAdapter.CopyDirectoryOverNetwork(configuration);
			siteController.StartSite(configuration);

			logger.RecordInfo("Deployment complete");
		}

		public void DeployOnDemand(string buildConfiguration, string deploymentConfiguration, string sourcePath, string binPath)
		{
			Deploy(CcdsDeploymentConfiguration.FromConfigurationString(deploymentConfiguration, sourcePath, binPath, secureStore));
		}

		public void AutoDeployLatestBuild(string buildConfiguration, string deploymentConfiguration, string sourcePath, string binPath)
		{
			Deploy(CcdsDeploymentConfiguration.FromConfigurationString(deploymentConfiguration, sourcePath, binPath, secureStore));
		}

		public void AutoDeployTestedShelf(string buildConfiguration, string deploymentConfiguration, string sourcePath, string binPath, TaskInfo taskInfo)
		{
			throw new NotImplementedException();
		}

		public void TeardownTestedShelf(string buildConfiguration, string deploymentConfiguration, TaskInfo taskInfo)
		{
			throw new NotImplementedException();
		}

		readonly IFileSystemAdapter fileSystemAdapter;
		readonly ITaskLogger logger;
		readonly IPublishBuilder publishBuilder;
		readonly ISecureStore secureStore;
		readonly ISiteController siteController;
	}
}
