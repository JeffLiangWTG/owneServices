using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;

namespace Ccds.Test
{
	[TestFixture]
	public class CompositionRootTest
	{
		[Test]
		[System.Diagnostics.CodeAnalysis.SuppressMessage("Usage", "CA1031: Do not catch general exception types", Justification = "Test")]
		public void CanResolveAllInterfaceImplementations()
		{
			// Arrange
			var serviceBaseMock = new ServiceCollection();

			// Act
			serviceBaseMock.RegisterInterfaceImplementations();

			// Assert
			var registeredTypes = serviceBaseMock
				.Select(registration => registration.ServiceType)
				.ToList();
			var provider = serviceBaseMock.BuildServiceProvider();

			Assert.Multiple(() =>
			{
				registeredTypes.ForEach(registration =>
				{
					try
					{
						Assert.That(provider.GetService(registration), Is.Not.Null, $"Can not find Implementation for {registration}");
					}
					catch (Exception e)
					{
						Assert.Fail($"Can not find Implementation for {registration} because of exception :{e}");
					}
				});
			});
		}
	}
}
