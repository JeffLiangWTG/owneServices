namespace Interfaces.Core
{
	public interface IServiceStatusRetriever
	{
		IEnumerable<IServiceStatusRecord> Retrieve();
	}
}
