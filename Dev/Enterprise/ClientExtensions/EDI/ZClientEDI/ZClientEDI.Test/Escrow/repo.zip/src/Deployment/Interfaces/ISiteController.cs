namespace Deployment.Interfaces
{
	public interface ISiteController
	{
		public void StartSite(IDeploymentConfiguration configuration);
		public void StopSite(IDeploymentConfiguration configuration);
	}
}
