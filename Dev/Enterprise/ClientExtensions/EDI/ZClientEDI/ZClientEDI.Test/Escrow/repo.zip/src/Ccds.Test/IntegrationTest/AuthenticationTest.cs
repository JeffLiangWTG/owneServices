using System.Net;
using NUnit.Framework;

namespace Ccds.Test.IntegrationTest
{
	[TestFixture]
	[System.Diagnostics.CodeAnalysis.SuppressMessage("Usage", "CA2234:Pass system uri objects instead of strings", Justification = "Test")]
	class AuthenticationTest : IntegrationTestBase<Startup>
	{
		[TestCaseSource(nameof(SupportedRequestHeaders))]
		public void AuthenticationIsAttemptedWithServer(HttpMethod method)
		{
			// Arrange
			var client = TestClientFactory!.GetClient();
			using var requestMessage = new HttpRequestMessage(method, "/wtg/status");

			// Act
			// Assert
			Assert.That(
				() => client.SendAsync(requestMessage).Result,
				Throws.Exception.With.InnerException.TypeOf<NotSupportedException>().With.Message.Contains("Negotiate authentication requires a server that supports IConnectionItemsFeature like Kestrel."));
		}

		[TestCaseSource(nameof(SupportedRequestHeaders))]
		public void EndpointDoesNotThrowWhenAuthenticationMiddlewareIsReplaced(HttpMethod method)
		{
			// Arrange
			DisableAuthentication();
			var asd = HttpMethod.Get;
			var client = TestClientFactory!.GetClient();
			using var requestMessage = new HttpRequestMessage(method, "/wtg/status");

			// Act
			var result = client.SendAsync(requestMessage).Result;

			// Assert
			Assert.That(result.StatusCode, Is.EqualTo(HttpStatusCode.OK));
		}

		static IEnumerable<TestCaseData> SupportedRequestHeaders()
		{
			yield return new TestCaseData(HttpMethod.Get);
			yield return new TestCaseData(HttpMethod.Head);
		}
	}
}
