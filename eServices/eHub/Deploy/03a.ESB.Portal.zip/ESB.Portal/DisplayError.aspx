<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="DisplayError.aspx.cs"
    Inherits="Microsoft.Practices.ESB.Portal.DisplayError" Title="ESB Management Console - Error"%>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <table class="FaultViewer" width="100%">
        <tr>
            <td>
                <table cellspacing="0" cellpadding="0" class="FaultViewer" border="1" width="100%">
                    <colgroup width="100px" span="1"></colgroup>
                    <tr>
                        <th colspan="2" class="FaultViewer">
                            ESB Portal Error Information</th>
                    </tr>
                    <tr>
                        <td class="FaultViewer">
                            Title
                        </td>
                        <td>
                            Unhandled Exception
                        </td>
                    </tr>
                    <tr>
                        <td>
                            Information
                        </td>
                        <td>
                            An unhandled exception has occurred. Please view the event log for detail information.
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</asp:Content>
