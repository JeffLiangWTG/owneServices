<%@ Control Language="C#" AutoEventWireup="true" Codebehind="MessageViewer.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.MessageViewer" %>
<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers" TagPrefix="cc1" %>
<script language="javascript" type="text/javascript">
    ///<summary>
    /// This function triggers the UI to go into edit mode.  Edit mode
    /// causes the Message Viewer to allow edits to the message and
    /// for the message to be resubmitted.
    ///</summary>
    function enterEditMode()
    {
        var navigateUrl = window.location.href;
   
        if(navigateUrl.indexOf("?") < 0)
	    {
	        navigateUrl += "?";
	    }
	    else
	    {
	        navigateUrl += "&";
	    }
	   
        navigateUrl += "esb:Mode=Edit";
        window.location = unescape(navigateUrl);
    }
    
    ///<summary>
    /// This function triggers the UI to leave edit mode.  Leaving edit
    /// mode causes the original message to be displayed, and made read
    /// only.  The Edit button is displayed again, and the Resubmit and
    /// Cancel buttons are hidden.
    ///</summary>
    function exitEditMode()
    { 
        window.location = unescape(removeQueryStringParam(window.location.href, "esb:Mode"));        
    }
    
</script>
<asp:FormView ID="MessageView" runat="server" AllowPaging="True" Width="100%">
	<ItemTemplate>
		<input type="hidden" id="resubmitAttempted" value='<%#DataBinder.Eval(Container.DataItem, "ResubmitAttempted") %>' runat="server" />
		<input type="hidden" id="resubmitSuccessful" value='<%#DataBinder.Eval(Container.DataItem, "ResubmitSuccessful") %>' runat="server" />
		<div style="clear: both; padding-bottom: 15px;">
			<a href="../Faults/FaultViewer.aspx?esb:FaultID=<%#DataBinder.Eval(Container.DataItem, "FaultID")%>">< Back to Original Fault</a>
		</div>
		<h1>
			<asp:Label ID="labelHeaderCaption" runat="server" Text="Message Viewer" CssClass="iconMessage" OnPreRender="labelHeaderCaption_PreRender"></asp:Label></h1>
		<h3>
			Message Details</h3>
		<div class="formBodyNoForm">
			<div class="formRow">
				<div class="formLabel">
					Message ID:</div>
				<div class="formField">
					<asp:Label Text='<%#DataBinder.Eval(Container.DataItem, "NativeMessageID")%>' ID="nativeMessageIDLabel" runat="server" />&nbsp;
					<asp:Label Visible="false" Text='<%#DataBinder.Eval(Container.DataItem, "MessageID")%>' ID="messageIdLabel" runat="server" /></div>
			</div>
			<div class="formRow">
				<div class="formLabel">
					Interchange ID:</div>
				<div class="formField">
					<%#DataBinder.Eval(Container.DataItem, "InterchangeID")%>
				</div>
			</div>
			<div class="formRow">
				<div class="formLabel">
					Routing URL:</div>
				<div class="formField">
					<asp:Label Text='<%#DataBinder.Eval(Container.DataItem, "RoutingURL")%>' ID="routingURLLabel" runat="server" /></div>
			</div>
			<div class="formRow">
				<div class="formLabel">
					Message Name:</div>
				<div class="formField">
					<%#DataBinder.Eval(Container.DataItem, "MessageName")%>
				</div>
			</div>
			<div class="formRow">
				<div class="formLabel">
					Content Type:</div>
				<div class="formField">
					<asp:Label Text='<%#DataBinder.Eval(Container.DataItem, "ContentType")%>' ID="contentTypeLabel" runat="server" /></div>
			</div>
			<div class="formRow">
<%--				<div class="formLabel">
					Message Data:</div>--%>
				<div class="formField">
			    <asp:TextBox Visible="false" ID="messageBodyBox" runat="server" TextMode="MultiLine" CssClass="formFieldInput" Height="200" Width="600" Text='<%#DataBinder.Eval(Container.DataItem, "MessageData")%>'>
					</asp:TextBox>
					<asp:DropDownList ID="receiveLocationList" runat="server" />
					<a id="messageBodyAnchor" runat="server" href='<%# "DownloadMessageBody.ashx?esb:MessageID=" + (Convert.ToString(DataBinder.Eval(Container.DataItem, "MessageID"))) %>'>
						<%--<img src="../Images/Icons/16_download.gif" title="Download" style="vertical-align: middle;" />&nbsp;Download--%></a><%-- | --%><span id="editButton" runat="server"><a href="javascript:enterEditMode()">
						
							<img src="../Images/Icons/16_edit.gif" title="Edit" style="vertical-align: middle;" />&nbsp;Edit</a> </span>&nbsp;&nbsp;
					<asp:LinkButton ID="resubmitButton" runat="server" ToolTip="Resubmit edited message" OnClick="resubmitButton_Click" Text="Resubmit" />
					<span id="cancelButton" runat="server">| <a href="javascript:exitEditMode();">Cancel</a></span>
				</div>
			</div>
		</div>
		<div class="formRow">
			<div class="formLabel">
				Resubmission Status:</div>
			<div class="formField">
				<div style="clear: both;">
					<asp:Label ID="resubmissionLabel" runat="server" /><br />
				</div>
			</div>
		</div>
	</ItemTemplate>
</asp:FormView>
<br clear="all" />
<h3>
	Context Properties</h3>
<asp:GridView ID="contextPropertiesView" runat="server" AllowPaging="True" 
    AllowSorting="True" AutoGenerateColumns="False" 
    Width="100%" BorderWidth="0" 
    PageSize="25" CellPadding="0" 
    onrowdatabound="contextPropertiesView_RowDataBound" 
    onpageindexchanging="contextPropertiesView_PageIndexChanging"
    >
	<HeaderStyle CssClass="tableHeader" />
	<RowStyle CssClass="tableRow" />
	<Columns>
		<asp:BoundField DataField="MessageID" HeaderText="MessageID" SortExpression="MessageID" Visible="False" />
		<asp:TemplateField HeaderText="Name" SortExpression="Name">
			<ItemTemplate>
				<asp:Label ID="lblName" ToolTip='<%# GetCrumbedString(Eval("Name"),40) %>' runat="server" Text='<%# GetCrumbedString(Eval("Name"),40) %>'></asp:Label>
			</ItemTemplate>
		</asp:TemplateField>
		<asp:TemplateField HeaderText="Value" SortExpression="Value">
			<ItemTemplate>
				<asp:Label ID="lblValue" runat="server" ToolTip='<%# GetCrumbedString(Eval("Value"), 100) %>' Text='<%# GetCrumbedString(Eval("Value"), 100) %>'></asp:Label>
				<asp:Label ID="lblValueOriginal" Visible="false" runat="server" Text='<%# Eval("Value") %>'></asp:Label>
				<asp:HyperLink ID="hlnkItineraries" runat="server" Text="See itineraries" Visible="false" />
			</ItemTemplate>
		</asp:TemplateField>
		<asp:TemplateField HeaderText="Type" SortExpression="Type">
			<ItemTemplate>
				<asp:Label ID="lblType" runat="server" ToolTip='<%# GetCrumbedString(Eval("Type"),100) %>' Text='<%# GetCrumbedString(Eval("Type"),100) %>'></asp:Label>
			</ItemTemplate>
		</asp:TemplateField>
	</Columns>
</asp:GridView>
<cc1:GridViewSortExtender ID="GridViewSortExtender1" runat="server" AscendingImageUrl="~/Images/asc_order.gif" DescendingImageUrl="~/Images/desc_order.gif" ExtendeeID="contextPropertiesView">
</cc1:GridViewSortExtender>
<%--<asp:ObjectDataSource ID="MessageContextProperitesData" runat="server" OldValuesParameterFormatString="original_{0}" SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.FaultsTableAdapters.ContextPropertiesTableAdapter">
	<SelectParameters>
		<asp:QueryStringParameter Name="MessageID" QueryStringField="esb:MessageID" Type="String" />
		<asp:Parameter Name="Debug" Type="Boolean" DefaultValue="false" />
	</SelectParameters>
</asp:ObjectDataSource>--%>
<%--<asp:ObjectDataSource ID="messageDataSource" runat="server" SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.FaultsTableAdapters.MessagesTableAdapter">
	<SelectParameters>
		<asp:QueryStringParameter Name="FaultID" QueryStringField="esb:FaultID" />
		<asp:QueryStringParameter Name="MessageID" QueryStringField="esb:MessageID" />
		<asp:Parameter DefaultValue="false" Name="debug" Type="Boolean" />
	</SelectParameters>
</asp:ObjectDataSource>--%>
<%--<asp:ObjectDataSource ID="contextPropertiesDataSource" runat="server" SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.FaultsTableAdapters.ContextPropertiesTableAdapter">
	<SelectParameters>
		<asp:QueryStringParameter Name="MessageID" QueryStringField="esb:MessageID" />
		<asp:Parameter DefaultValue="false" Name="debug" Type="Boolean" />
	</SelectParameters>
</asp:ObjectDataSource>--%>
