//---------------------------------------------------------------------
// File: FaultViewer.ascx.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal
{
    public partial class FaultViewer : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IExceptionService client = null;
                try
                {
                    client = PortalHelper.GetExceptionService();
                    Fault fault = client.GetFault(new Guid(Request.QueryString["esb:FaultID"]));

                    List<Fault> faults = new List<Fault>();
					if (fault != null)
					{
						faults.Add(fault);
					}

                    FormView1.DataSource = faults;
                    FormView1.DataBind();

                    List<usp_select_MessagesResult> messages = client.GetMessages(
						Request.QueryString["esb:FaultID"], Request.QueryString["esb:MessageID"]) ?? 
						new List<usp_select_MessagesResult>();

                    GridView messagesView = FormView1.FindControl("messagesView") as GridView;
					if (messagesView != null)
					{
						messagesView.DataSource = messages;
						messagesView.DataBind();
					}
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }
        }

        public string GetSeverityText(object severity)
        {
            string severityHtml = "<img style='vertical-align:middle;' src='../" +
                PortalHelper.TranslateSeverityImages(int.Parse(severity.ToString())) + "'> " +                 
                PortalHelper.TranslateSeverityText(int.Parse(severity.ToString()));

            return severityHtml;
        }
    }
}