<%@ WebHandler Language="C#" CodeBehind="DownloadMessageBody.ashx.cs" Class="Microsoft.Practices.ESB.Portal.DownloadMessageBody" %>
