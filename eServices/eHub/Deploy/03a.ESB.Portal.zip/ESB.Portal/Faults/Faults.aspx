<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="Faults.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Faults.Faults2" Title="ESB Management Console - Faults"  UICulture="auto" Culture="auto" %>
<%@ Register Src="../Lists/FaultList.ascx" TagName="FaultList" TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<h1 class="iconFault">Faults</h1><br />
    <uc1:FaultList ID="FaultList1" runat="server" />
</asp:Content>
