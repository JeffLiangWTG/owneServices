//---------------------------------------------------------------------
// File: DownloadMessageBody.ashx.cs
// 
// Summary: This handler allows the download of a message body.  It
//          retrieves the message body from the database, where it is
//          stored in a varbinary(max) column.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Data;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Configuration;
using System.Data.SqlClient;
//using Microsoft.Practices.ESB.Portal.DataSets.FaultsTableAdapters;
//using Microsoft.Practices.ESB.Portal.DataSets.AuditLogTableAdapters;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal
{
    /// <summary>
    /// This handler allows the download of Base64 encoded files stored in the EsbExceptionDb database.
    /// It decodes the data before sending it to the user.
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class DownloadMessageBody : IHttpHandler
    {       
        /// <summary>
        /// This method retrieves the message body from the database using the MessageID from the querystring.
        /// It then sets the response content type to the actual content type of the message body.  It starts
        /// the file download to the user's computer with the default filename of {MessageID}.body.
        /// </summary>
        public void ProcessRequest(HttpContext context)
        {
            //Retrieve the message data
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();
                List<usp_select_MessagesResult> messages = client.GetMessages(null, context.Request.QueryString["esb:MessageID"] ?? "");

                //MessagesTableAdapter messagesTA = new MessagesTableAdapter();
                //DataSets.Faults.MessagesDataTable messageTable = messagesTA.GetData(null, context.Request.QueryString["esb:MessageID"] ?? "", false);

                usp_select_MessagesResult message = messages[0];

                bool decodeMessage = !(message.ContentType.Contains("text"))
                                        && !(message.ContentType.Contains("application\\octet-stream"));

                //Insert audit information
                
                //AuditLogTableAdapter auditLogTA = new AuditLogTableAdapter();
                //DataSets.AuditLog.AuditLogDataTable auditLogTable = new DataSets.AuditLog.AuditLogDataTable();
                //DataSets.AuditLog.AuditLogRow auditRow = auditLogTable.NewAuditLogRow();

                AuditLog auditLog = new AuditLog();
                auditLog.ActionName = "Save";
                auditLog.AuditDate = DateTime.UtcNow;
                auditLog.AuditUserName = context.User.Identity.Name;
                auditLog.MessageID = message.MessageID;

                client.InsertAuditLog(auditLog);

                Byte[] file;

                if (decodeMessage)
                {
                    //Decode the message body
                    file = Formatter.DeserializeObject<Byte[]>(message.MessageData);
                }
                else
                {
                    file = StringToByte(message.MessageData);
                }

                //Set the download parameters
                string fileName = context.Request.QueryString["esb:MessageID"] ?? "" + ".body";
                context.Response.Buffer = true;
                context.Response.ClearHeaders();
                context.Response.ContentType = message.ContentType;
                context.Response.Clear();
                context.Response.AddHeader("Content-Disposition", "attachment;Filename=" + fileName);
                context.Response.Expires = -1;

                //Initiate the message body download
                context.Response.BinaryWrite(file);
                context.Response.End();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }

        /// <summary>
        /// Converts a string to a byte array.
        /// </summary>
        /// <param name="str">The string to convert.</param>
        /// <returns>A byte array containing the string that was passed int.</returns>
        private static byte[] StringToByte(string str)
        {
           System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
           return encoding.GetBytes(str);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
