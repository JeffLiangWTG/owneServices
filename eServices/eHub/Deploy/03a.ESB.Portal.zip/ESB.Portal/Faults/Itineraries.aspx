﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="Itineraries.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Faults.Itineraries" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <asp:GridView ID="grdItineraries" runat="server" 
    AutoGenerateColumns="True" 
    Width="100%" BorderWidth="0" 
    CellPadding="0">
	<HeaderStyle CssClass="tableHeader" />
	<RowStyle CssClass="tableRow" />
    </asp:GridView>
</asp:Content>
