﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ServiceModel;
using ESB.BAM.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Faults
{
    public partial class Itineraries : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack && !Master.IsPostBack)
            {
                string uuid = Request["uuid"];

                BindItineraries(uuid);
            }
        }

        private void BindItineraries(string uuid)
        {
            if(string.IsNullOrEmpty(uuid))
            {
                return;
            }

            ChannelFactory<IBAMService> factory = new ChannelFactory<IBAMService>("BAMService");
			factory.Credentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
            var proxy = factory.CreateChannel();
            var result = proxy.GetItinerariesByItineraryUuid(uuid);
            ((IDisposable)proxy).Dispose();

            var itineraries = from i in result							  
                              select new { Record = i.RecordID, BeginTime = i.ItineraryBeginTime, State = i.ItineraryState, 
                              ESBService = i.ESBServiceName, IsRequestResponse = i.ItineraryisRequestResponse, ServiceState = i.ServiceState,
                              MessageDirection = i.MessageDirection, LastModified = i.LastModified};

            grdItineraries.DataSource = itineraries;
            grdItineraries.DataBind();
        }
    }
}
