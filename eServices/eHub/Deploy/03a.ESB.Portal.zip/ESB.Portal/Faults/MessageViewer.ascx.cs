//---------------------------------------------------------------------
// File: MessageViewer.aspx.cs
// 
// Summary: This page displays the details of a message.  It renders the message body
//          if it is an XML or flat file.  Otherwise if allows the message
//          body to be downloaded.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Net;
using System.IO;
//using Microsoft.Practices.ESB.Portal.DataSets.FaultsTableAdapters;
//using Microsoft.Practices.ESB.Portal.DataSets.AuditLogTableAdapters;
using System.Text;
using System.Xml;
using System.ServiceModel;
using ESB.BAM.Service.Implementation;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal
{
    public partial class MessageViewer : System.Web.UI.UserControl
    {
        #region Properties

        /// <summary>
        /// True if the message is text based, false otherwise.
        /// </summary>
        private bool MessageIsText
        {
            get
            {
                return (((Label)this.MessageView.FindControl("contentTypeLabel")).Text.Contains("text")
                 || ((Label)this.MessageView.FindControl("contentTypeLabel")).Text.Equals("application/octet-stream"));
            }
        }

        /// <summary>
        /// Indicates whether a resubmission attempt has been made on the message.
        /// </summary>
        private bool _resubmitAttempted;
        private bool ResubmitAttempted
        {
            get { return _resubmitAttempted; }
            set { _resubmitAttempted = value; }
        }

        /// <summary>
        /// Indicates whether the message has been successfully resubmitted.
        /// </summary>
        private bool _resubmitSuccessful;
        private bool ResubmitSuccessful
        {
            get { return _resubmitSuccessful; }
            set { _resubmitSuccessful = value; }
        }

        /// <summary>
        /// Indicated whether the control is allowed to go into edit mode.
        /// </summary>
        private bool _editModeAvailable;
        private bool EditModeAvailable
        {
            get { return _editModeAvailable; }
            set { _editModeAvailable = value; }
        }

        /// <summary>
        /// Get the selected receive location from the 'receiveLocationList' DropDownlist.
        /// </summary>
        private string SelectedReceiveLocation
        {
            get
            {
                if (((DropDownList)this.MessageView.FindControl("receiveLocationList")).SelectedItem.Text == "Submit to Routing URL")
                {
                    return "RoutingURL";
                }
                else
                {
                    return ((DropDownList)this.MessageView.FindControl("receiveLocationList")).SelectedValue;
                }
            }
        }

        /// <summary>
        /// Gets the message content type (MIME type).
        /// </summary>
        private string MessageContentType
        {
            get { return ((Label)this.MessageView.FindControl("contentTypeLabel")).Text; }
        }

        /// <summary>
        /// This property indicates whether or not the page is in the mode to 
        /// edit and resubmit the message.  This is determined by the esb:Mode 
        /// querystring parameter containing the value: "Edit".
        /// </summary>
        private bool _editMode;
        protected bool EditMode
        {
            set { _editMode = value; }
            get { return _editMode; }
        }

        #endregion

        protected void Page_PreRender(object sender, EventArgs e)
        {
            SetControlVisibility();
            SetControlEditability();
            RenderMessageBody();

            if (!IsPostBack)
            {
                PopulateReceiveLocationList();
            }
        }

        private void BindGrid()
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();

                List<usp_select_ContextPropertiesResult> contextProperties = client.GetContextProperties(new Guid(Request.QueryString["esb:MessageID"]));

                contextPropertiesView.DataSource = contextProperties;
                contextPropertiesView.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IExceptionService client = null;
                try
                {
                    client = PortalHelper.GetExceptionService();
                    List<usp_select_MessagesResult> messages = client.GetMessages(Request.QueryString["esb:FaultID"], Request.QueryString["esb:MessageID"]);

                    MessageView.DataSource = messages;
                    MessageView.DataBind();

                    BindGrid();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }

            this.EditMode = (Request.QueryString["esb:Mode"] == "Edit");

            this.EditModeAvailable = (((HtmlInputHidden)this.MessageView.FindControl("resubmitSuccessful")).Value == "True"
                                          || !this.MessageIsText
                                          || this.EditMode) ? false : true;
            this.ResubmitAttempted = (((HtmlInputHidden)this.MessageView.FindControl("resubmitAttempted")).Value == "True");
            this.ResubmitSuccessful = (((HtmlInputHidden)this.MessageView.FindControl("resubmitSuccessful")).Value == "True");

            if (this.ResubmitSuccessful)
            {
                ((Label)this.MessageView.FindControl("resubmissionLabel")).Text = "<img src='../images/severityinformation.gif' style='vertical-align:middle;'/>&nbsp;This message has been successfully resubmitted.";
                ((Label)this.MessageView.FindControl("resubmissionLabel")).ForeColor = System.Drawing.Color.Black;
            }
            else if (this.ResubmitAttempted)
            {
                ((Label)this.MessageView.FindControl("resubmissionLabel")).Text = "<img src='../images/severitycritical.gif' style='vertical-align:middle;'/>&nbsp;A message resubmission was attempted but failed.";
                ((Label)this.MessageView.FindControl("resubmissionLabel")).ForeColor = System.Drawing.Color.Red;
            }
        }

        /// <summary>
        /// Calls the resubmit helper class to transmit the message back to BizTalk.  Logs the result to the portal audit log.
        /// </summary>
        protected void resubmitButton_Click(object sender, EventArgs e)
        {
            //Resubmit the message to the selected receive location via HTTP
            string messageID = ((Label)this.MessageView.FindControl("messageIDLabel")).Text;
            string statusCode;
            string statusMessage;

            bool result = ResubmitMessage(((DropDownList)this.MessageView.FindControl("receiveLocationList")).SelectedValue, out statusCode, out statusMessage);
            this.ResubmitAttempted = true;

            if (result == false)
            {
                ((Label)this.MessageView.FindControl("resubmissionLabel")).Text = "<img src='../images/severitycritical.gif' style='vertical-align:middle;'/>&nbsp;The resubmission failed: " + statusCode + " - " + statusMessage;
                ((Label)this.MessageView.FindControl("resubmissionLabel")).ForeColor = System.Drawing.Color.Red;
                ((Label)this.MessageView.FindControl("resubmissionLabel")).Visible = true;
            }
            else
            {
                this.ResubmitSuccessful = true;
                this.EditMode = false;
                this.EditModeAvailable = false;
                ((Label)this.MessageView.FindControl("resubmissionLabel")).Text = "<img src='../images/severityinformation.gif' style='vertical-align:middle;'/>&nbsp;This message has been successfully resubmitted.";
                ((Label)this.MessageView.FindControl("resubmissionLabel")).ForeColor = System.Drawing.Color.Black;
                ((Label)this.MessageView.FindControl("resubmissionLabel")).Visible = true;
            }

            //Update the resubmission status in the Message table
            UpdateMessageResubmissionStatus(result);

            //Write an audit log event for the message resubmission
            AuditMessageResubmission(result, statusCode, statusMessage, ((DropDownList)this.MessageView.FindControl("receiveLocationList")).SelectedValue);
        }

        /// <summary>
        /// Resubmits the message body to the URL selected in the resubmit location DropDownList.
        /// </summary>
        /// <returns>True if the message was successfully resubmitted, false otherwise.</returns>
        private bool ResubmitMessage(string resubmitUrl, out string responseCode, out string responseMessage)
        {
            bool result = false;    // returned.
            if (resubmitUrl.ToUpper().Equals("WCF ONRAMP"))
            {
                // resubmit message and capture the result
                System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                doc.LoadXml(((TextBox)this.MessageView.FindControl("messageBodyBox")).Text);
                result = MessageResubmitter.ResubmitWCF(doc);
                if (result == true)
                {
                    responseCode = "202";
                    responseMessage = "Successfully sumbitted to WCF OnRamp";
                }
                else
                {
                    responseCode = "500";
                    responseMessage = "Failure submitting to WCF OnRamp";
                }
            }
            else if (resubmitUrl.ToUpper().Equals("SOAP ONRAMP"))
            {
                // resubmit message and capture the result
                System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                doc.LoadXml(((TextBox)this.MessageView.FindControl("messageBodyBox")).Text);
                result = MessageResubmitter.ResubmitSOAP(doc);
                if (result == true)
                {
                    responseCode = "202";
                    responseMessage = "Successfully sumbitted to SOAP OnRamp";
                }
                else
                {
                    responseCode = "500";
                    responseMessage = "Failure submitting to SOAP OnRamp";
                }
            }
            else if (resubmitUrl.ToUpper().Equals("EHUB ONRAMP"))
            {
                // Resubmit to eHub
                string messageID = ((Label)this.MessageView.FindControl("messageIdLabel")).Text;
                result = eHubResubmitter.Resubmit(messageID);
                if (result == true)
                {
                    responseCode = "202";
                    responseMessage = "Successfully sumbitted to eHub OnRamp";
                }
                else
                {
                    responseCode = "500";
                    responseMessage = "Failure submitting to eHub OnRamp";
                }
            }
            else
            {
                HttpStatusCode statusCode;

                //check to see if we need to set a proxy
                using (Stream messageReader = this.GetMessageDataStream(((TextBox)this.MessageView.FindControl("messageBodyBox")).Text))
                {
                    HttpWebRequest HttpWRequest = (HttpWebRequest)WebRequest.Create(resubmitUrl);

                    // TODO: (jsk) put settings in web.config
                    // set the name of the user agent. This is the client name that is passed to IIS
                    HttpWRequest.Headers.Set("Pragma", "no-cache");

                    HttpWRequest.UserAgent = Page.User.Identity.Name;
                    HttpWRequest.KeepAlive = true; //this is the default
                    HttpWRequest.Timeout = 300000;
                    HttpWRequest.Method = "POST";
                    HttpWRequest.ContentType = MessageContentType;
                    HttpWRequest.Credentials = CredentialCache.DefaultCredentials;

                    // resubmit message and capture the result

                    statusCode = MessageResubmitter.ResubmitHTTP(HttpWRequest, messageReader);

                    //Anything between 200 and 299 is considered success
                    result = ((int)statusCode > 199 && (int)statusCode < 301);
                    responseCode = ((int)statusCode).ToString();
                    responseMessage = Enum.GetName(typeof(HttpStatusCode), statusCode);
                }
            }
            return result;
        }

        /// <summary>
        /// Extracts and returns a Stream from the given string.
        /// </summary>
        /// <param name="messageDataString">The string to extract into a stream.</param>
        /// <returns>A stream from the given string.</returns>
        private Stream GetMessageDataStream(string messageDataString)
        {
            MemoryStream ms = new MemoryStream(ASCIIEncoding.Default.GetBytes(messageDataString));
            return ms;
        }

        /// <summary>
        /// Updates the ResubmitAttempted and ResubmitSuccessful fields on the Message table
        /// in the database.
        /// </summary>
        /// <param name="success">True if the message was successfully resubmitted, false otherwise.</param>
        private void UpdateMessageResubmissionStatus(bool success)
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();
                client.InsertMessage(((Label)this.MessageView.FindControl("messageIDLabel")).Text, true, success);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }

            //DataSets.Faults.MessagesDataTable messageTable = new DataSets.Faults.MessagesDataTable();

            ////The only values that are used by this call are MessageID, ResubmissionAttempted, and ResubmissionSuccessful.  
            ////The 2nd new Guid is just there because null is not accepted.
            //messageTable.AddMessagesRow(((Label)this.MessageView.FindControl("messageIDLabel")).Text, null, null, null, null, null, null, null, true, success, DateTime.Now);
            //MessagesTableAdapter messageAdapter = new MessagesTableAdapter();
            //messageAdapter.Update(messageTable);
        }

        /// <summary>
        /// Writes the failed or successful resubmission event to the audit log.
        /// </summary>
        /// <param name="success">True if the message was successfully resubmitted, false otherwise.</param>
        private void AuditMessageResubmission(bool success, string resubmitCode, string resubmitMessage, string resubmitUrl)
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();
                AuditLog auditLog = new AuditLog();
                auditLog.ActionName = success ? "SuccessfulResubmit" : "UnsuccessfulResubmit";
                auditLog.AuditDate = DateTime.UtcNow;
                auditLog.AuditUserName = Page.User.Identity.Name;
                auditLog.MessageID = new Guid(((Label)this.MessageView.FindControl("messageIDLabel")).Text);
                auditLog.ResubmitURL = resubmitUrl;
                auditLog.ResubmitCode = resubmitCode;
                auditLog.ResubmitMessage = resubmitMessage;
                // auditLog.MessageData = ((TextBox)this.MessageView.FindControl("messageBodyBox")).Text;
                auditLog.MessageData = string.Empty;

                client.InsertAuditLog(auditLog);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }

            ////Insert audit information
            //AuditLogTableAdapter auditLogTA = new AuditLogTableAdapter();

            //DataSets.AuditLog.AuditLogDataTable auditLogTable = new DataSets.AuditLog.AuditLogDataTable();

            //DataSets.AuditLog.AuditLogRow auditRow = auditLogTable.NewAuditLogRow();

            //auditRow.ActionName = success ? "SuccessfulResubmit" : "UnsuccessfulResubmit";
            //auditRow.AuditDate = DateTime.UtcNow;
            //auditRow.AuditUserName = Page.User.Identity.Name;
            //auditRow.MessageID = new Guid(((Label)this.MessageView.FindControl("messageIDLabel")).Text);
            //auditRow.ResubmitURL = resubmitUrl;
            //auditRow.ResubmitCode = resubmitCode;
            //auditRow.ResubmitMessage = resubmitMessage;
            ////auditRow.ContentType = (((Label)this.MessageView.FindControl("contentTypeLabel")).Text);

            //if (success)
            //{
            //    auditRow.MessageData = ((TextBox)this.MessageView.FindControl("messageBodyBox")).Text;
            //}

            //auditLogTable.AddAuditLogRow(auditRow);

            //auditLogTA.Update(auditLogTable);
        }

        /// <summary>
        /// Populates the receive location selection list with the WCF OnRamp, the SOAP OnRamp, and/or all HTTP receive locations on the BizTalk group.  Flat File resubmission is limited to HTTP receive
        /// locations only, while XML document resubmission can be to WCF, SOAP, or HTTP.
        /// </summary>
        private void PopulateReceiveLocationList()
        {
            BizTalkOperationsService.Operations queryService = Microsoft.Practices.ESB.Portal.BizTalkOperationsService.Operations.CreateInstance();
            BizTalkOperationsService.BTSysStatus sysStatus = queryService.ReceiveLocations(string.Empty);

            //Loop through the receive locations and extract the HTTP and WCF HTTP receive locations.
            int i = 0;
            ArrayList httpRcvLocs = new ArrayList();
            foreach (BizTalkOperationsService.BTReceiveLocation rcvLoc in sysStatus.ReceiveLocations)
            {
                if (rcvLoc.Handler.ProtocolName.ToUpper().Equals("HTTP"))
                {
                    rcvLoc.Address = "http://" + rcvLoc.Handler.Host.HostInstances[0].ServerName + rcvLoc.Address;
                    httpRcvLocs.Add(rcvLoc);
                    i++;
                }
            }

            DropDownList receiveLocList = ((DropDownList)this.MessageView.FindControl("receiveLocationList"));

            //Add a default selection to the applications list
            if (String.IsNullOrEmpty(((Label)this.MessageView.FindControl("routingURLLabel")).Text))
            {
                receiveLocList.Items.Add(new ListItem("Select a receive location.", null));
            }
            else
            {
                receiveLocList.Items.Add(new ListItem("Submit to Routing URL", ((Label)this.MessageView.FindControl("routingURLLabel")).Text));
            }

            //Add the WCF and SOAP OnRamps if the message is not a flat file
            //if (((Label)this.MessageView.FindControl("contentTypeLabel")).Text.ToUpper() != "TEXT/PLAIN")
            //{
            //    receiveLocList.Items.Add(new ListItem("WCF OnRamp", "WCF OnRamp")); //URL will be retrieved from web.config
            //    receiveLocList.Items.Add(new ListItem("SOAP OnRamp", "SOAP OnRamp")); //URL will be retrieved from web.config
            //}
            receiveLocList.Items.Add(new ListItem("eHub OnRamp", "eHub OnRamp")); //URL will be retrieved from web.config

            //Populate the receive locations list with the receive locations from BizTalk 
            receiveLocList.AppendDataBoundItems = true;
            receiveLocList.DataSource = httpRcvLocs;
            receiveLocList.DataTextField = "Name";
            receiveLocList.DataValueField = "Address";
            receiveLocList.DataBind();
        }

        /// <summary>
        /// This method shows or hides the correct control to display the message body.  When the message
        /// body is text based, it is rendered to the screen in a TextBox.  When the message body is binary
        /// a link is displayed to download it.
        /// </summary>
        private void RenderMessageBody()
        {
            //If the message content type is text
            if (this.MessageIsText)
            {
                //Make the message body download link invisible.
                //((TextBox)this.MessageView.FindControl("messageBodyBox")).Visible = true;
                ((TextBox)this.MessageView.FindControl("messageBodyBox")).Visible = false;
            }
        }

        /// <summary>
        /// Reads the mode from the querystring, and shows/hides the appropriate buttons.
        /// By default the Edit button is shown, if the mode = Edit, the Resubmit and Cancel buttons
        /// are shown.
        /// </summary>
        private void SetControlVisibility()
        {
            ((HtmlGenericControl)this.MessageView.FindControl("editButton")).Visible = this.EditModeAvailable;
            ((HtmlAnchor)this.MessageView.FindControl("messageBodyAnchor")).Visible = this.EditModeAvailable;
            ((LinkButton)this.MessageView.FindControl("resubmitButton")).Visible = this.EditMode;
            ((HtmlGenericControl)this.MessageView.FindControl("cancelButton")).Visible = this.EditMode;
            ((DropDownList)this.MessageView.FindControl("receiveLocationList")).Visible = this.EditMode;
            ((Label)this.MessageView.FindControl("resubmissionLabel")).Visible = this.ResubmitAttempted;
        }

        /// <summary>
        /// Sets the editability of controls based on whether the page is in edit mode.
        /// </summary>
        private void SetControlEditability()
        {
            TextBox messageBodyBox = this.MessageView.FindControl("messageBodyBox") as TextBox;

            messageBodyBox.ReadOnly = !this.EditMode;

            if (!this.EditMode)
            {
                messageBodyBox.BackColor = System.Drawing.Color.WhiteSmoke;
            }
            else
            {
                messageBodyBox.BackColor = System.Drawing.Color.White;
            }

        }


        public string GetCrumbedString(object t, int crumbAt)
        {
            string text = t.ToString();
            if (text.Length > crumbAt)
            {
                //return "<span title='" + text + "'>" + HttpUtility.HtmlEncode(  PortalHelper.CrumbString(text, crumbAt)) + "</span>";
                return HttpUtility.HtmlEncode(PortalHelper.CrumbString(text, crumbAt));
            }
            else
            {
                return text;
            }
        }

        protected void labelHeaderCaption_PreRender(object sender, EventArgs e)
        {
            Label me = (Label)sender;

            if (Request.QueryString["esb:Mode"] == "Edit")
            {
                me.CssClass = "iconMessageEdit";
            }
            else
            {
                me.CssClass = "iconMessage";
            }
        }

        protected void contextPropertiesView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label name = e.Row.FindControl("lblName") as Label;

                if (name != null && name.Text.Equals("ItineraryHeader", StringComparison.InvariantCultureIgnoreCase))
                {
                    Label content = e.Row.FindControl("lblValueOriginal") as Label;

                    if (content != null && !string.IsNullOrEmpty(content.Text))
                    {
                        string contentData = HttpUtility.HtmlDecode(content.Text);
                        XmlDocument xml = new XmlDocument();
                        xml.LoadXml(contentData);
                        XmlNodeList nodeList = xml.GetElementsByTagName("Itinerary");

                        if (nodeList.Count > 0)
                        {
                            XmlNode node = nodeList[0];
							if (node.Attributes["uuid"] != null)
							{
								string itineraryUuid = node.Attributes["uuid"].Value;
								HyperLink lnk = e.Row.FindControl("hlnkItineraries") as HyperLink;
								if (lnk != null)
								{
									lnk.Visible = true;
									lnk.NavigateUrl = "Itineraries.aspx?uuid=" + itineraryUuid;
								}
							}
                        }
                    }
                }
            }
        }

        protected void contextPropertiesView_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            contextPropertiesView.PageIndex = e.NewPageIndex;
            BindGrid();
        }
    }
}