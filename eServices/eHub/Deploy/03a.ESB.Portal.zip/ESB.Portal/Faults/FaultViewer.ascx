<%@ Control Language="C#" AutoEventWireup="true" Codebehind="FaultViewer.ascx.cs"
	Inherits="Microsoft.Practices.ESB.Portal.FaultViewer" %>

<%--<asp:ObjectDataSource ID="faultDataSource" runat="server" SelectMethod="GetSingleFault"
	TypeName="Microsoft.Practices.ESB.Portal.DataSets.FaultsTableAdapters.FaultsTableAdapter"
	OldValuesParameterFormatString="original_{0}">
	<SelectParameters>
		<asp:QueryStringParameter Name="FaultID" QueryStringField="esb:FaultID" Type="String" />
		<asp:Parameter DefaultValue="false" Name="debug" Type="Boolean" />
	</SelectParameters>
</asp:ObjectDataSource>--%>
<%--<asp:ObjectDataSource ID="messageDataSource" runat="server" SelectMethod="GetData"
	TypeName="Microsoft.Practices.ESB.Portal.DataSets.FaultsTableAdapters.MessagesTableAdapter">
	<SelectParameters>
		<asp:QueryStringParameter Name="FaultID" QueryStringField="esb:FaultID" />
		<asp:QueryStringParameter Name="MessageID" QueryStringField="esb:MessageID" />
		<asp:Parameter DefaultValue="false" Name="debug" Type="Boolean" />
	</SelectParameters>
</asp:ObjectDataSource>--%>
		<h1 class="iconFault">Fault Viewer</h1>
<asp:FormView ID="FormView1" runat="server" AllowPaging="True">
	<ItemTemplate>

		<h3>Fault Details</h3>
		<div class="formBodyNoForm">
			<div class="formRow">
				<div class="formLabel">Fault Message ID:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "NativeMessageID")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Activity Identity:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "ActivityID")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Fault Code:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "FaultCode")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Fault Description:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "FaultDescription")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Failure Category:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "FailureCategory")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Fault Severity:</div>
				<div class="formField"><%# GetSeverityText(DataBinder.Eval(Container.DataItem, "FaultSeverity"))%></div>				
			</div>
			<div class="lineBreak"></div>
			<div class="formRow">
				<div class="formLabel">Exception Type:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "ExceptionType")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Error Type:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "ErrorType")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Application:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "Application")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Application Scope:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "Scope")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Fault Generator:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "FaultGenerator")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Machine Name:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "MachineName")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Date Time:</div>
				<div class="formField"><%# Microsoft.Practices.ESB.Portal.PortalHelper.UTC_to_ClientLocalTime(DataBinder.Eval(Container.DataItem, "DateTime")).ToString() %></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Service Name:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "ServiceName")%></div>				
			</div>
			<div class="formRow">
				<div class="formLabel">Service Instance ID:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "ServiceInstanceID")%></div>				
			</div>
		</div>
		<h3>Exception Details</h3>
		<div class="formBodyNoForm">
			<div class="formRow">
				<div class="formLabel">Exception Message:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "ExceptionMessage")%></div>				
			</div>
			<div class="lineBreak"></div>
			<div class="formRow">
				<div class="formLabel">Stack Trace:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "ExceptionStackTrace")%></div>				
			</div>
			<div class="lineBreak"></div>
			<div class="formRow">
				<div class="formLabel">Inner Exception Message:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "InnerExceptionMessage")%></div>				
			</div>
			<div class="lineBreak"></div>
			<div class="formRow">
				<div class="formLabel">Source:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "ExceptionSource")%></div>				
			</div>
			<div class="lineBreak"></div>
			<div class="formRow">
				<div class="formLabel">Type:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "ExceptionType")%></div>				
			</div>
			<div class="lineBreak"></div>
			<div class="formRow">
				<div class="formLabel">Target Site:</div>
				<div class="formField"><%#DataBinder.Eval(Container.DataItem, "ExceptionTargetSite")%></div>				
			</div>
		</div>
		
		<h2>Messages</h2>
		<asp:GridView 
			ID="messagesView" 
			runat="server" 
			AllowSorting="False" 
			AutoGenerateColumns="False" 
			DataKeyNames="MessageID" 
			Width="100%" 
			BorderWidth="0" 
			BorderStyle="Solid" 
			AllowPaging="false">
			<HeaderStyle CssClass="tableHeader" />
			<RowStyle CssClass="tableRow" />
			<Columns>
				<asp:TemplateField HeaderText="Message ID" >
					<ItemTemplate>
						<%# "<a href=MessageViewer.aspx?esb:MessageID=" + DataBinder.Eval(Container.DataItem, "MessageID") + ">" + (String.IsNullOrEmpty(System.Convert.ToString((DataBinder.Eval(Container.DataItem, "NativeMessageID")))) ? "View Message" : DataBinder.Eval(Container.DataItem, "NativeMessageID")) + "</a>"%>
					</ItemTemplate>
					<HeaderStyle HorizontalAlign="Center" />
				</asp:TemplateField>
				<asp:BoundField DataField="InterchangeID" HeaderText="Interchange ID" />
				<asp:BoundField DataField="MessageName" HeaderText="Message Name" />
				<asp:BoundField DataField="ContentType" HeaderText="Content Type" />
<%--				<asp:TemplateField>
					<ItemTemplate>
						<a id="messageBodyAnchor" href='<%# "DownloadMessageBody.ashx?esb:MessageID=" + (Convert.ToString(DataBinder.Eval(Container.DataItem, "MessageID"))) %>'>
						<img src="../Images/Icons/16_download.gif" title="Download Message Body" style="vertical-align:middle;" />&nbsp;Download</a>
					</ItemTemplate>
				</asp:TemplateField>--%>
			</Columns>
		</asp:GridView>

	</ItemTemplate>
    <EmptyDataTemplate>
        <br />
        <br />
        
            Fault message not found.&nbsp; The message may have been deleted or archived from
            the database.&nbsp; Please contact &nbsp;administrator for more information.
    </EmptyDataTemplate>
</asp:FormView>
