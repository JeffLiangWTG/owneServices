<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="MessageViewer.aspx.cs" Inherits="ESB.Portal.MessageViewer" Title="ESB Management Console - Message Viewer" ValidateRequest="false" %>
<%@ Register Src="~/Faults/MessageViewer.ascx" TagName="MessageViewer" TagPrefix="mv" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
   <mv:MessageViewer ID="MessageViewerWebPart" runat="Server"  />
</asp:Content>
