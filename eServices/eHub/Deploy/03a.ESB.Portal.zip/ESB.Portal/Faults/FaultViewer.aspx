<%@ Page 
	Language="C#" 
	MasterPageFile="~/Layout.Master" 
	AutoEventWireup="true" 
	CodeBehind="FaultViewer.aspx.cs" 
	Inherits="Microsoft.Practices.ESB.Portal.Faults.FaultViewer" 
	Title="ESB Management Console - Fault Viewer" %>

<%@ Register Src="~/Faults/FaultViewer.ascx" TagName="FaultViewer" TagPrefix="uc1" %>
<asp:Content 
	ID="Content1" 
	ContentPlaceHolderID="ContentPlaceHolder1" 
	runat="server">
	<uc1:FaultViewer ID="FaultViewer1" runat="server" />
</asp:Content>
