<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="SubscriptionEdit.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Alerts.SubscriptionEdit" %>
<script type="text/javascript" language="javascript" src="../Script/Scripts.js"></script>
<script language="javascript" type="text/javascript">
    // Set the blackout start and end dates. Dates are provided in UTC.
    // They will be converted to local dates and assigned to the respective textboxes.    
    function SetBlackoutDate(startUtcDate, endUtcDate) {   
        var defaultDate = "1/1/1900 12:00:00 AM";
        // We will not show default dates.
        if(startUtcDate != defaultDate) 
        {
            document.getElementById("<%= this.txtBlackoutStart.ClientID %>").value = FormatLocalDate(utcToLocalDate(startUtcDate));        
        }           
        // We will not show default dates.
        if(endUtcDate != defaultDate) 
        {
            document.getElementById("<%= this.txtBlackoutEnd.ClientID %>").value = FormatLocalDate(utcToLocalDate(endUtcDate));
        }
    }
    
    //Calls the SetHiddenBlackoutDate and SetHiddenStartAndEndTimes functions.
    function SetHiddenFields()
    {
      SetHiddenBlakcoutDate();
      SetHiddenStartAndEndTimes();
    }
    
    //Converts the blackout dates that were entered on the page to UTC, and sets them in hidden fields on the page.
     function SetHiddenBlakcoutDate() 
     {        
        document.getElementById("<%= this.hiddenBlackOutStart.ClientID %>").value = FormatDateTime(localToUtcDate(document.getElementById("<%= this.txtBlackoutStart.ClientID %>").value));
        document.getElementById("<%= this.hiddenBlackOutEnd.ClientID %>").value = FormatDateTime(localToUtcDate(document.getElementById("<%= this.txtBlackoutEnd.ClientID %>").value));
      }
    
    //Sets hidden start and end hour and minute variables based on the hour and minute selections in the dropdown lists on the page.  Converts the hours and minutes to UTC before setting them.
    function SetHiddenStartAndEndTimes()
    {
         //Set the start hour and minute
         var startLocalDate = new Date();
         var startLocalHour = document.getElementById("<%= this.ddlStartHour.ClientID %>").value;
         if(document.getElementById("<%= this.ddlStartMeridiem.ClientID %>").value == "PM" && document.getElementById("<%= this.ddlStartHour.ClientID %>").value != 12)
         {
            startLocalHour = parseInt(startLocalHour) + 12;
         }
         var startLocalMinute = document.getElementById("<%= this.ddlStartMin.ClientID %>").value;
         startLocalDate.setHours(startLocalHour);
         startLocalDate.setMinutes(startLocalMinute);
         
        document.getElementById("<%= this.hiddenStartUTCHour.ClientID %>").value = startLocalDate.getUTCHours();
        document.getElementById("<%= this.hiddenStartUTCMinute.ClientID %>").value = startLocalDate.getUTCMinutes();
        
        //Set the end hour and minute
         var endLocalDate = new Date();
         var endLocalHour = document.getElementById("<%= this.ddlEndHour.ClientID %>").value;
         if(document.getElementById("<%= this.ddlEndMeridiem.ClientID %>").value == "PM" && document.getElementById("<%= this.ddlEndHour.ClientID %>").value != 12)
         {
            endLocalHour = parseInt(endLocalHour) + 12;
         }
         var endLocalMinute = document.getElementById("<%= this.ddlEndMinute.ClientID %>").value;
         endLocalDate.setHours(endLocalHour);
         endLocalDate.setMinutes(endLocalMinute);
         
        document.getElementById("<%= this.hiddenEndUTCHour.ClientID %>").value = endLocalDate.getUTCHours();
        document.getElementById("<%= this.hiddenEndUTCMinute.ClientID %>").value = endLocalDate.getUTCMinutes();
    }
   
   
    // Set the start and end utc hour/minute
    function SetStartAndEndTime(startUtcDate, endUtcDate) 
    {
        var startLocalDate = utcToLocalDate(startUtcDate);
        var endLocalDate = utcToLocalDate(endUtcDate);
                
        if(startLocalDate.getHours() > 12) {
            document.getElementById("<%= this.ddlStartMeridiem.ClientID %>").value = "PM";            
            document.getElementById("<%= this.ddlStartHour.ClientID %>").value = startLocalDate.getHours() - 12; // to compensate for the hour we deduct from C# code.   
        } else {
            document.getElementById("<%= this.ddlStartMeridiem.ClientID %>").value = "AM";
            document.getElementById("<%= this.ddlStartHour.ClientID %>").value = startLocalDate.getHours(); // to compensate for the hour we deduct from C# code.
        }        
        document.getElementById("<%= this.ddlStartMin.ClientID %>").value = startLocalDate.getMinutes();

        if(endLocalDate.getHours() > 12) {
            document.getElementById("<%= this.ddlEndMeridiem.ClientID %>").value = "PM";            
            document.getElementById("<%= this.ddlEndHour.ClientID %>").value = endLocalDate.getHours() - 12; // to compensate for the hour we deduct from C# code.       
        } else {
            document.getElementById("<%= this.ddlEndMeridiem.ClientID %>").value = "AM";
            document.getElementById("<%= this.ddlEndHour.ClientID %>").value = startLocalDate.getHours(); // to compensate for the hour we deduct from C# code.
        }        
        document.getElementById("<%= this.ddlEndMinute.ClientID %>").value = endLocalDate.getMinutes();
    }
    
    
    //Confirms that the user wants to delete the subscription, then redirects to the DeleteSubscription page.
    function deleteSubscription()
    {
      if(confirm("Are you sure you want to delete the subscription?"))
      {
         window.location = "DeleteSubscription.aspx?esb:AlertID=<%=this.AlertID %>&esb:SubscriptionID=<%=this.SubscriptionID %>";
      }
    }
</script>
<asp:HiddenField ID="hiddenStartUTCHour" runat="Server" />
<asp:HiddenField ID="hiddenStartUTCMinute" runat="Server" />
<asp:HiddenField ID="hiddenEndUTCHour" runat="Server" />
<asp:HiddenField ID="hiddenEndUTCMinute" runat="Server" />
<h1 class="iconAddSubscriber">Edit Subscription</h1>


<div class="formBody">
	<div class="formHeader">Email Settings</div>
	<div class="formRow">
		<div class="formLabel"></div>
		<div class="formField">
			<asp:RadioButtonList ID="rblUserGroup" runat="server" RepeatDirection="Horizontal">
			<asp:ListItem Text="User" Value="true" Enabled="false" Selected="True"></asp:ListItem>
			<asp:ListItem Text="Group" Value="false" Enabled="false"></asp:ListItem>
			</asp:RadioButtonList>
		</div>
	</div>
	<div class="formRow">
		<label class="formLabel" for="<% Response.Write(txtSubscriber.ID); %>">Subscriber:</label>
		<div class="formField"><asp:TextBox ID="txtSubscriber" runat="server" Width="15em" Enabled="false" /></div>
	</div>
	<div class="formRow">
		<div class="formLabel"></div>
		<div class="formField">
			<asp:CheckBox ID="chkCustomEmail" Text="Custom Email" runat="server" AutoPostBack="True" OnCheckedChanged="chkCustomEmail_CheckedChanged" />
			<asp:TextBox ID="txtCustomEmail" runat="server" Width="20em" Enabled="false" />
		</div>
	</div>
</div>

<div class="formBody">
	<div class="formHeader">Schedule</div>
	<div class="formRow">
		<div class="formLabel"></div>
		<div class="formField"><asp:CheckBox ID="chkUseStartAndEndTime" runat="Server" />Specify start and end time:</div>
	</div>
	<div class="formRow" id="divStartTime">
		<label for="divStartTime" class="formLabel">Start Time:</label>
		<div class="formField">
			<asp:DropDownList ID="ddlStartHour" runat="Server" Width="3em">
			<asp:ListItem Text="1" Value="1" />
			<asp:ListItem Text="2" Value="2" />
			<asp:ListItem Text="3" Value="3" />
			<asp:ListItem Text="4" Value="4" />
			<asp:ListItem Text="5" Value="5" />
			<asp:ListItem Text="6" Value="6" />
			<asp:ListItem Text="7" Value="7" />
			<asp:ListItem Text="8" Value="8" Selected="true" />
			<asp:ListItem Text="9" Value="9" />
			<asp:ListItem Text="10" Value="1" />
			<asp:ListItem Text="11" Value="11" />
			<asp:ListItem Text="12" Value="12" />
			</asp:DropDownList>&#58;<asp:DropDownList ID="ddlStartMin" runat="Server" Width="3em">
			<asp:ListItem Text="00" Value="0" />
			<asp:ListItem Text="15" Value="15" />
			<asp:ListItem Text="30" Value="30" />
			<asp:ListItem Text="45" Value="45" />
			</asp:DropDownList><asp:DropDownList ID="ddlStartMeridiem" runat="Server" Width="3.5em">
			<asp:ListItem Text="AM" Value="AM" Selected="true" />
			<asp:ListItem Text="PM" Value="PM" />
			</asp:DropDownList>
		</div>
	</div>
	<div id="divEndTime" class="formRow">
		<label for="divEndTime" class="formLabel">End Time:</label>
			<div class="formField">
			<asp:DropDownList ID="ddlEndHour" runat="Server" Width="3em">
			<asp:ListItem Text="1" Value="1" />
			<asp:ListItem Text="2" Value="2" />
			<asp:ListItem Text="3" Value="3" />
			<asp:ListItem Text="4" Value="4" />
			<asp:ListItem Text="5" Value="5" Selected="true"/>
			<asp:ListItem Text="6" Value="6" />
			<asp:ListItem Text="7" Value="7" />
			<asp:ListItem Text="8" Value="8" />
			<asp:ListItem Text="9" Value="9" />
			<asp:ListItem Text="10" Value="10" />
			<asp:ListItem Text="11" Value="11" />
			<asp:ListItem Text="12" Value="12" />
			</asp:DropDownList>&#58;<asp:DropDownList ID="ddlEndMinute" runat="Server" Width="3em">
			<asp:ListItem Text="00" Value="0" />
			<asp:ListItem Text="15" Value="15" />
			<asp:ListItem Text="30" Value="30" />
			<asp:ListItem Text="45" Value="45" />
			</asp:DropDownList><asp:DropDownList ID="ddlEndMeridiem" runat="Server" Width="3.5em">
			<asp:ListItem Text="AM" Value="AM" />
			<asp:ListItem Text="PM" Value="PM" Selected="true" />
			</asp:DropDownList>
		</div>
	</div>
	<div class="formRow">
		<label class="formLabel" for="divBlackout">Black-out Period:</label>
		<div class="formField">
		Start <asp:TextBox ID="txtBlackoutStart" runat="server" Width="7em"></asp:TextBox>&nbsp;
		End <asp:TextBox ID="txtBlackoutEnd" runat="server" Width="7em"></asp:TextBox><br />
		<div class="formSmallText">Enter dates in MM/DD/YYYY format.</div>
		</div>
	</div>

	<div class="formRow" id="divInterval">
		<label class="formLabel" for="divInterval">Interval Minutes:</label>
		<div class="formField">
		<asp:DropDownList ID="ddlInterval" runat="server">
			<asp:ListItem Text="0 minutes" Value="0" />
			<asp:ListItem Text="15 minutes" Value="15" />
			<asp:ListItem Text="1 hour" Value="60" />
			<asp:ListItem Text="4 hours" Value="240" />
			<asp:ListItem Text="8 hours" Value="320" />
		</asp:DropDownList><br />
		<div class="formSmallText">Suppress new alerts matching this subscription</div>
		</div>
	</div>
</div>

<div class="formSubmit">
	<input type="hidden" id="hiddenBlackOutStart" runat="server" />
	<input type="hidden" id="hiddenBlackOutEnd" runat="server" />
	<asp:Button ID="btnEdit" Width="70px" runat="server" Text="Save" OnClientClick="return SetHiddenFields();" OnClick="btnEdit_Click" class="formButton" />&nbsp;
	<button id="btnDelete" Width="70px" onclick="deleteSubscription()" class="formButton">Delete</button>&nbsp;
	<button id="btnCancel" Width="70px" onclick="return cancelNavigation();" class="formButton">Cancel</button>
</div>

<script language="javascript" type="text/javascript">
    function cancelNavigation() {        
        document.location.href = '<%= this.ResolveUrl("Alerts.aspx") %>';
        return true;
    }
</script>