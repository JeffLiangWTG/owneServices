//---------------------------------------------------------------------
// File: Alerts.aspx.cs
// 
// Summary: This page displays a list of alerts all the alerts in the 
//          portal.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using ESB.Exceptions.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Alerts
{
    /// <summary>
    /// Base class for the Alerts page.
    /// </summary>
    public partial class Alerts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IExceptionService client = null;
                try
                {
                    client = PortalHelper.GetExceptionService();

                    List<AlertSubscription> subscriptions = client.GetAlertSubscriptionsBySubscriber(User.Identity.Name);
                    DataSets.Alerts alerts = new Microsoft.Practices.ESB.Portal.DataSets.Alerts();
                    SubscriptionsList1.AlertSubscriptions = alerts.GetAlertSubscriptionsView(subscriptions);
                    SubscriptionsList1.IsAdmin = false;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }
        }

        protected void AlertList1_Load(object sender, EventArgs e)
        {
            this.AlertList1.ApplyStyleSheetSkin(this.Page);
        }
    }
}
