//---------------------------------------------------------------------
// File: AlertAdd.aspx.cs
// 
// Summary: This page provides users the ability to create new alerts.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Text;
using ESB.Exceptions.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Alerts
{
    /// <summary>
    /// Base class for the AlertAdd page.
    /// 
    /// </summary>
    public partial class AlertAdd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session.Remove("AlertDataSet"); //TODO: use constant
                //create new alert
                alerts = new Microsoft.Practices.ESB.Portal.DataSets.Alerts();
                alerts.Alert.AddAlertRow(Guid.NewGuid(), string.Empty, string.Empty, User.Identity.Name, 0, 0, DateTime.UtcNow);
                Session.Add("AlertDataSet", alerts);
            }
            else
            {
                alerts = (Microsoft.Practices.ESB.Portal.DataSets.Alerts)Session["AlertDataSet"];
            }

            TheConditionAdd.AlertsDataSet = alerts;
            TheConditionList.AlertConditions = alerts.AlertCondition;
            ownerName.Text = User.Identity.Name.ToString();
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (this.IsPostBack)
            {
                this.noNameErrorMessage.Visible = string.IsNullOrEmpty(txtName.Text);
            }
        }

        private Microsoft.Practices.ESB.Portal.DataSets.Alerts alerts;

        public Microsoft.Practices.ESB.Portal.DataSets.Alerts AlertsDataSet
        {
            get { return alerts; }
            set { alerts = value; }
        }

        private void noConditionsCheck()
        {
            this.noConditionsErrorMessage.Visible = !(alerts.AlertCondition.Count > 0);
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            if (alerts.AlertCondition.Count > 0 && !string.IsNullOrEmpty(txtName.Text))
            {
                Microsoft.Practices.ESB.Portal.DataSets.Alerts.AlertRow newAlert = alerts.Alert[0];
                newAlert.Name = txtName.Text;

                //build conditions string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < alerts.AlertCondition.Count; i++)
                {
                    Microsoft.Practices.ESB.Portal.DataSets.Alerts.AlertConditionRow acr = alerts.AlertCondition[i];

                    sb.AppendFormat(" {0} {1} '{2}{3}{2}'", acr.LeftSide, acr.Operator, acr.Operator == "like" ? "%" : string.Empty,
                        acr.RightSide.Replace("'", "''"));

                    if (i < alerts.AlertCondition.Count - 1) sb.AppendFormat(" AND");
                }
                // hook service instead of using the dataset
                IExceptionService client = null;
                try
                {
                    client = PortalHelper.GetExceptionService();

                    client.InsertAlert(new Alert()
                    {
                        AlertID = newAlert.AlertID,
                        ConditionsString = sb.ToString(),
                        Name = newAlert.Name,
                        InsertedBy = newAlert.InsertedBy,
                        InsertedDate = newAlert.InsertedDate
                    });

                    foreach (Microsoft.Practices.ESB.Portal.DataSets.Alerts.AlertConditionRow ac in alerts.AlertCondition.Rows)
                    {
                        client.InsertAlertCondition(new AlertCondition()
                        {
                            AlertConditionID = Guid.NewGuid(),
                            AlertID = newAlert.AlertID,
                            InsertedDate = newAlert.InsertedDate,
                            LeftSide = ac.LeftSide,
                            RightSide = ac.RightSide,
                            Operator = ac.Operator
                        });
                    }

                    Session.Remove("AlertDataSet");
                    Response.Redirect("AlertViewer.aspx?esb:AlertID=" + alerts.Alert[0].AlertID.ToString());
                }
                catch (Exception)
                {
                    this.noNameErrorMessage.Visible = true;
                    this.noNameErrorMessage.Text = "Could not create record - Alert name already exists!";
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }
            else
            {
                this.noConditionsErrorMessage.Visible = !(alerts.AlertCondition.Count > 0);
            }
        }
    }
}