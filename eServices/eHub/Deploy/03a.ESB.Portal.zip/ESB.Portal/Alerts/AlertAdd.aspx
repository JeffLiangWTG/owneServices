<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="AlertAdd.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Alerts.AlertAdd" Title="ESB Management Console - Add Alert" %>

<%@ Register Src="../Lists/ConditionList.ascx" TagName="ConditionList" TagPrefix="uc1" %>
<%@ Register Src="ConditionAdd.ascx" TagName="ConditionAdd" TagPrefix="uc2" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<h1 class="iconAlert">Add Alert</h1>
	<br />
	<br />
	<div class="formBody">
		<div class="formRow">
			<div class="formLabel">Enter Alert Name:</div>
			<div class="formField">
				<asp:TextBox ID="txtName" CssClass="formFieldInput" runat="server" Width="200px" />
				<asp:Label ID="noNameErrorMessage" ForeColor="Red" Visible="false" runat="Server">Please enter an alert name.</asp:Label>
                <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtName">Please enter an alert name.</asp:RequiredFieldValidator><br />
            </div>
		</div>
	</div>
	<div class="formBody">
		<div class="formRow">
			<div class="formLabel">Enter Owner:</div>
			<div class="formField">
				<asp:Label ID="ownerName" Visible="true" runat="Server"></asp:Label><br />
            </div>
		</div>
	</div>
		
	<div class="formBody" style="width:1220px">
		<div class="formHeader">Add conditions for this alert</div>
		
		<!-- Add Condition Start -->
		<uc2:ConditionAdd ID="TheConditionAdd" runat="server" />
		<!-- Add Condition End -->

		
		<uc1:ConditionList ID="TheConditionList" runat="server" />

		<div style="clear: both; padding-top: 10px;">
			<asp:Label ID="noConditionsErrorMessage" ForeColor="Red" Visible="false" runat="Server">At least one condition is required.<br/></asp:Label>
		</div>
	</div>
	
	<p><asp:Button Text="Save" ID="btnCreate" runat="server" Width="70px" CssClass="formButton" OnClick="btnCreate_Click" /></p>

</asp:Content>
