//---------------------------------------------------------------------
// File: DeleteSubscription.aspx.cs
// 
// Summary: Deletes a subscription by AlertID and SubscriptionID.  The
//          AlertID and SubscriptionID are supplied through the querystring.
//          Once the subscription has been deleted, the user is redirected
//          back to the Alerts.aspx page.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Web.UI;
using ESB.Exceptions.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Alerts
{
    public partial class DeleteSubscription : System.Web.UI.Page
    {
        private Guid AlertID
        {
            get
            {
                return new Guid(Request.QueryString["esb:AlertID"]);
            }
        }

        private Guid SubscriptionID
        {
            get
            {
                return new Guid(Request.QueryString["esb:SubscriptionID"]);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                IExceptionService client = null;
                try
                {
                    client = PortalHelper.GetExceptionService();

                    client.DeleteAlertSubscriptionById(this.SubscriptionID);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }

                Response.Redirect("~/Alerts/Alerts.aspx");
            }
        }
    }
}