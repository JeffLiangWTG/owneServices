//---------------------------------------------------------------------
// File: SubscriptionEdit.aspx.cs
// 
// Summary: This user control allows users and administrators to edit
//          subscriptions.  
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Web;
using System.Web.UI;
using ESB.Exceptions.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Alerts
{
    public partial class SubscriptionEdit : System.Web.UI.UserControl
    {
        protected Guid AlertID
        {
            get
            {
                return new Guid(Request.QueryString["esb:AlertID"]);
            }
        }

        protected Guid SubscriptionID
        {
            get
            {
                return new Guid(Request.QueryString["ID"]);
            }
        }

        /// <summary>
        /// View state key that is used to access the IsAdmin property.
        /// </summary>
        private const string VS_KEY_ISADMIN = "IsAdmin";

        /// <summary>
        /// Determines whether the control is being viewed by an admin or not.
        /// Default is false.
        /// </summary>
        public bool IsAdmin
        {
            get
            {
                if(ViewState[VS_KEY_ISADMIN] == null) {
                    return false;
                }
                return (bool)ViewState[VS_KEY_ISADMIN];
            }
            set
            {
                ViewState[VS_KEY_ISADMIN] = value;
            }
        }

        private AlertSubscription GetAlertSubscription()
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();
                AlertSubscription subscription = client.GetAlertSubscriptionById(SubscriptionID);

                if (subscription == null)
                {
                    throw new ArgumentException("The subscription doesn't exist");
                }

                return subscription;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                this.rblUserGroup.Visible = this.IsAdmin;
                this.rblUserGroup.Enabled = this.IsAdmin;
                this.rblUserGroup.Items[0].Enabled = this.IsAdmin;
                this.rblUserGroup.Items[1].Enabled = this.IsAdmin;
                this.txtSubscriber.Enabled = this.IsAdmin;

                AlertSubscription subscription = GetAlertSubscription();

                if (subscription.IsGroup)
                {
                    rblUserGroup.Items[1].Selected = true;
                    rblUserGroup.Items[1].Value = "true";
                }
                else
                {
                    rblUserGroup.Items[0].Selected = true;
                    rblUserGroup.Items[0].Value = "true";
                }

                txtSubscriber.Text = subscription.Subscriber;
                if (!string.IsNullOrEmpty(subscription.CustomEmail))
                {
                    chkCustomEmail.Checked = txtCustomEmail.Enabled = true;
                    txtCustomEmail.Text = subscription.CustomEmail;
                }
                ddlInterval.SelectedValue = subscription.IntervalMinutes.ToString();

                string blackOutDateScript = @"<script language=""javascript"">SetBlackoutDate('" + subscription.BlackOutStartDate + "','" + subscription.BlackOutEndDate + "');</script>";
                if (!Page.ClientScript.IsStartupScriptRegistered(this.GetType(), "BlackOutDateSet"))
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "BlackOutDateSet", blackOutDateScript);
                }

                this.chkUseStartAndEndTime.Checked = Convert.ToBoolean(subscription.UseStartAndEndTime);
                DateTime startUtcDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, (int)subscription.StartUTCHour.Value, (int)subscription.StartUTCMinute.Value, 0);
                DateTime endUtcDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, (int)subscription.EndUTCHour.Value, (int)subscription.EndUTCMinute.Value, 0);
                string startEndDateScript = @"<script language=""javascript"">SetStartAndEndTime('" + startUtcDate + "','" + endUtcDate + "');</script>";
                if (!Page.ClientScript.IsStartupScriptRegistered(this.GetType(), "StartEndDateSet"))
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "StartEndDateSet", startEndDateScript);
                }
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();

                AlertSubscription subscription = GetAlertSubscription();

                DateTime blackOutStartDate =
                  (this.txtBlackoutStart.Text.Trim().Length == 0)
                  ? new DateTime(1900, 1, 1)
                  : Convert.ToDateTime(string.Format("{0:MM/dd/yyyy 00:00:00}", this.hiddenBlackOutStart.Value));

                DateTime blackOutEndDate =
                    (this.txtBlackoutEnd.Text.Trim().Length == 0)
                    ? new DateTime(1900, 1, 1)
                    : Convert.ToDateTime(string.Format("{0:MM/dd/yyyy 00:00:00}", this.hiddenBlackOutEnd.Value));

                subscription.Active = true;
                subscription.Subscriber = this.txtSubscriber.Text.Trim();

                subscription.IsGroup = rblUserGroup.Items[1].Selected;
                subscription.CustomEmail = this.txtCustomEmail.Text.Trim();
                subscription.UseStartAndEndTime = this.chkUseStartAndEndTime.Checked;
                subscription.StartUTCHour = (byte)(Convert.ToInt16(this.hiddenStartUTCHour.Value));
                subscription.StartUTCMinute = (byte)(Convert.ToInt16(this.hiddenStartUTCMinute.Value));
                subscription.EndUTCHour = (byte)(Convert.ToInt16(this.hiddenEndUTCHour.Value));
                subscription.EndUTCMinute = (byte)(Convert.ToInt16(this.hiddenEndUTCMinute.Value));
                subscription.BlackOutStartDate = blackOutStartDate;
                subscription.BlackOutEndDate = blackOutEndDate;
                subscription.IntervalMinutes = Convert.ToInt16(this.ddlInterval.SelectedValue.Trim());
                subscription.ModifiedBy = HttpContext.Current.User.Identity.Name;
                subscription.LastFired = DateTime.UtcNow;

                client.UpdateAlertSubscription(subscription);
                Response.Redirect("Alerts.aspx");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }

        protected void chkCustomEmail_CheckedChanged(object sender, EventArgs e)
        {
            this.txtCustomEmail.Enabled = this.chkCustomEmail.Checked;
            if(!this.chkCustomEmail.Checked) {
                this.txtCustomEmail.Text = string.Empty;
            }
        }
    }
}