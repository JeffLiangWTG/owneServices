//---------------------------------------------------------------------
// File: SubscriptionAdd.ascx.cs
// 
// Summary: This control allows the user to add subscriptions for a particular alert.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Web;
using System.Web.UI;
using ESB.Exceptions.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Alerts
{
    public partial class SubscriptionAdd : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack) 
            {
                this.txtSubscriber.Text = HttpContext.Current.User.Identity.Name;
                this.rblUserGroup.Visible = this.IsAdmin;
                this.AdminPanel.Visible = this.IsAdmin;
            }
        }

        /// <summary>
        /// View state key that is used to access the IsAdmin property.
        /// </summary>
        private const string VS_KEY_ISADMIN = "IsAdmin";

        /// <summary>
        /// Determines whether the control is being viewed by an admin or not.
        /// Default is false.
        /// </summary>
        public bool IsAdmin
        {
            get
            {
                if(ViewState[VS_KEY_ISADMIN] == null) {
                    return false;
                }
                return (bool)ViewState[VS_KEY_ISADMIN];
            }
            set
            {
                ViewState[VS_KEY_ISADMIN] = value;
            }
        }

        public string AlertID
        {
            get { return (string)ViewState["AlertID"] ?? string.Empty; }
            set { ViewState["AlertID"] = value; }
        }

        protected void chkCustomEmail_CheckedChanged(object sender, EventArgs e)
        {
            this.txtCustomEmail.Enabled = this.chkCustomEmail.Checked;
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            IExceptionService client = null;
            try
            {
                if (string.IsNullOrEmpty(Request.QueryString["esb:AlertID"]))
                {
                    throw new ArgumentException("The alert doesn't exist");
                }

                Guid alertID = new Guid(Request.QueryString["esb:AlertID"]);

                DateTime blackOutStartDate =
                    (this.txtBlackoutStart.Text.Trim().Length == 0)
                    ? new DateTime(1900, 1, 1)
                    : Convert.ToDateTime(string.Format("{0:MM/dd/yyyy 00:00:00}", this.hiddenBlackOutStart.Value));

                DateTime blackOutEndDate =
                    (this.txtBlackoutEnd.Text.Trim().Length == 0)
                    ? new DateTime(1900, 1, 1)
                    : Convert.ToDateTime(string.Format("{0:MM/dd/yyyy 00:00:00}", this.hiddenBlackOutEnd.Value));

                client = PortalHelper.GetExceptionService();

                Alert alert = client.GetAlertById(alertID);

                if (alert == null)
                {
                    throw new ArgumentException("The alert doesn't exist");
                }

                AlertSubscription alertSubscription = new AlertSubscription()
                {
                    AlertSubscriptionID = Guid.NewGuid(),
                    Active = true,
                    AlertID = alert.AlertID,
                    BlackOutEndDate = blackOutEndDate,
                    BlackOutStartDate = blackOutStartDate,
                    CustomEmail = txtCustomEmail.Text,
                    StartUTCHour = (byte)(Convert.ToInt16(this.hiddenStartUTCHour.Value)),
                    StartUTCMinute = (byte)(Convert.ToInt16(this.hiddenStartUTCMinute.Value)),
                    InsertedBy = HttpContext.Current.User.Identity.ToString(),
                    InsertedDate = DateTime.UtcNow,
                    IsGroup = bool.Parse(this.rblUserGroup.SelectedValue),
                    LastFired = DateTime.Today,
                    Subscriber = txtSubscriber.Text,
                    UseStartAndEndTime = this.chkUseStartAndEndTime.Checked,
                    EndUTCHour = (byte)(Convert.ToInt16(this.hiddenEndUTCHour.Value)),
                    EndUTCMinute = (byte)(Convert.ToInt16(this.hiddenEndUTCMinute.Value)),
                    ModifiedBy = HttpContext.Current.User.Identity.Name
                };

                client.InsertAlertSubscription(alertSubscription);

                Response.Redirect("Alerts.aspx");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }
    }
}