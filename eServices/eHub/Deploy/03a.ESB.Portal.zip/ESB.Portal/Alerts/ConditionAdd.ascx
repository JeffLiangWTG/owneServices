<%@ Control Language="C#" AutoEventWireup="true" Codebehind="ConditionAdd.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Alerts.ConditionAdd" %>

<div class="formRow">
	<div class="formLabel" style="width:800px;">
        <table>
            <tr>
                <td style="width:150px;">
                    Criteria:</td>
                <td style="width:85px;">
                    Operator:</td>
                <td style="width:150px;">
                    Value:</td>
                <td style="width:300px;">
                </td>
            </tr>
            <tr>
                <td style="width: 150px;">
		            <asp:DropDownList ID="ddlLeftSide" runat="server" AutoPostBack="True" OnSelectedIndexChanged="ddlLeftSide_SelectedIndexChanged">
			            <asp:ListItem Text="Application" Value="Application" />
			            <asp:ListItem Text="Error Type" Value="ErrorType" />
			            <asp:ListItem Text="Failure Category" Value="FailureCategory" />
			            <asp:ListItem Text="Fault Code" Value="FaultCode" />
			            <asp:ListItem Text="Fault Generator" Value="FaultGenerator" />
			            <asp:ListItem Text="Fault Severity" Value="FaultSeverity" />
			            <asp:ListItem Text="Machine Name" Value="MachineName" />
			            <asp:ListItem Text="Scope" Value="Scope" />
			            <asp:ListItem Text="Service Name" Value="ServiceName" />
		            </asp:DropDownList></td>
                <td style="width: 85px;">
		            <asp:DropDownList ID="ddlOperator" runat="server">
			            <asp:ListItem Text="=" Value="=" />
			            <asp:ListItem Text="!=" Value="!=" />
			            <asp:ListItem Text="&lt;" Value="&lt;" />
			            <asp:ListItem Text="&gt;" Value="&gt;" />
			            <asp:ListItem Text="&lt;=" Value="&lt;=" />
			            <asp:ListItem Text="&gt;=" Value="&gt;=" />
			            <asp:ListItem Text="like" Value="like" />
		            </asp:DropDownList></td>
                <td style="width:150px;">
		            <asp:DropDownList ID="ddlApplications" runat="server" Visible="False" />
		            <asp:DropDownList ID="ddlFaultGenerator" runat="server" Visible="False" >
			            <asp:ListItem Text="Messaging" Value="Messaging" />
			            <asp:ListItem Text="Orchestration" Value="Orchestration" />
		            </asp:DropDownList>
                    <asp:TextBox ID="txtRightSide" runat="Server" Width="12em" Font-Size="1em" />
                    <asp:DropDownList ID="ddlServiceNames" runat="server" Visible="False" />
                </td>
                <td style="width:300px;">
	                <asp:ImageButton ID="imgAddCondition" ImageUrl="~/Images/Icons/16_new.gif" runat="server" OnClick="btnAddCondition_Click" />
	                <asp:LinkButton ID="linkAddCondition" Text="Add" OnClick="btnAddCondition_Click" runat="server" ToolTip="Add" />
	            </td>
            </tr>
        </table>
    </div>
</div>
<div style="clear:both; padding-left: 2px;">
</div>
