//---------------------------------------------------------------------
// File: ConditionAdd.ascx.cs
// 
// Summary: This page has the logic for adding conditions.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Web.UI;

namespace Microsoft.Practices.ESB.Portal.Alerts
{
    public partial class ConditionAdd : System.Web.UI.UserControl
    {
        private DataSets.Alerts alerts;

        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack) 
            {
                SetRightSide();
            }
        }

        public DataSets.Alerts AlertsDataSet
        {
            get { return alerts; }
            set { alerts = value; }
        }

        protected void btnAddCondition_Click(object sender, EventArgs e)
        {
            if (ddlLeftSide.SelectedItem != null)
            {
                if(ddlLeftSide.SelectedValue.Equals("Application")) {
                    //add to dataset
                    alerts.AlertCondition.AddAlertConditionRow(Guid.NewGuid(), alerts.Alert[0],
                        ddlLeftSide.SelectedValue, ddlApplications.SelectedValue, ddlOperator.SelectedValue);
                    ddlApplications.SelectedIndex = 0;
                } else if(ddlLeftSide.SelectedValue.Equals("ServiceName")) {
                    //add to dataset
                    alerts.AlertCondition.AddAlertConditionRow(Guid.NewGuid(), alerts.Alert[0],
                        ddlLeftSide.SelectedValue, ddlServiceNames.SelectedValue, ddlOperator.SelectedValue);
                    ddlServiceNames.SelectedIndex = 0;
                } else if(ddlLeftSide.SelectedValue.Equals("FaultGenerator")) {
                    //add to dataset
                    alerts.AlertCondition.AddAlertConditionRow(Guid.NewGuid(), alerts.Alert[0],
                        ddlLeftSide.SelectedValue, ddlFaultGenerator.SelectedValue, ddlOperator.SelectedValue);
                    ddlFaultGenerator.SelectedIndex = 0;
                } else if(!string.IsNullOrEmpty(txtRightSide.Text.Trim())) {
                    //add to dataset
                    alerts.AlertCondition.AddAlertConditionRow(Guid.NewGuid(), alerts.Alert[0],
                        ddlLeftSide.SelectedValue, txtRightSide.Text, ddlOperator.SelectedValue);
                    //clear                    
                    txtRightSide.Text = string.Empty;
                }
               
                ddlOperator.SelectedIndex = 0;                
            }
        }

        private void LoadApplications()
        {
            this.ddlApplications.Visible = true;
            this.txtRightSide.Visible = false;
            this.ddlServiceNames.Visible = false;
            this.ddlFaultGenerator.Visible = false;

            //Call the BTQuery Service
            List<BizTalkOperationsService.BTApplication> applications = PortalHelper.GetAllApplications();

            //Populate the applications list with the applications from BizTalk                
            this.ddlApplications.DataSource = applications;
            this.ddlApplications.DataTextField = "Name";
            this.ddlApplications.DataValueField = "Name";
            this.ddlApplications.DataBind();
        }

        private void LoadServiceNames()
        {
            this.ddlApplications.Visible = false;
            this.txtRightSide.Visible = false;
            this.ddlServiceNames.Visible = true;
            this.ddlFaultGenerator.Visible = false;

            //Call the BTQuery Service
            List<string> serviceNames = PortalHelper.GetServiceNames();
            this.ddlServiceNames.DataSource = serviceNames;
            this.ddlServiceNames.DataBind();
        }
        
        protected void ddlLeftSide_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetRightSide();
        }

        private void SetRightSide()
        {
            if(ddlLeftSide.SelectedValue.Equals("Application")) {
                LoadApplications();
            } else if(ddlLeftSide.SelectedValue.Equals("ServiceName")) {
                LoadServiceNames();
            } else if(ddlLeftSide.SelectedValue.Equals("FaultGenerator")) {
                this.ddlServiceNames.Visible = false;
                this.ddlApplications.Visible = false;
                this.ddlFaultGenerator.Visible = true;
                this.txtRightSide.Visible = false;
            } else {
                this.ddlServiceNames.Visible = false;
                this.ddlApplications.Visible = false;
                this.txtRightSide.Visible = true;
                this.ddlFaultGenerator.Visible = false;
            }
        }
    }
}