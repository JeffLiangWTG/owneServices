<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="AddSubscriptions.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Alerts.AddSubscriptions" Title="ESB Management Console - Add Subscriptions" %>
<%@ Register Src="~/Alerts/SubscriptionAdd.ascx" TagName="AddSubscription" TagPrefix="ESB" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div>
        <ESB:AddSubscription ID="addSubscriptionControl" IsAdmin="false" runat="server"  />
    </div>
</asp:Content>
