<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="AlertEdit.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Alerts.AlertEdit" Title="ESB Management Console - Edit Alert"%>
<%@ Register Src="../Lists/ConditionList.ascx" TagName="ConditionList" TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<h1 class="iconAlert">
		Edit Alert</h1>
	<br />
	<br />
	<div class="formBody">
		<div class="formRow">
			<div class="formLabel">
				Enter Alert Name:</div>
			<div class="formField">
				<asp:TextBox ID="txtName" CssClass="formFieldInput" runat="server" Width="200px" />
				<asp:Label ID="noNameErrorMessage" ForeColor="Red" Visible="false" runat="Server">Please enter an alert name.</asp:Label>
				<asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" ControlToValidate="txtName">Please enter an alert name.</asp:RequiredFieldValidator><br />
			</div>
		</div>
	</div>
	<div class="formBody">
		<div class="formRow">
			<div class="formLabel">
				Enter Owner:</div>
			<div class="formField">
				<asp:Label ID="ownerName" Visible="true" runat="Server"><%# GetOwnerName() %></asp:Label><br />
			</div>
		</div>
	</div>
	<div class="formBody" style="width: 1220px">
		<div class="formHeader">
			Add conditions for this alert</div>
		<!-- Add Condition Start -->
		<div class="formRow">
			<div class="formLabel" style="width: 800px;">
				<table>
					<tr>
						<td style="width: 150px;">
							Criteria:</td>
						<td style="width: 85px;">
							Operator:</td>
						<td style="width: 150px;">
							Value:</td>
						<td style="width: 300px;">
						</td>
					</tr>
					<tr>
						<td style="width: 150px;">
							<asp:DropDownList ID="ddlLeftSide" runat="server" AutoPostBack="True" OnSelectedIndexChanged="ddlLeftSide_SelectedIndexChanged">
								<asp:ListItem Text="Application" Value="Application" />
								<asp:ListItem Text="Error Type" Value="ErrorType" />
								<asp:ListItem Text="Failure Category" Value="FailureCategory" />
								<asp:ListItem Text="Fault Code" Value="FaultCode" />
								<asp:ListItem Text="Fault Generator" Value="FaultGenerator" />
								<asp:ListItem Text="Fault Severity" Value="FaultSeverity" />
								<asp:ListItem Text="Machine Name" Value="MachineName" />
								<asp:ListItem Text="Scope" Value="Scope" />
								<asp:ListItem Text="Service Name" Value="ServiceName" />
							</asp:DropDownList></td>
						<td style="width: 85px;">
							<asp:DropDownList ID="ddlOperator" runat="server">
								<asp:ListItem Text="=" Value="=" />
								<asp:ListItem Text="!=" Value="!=" />
								<asp:ListItem Text="&lt;" Value="&lt;" />
								<asp:ListItem Text="&gt;" Value="&gt;" />
								<asp:ListItem Text="&lt;=" Value="&lt;=" />
								<asp:ListItem Text="&gt;=" Value="&gt;=" />
								<asp:ListItem Text="like" Value="like" />
							</asp:DropDownList></td>
						<td style="width: 150px;">
							<asp:DropDownList ID="ddlApplications" runat="server" Visible="False" />
							<asp:DropDownList ID="ddlFaultGenerator" runat="server" Visible="False">
								<asp:ListItem Text="Messaging" Value="Messaging" />
								<asp:ListItem Text="Orchestration" Value="Orchestration" />
							</asp:DropDownList>
							<asp:TextBox ID="txtRightSide" runat="Server" Width="12em" Font-Size="1em" />
							<asp:DropDownList ID="ddlServiceNames" runat="server" Visible="False" />
						</td>
						<td style="width: 300px;">
							<asp:ImageButton ID="imgAddCondition" ImageUrl="~/Images/Icons/16_new.gif" runat="server" OnClick="btnAddCondition_Click" />
							<asp:LinkButton ID="linkAddCondition" Text="Add" OnClick="btnAddCondition_Click" runat="server" ToolTip="Add" />
						</td>
					</tr>
				</table>
			</div>
		</div>
		<div style="clear: both; padding-left: 2px;">
		</div>
		<uc1:ConditionList ID="TheConditionList" runat="server" />
		<div style="clear: both; padding-top: 10px;">
			<asp:Label ID="noConditionsErrorMessage" ForeColor="Red" Visible="false" runat="Server">At least one condition is required.<br/></asp:Label>
		</div>
	</div>
	<p>
		<asp:Button Text="Save" ID="btnCreate" runat="server" Width="70px" CssClass="formButton" OnClick="btnCreate_Click" />
		<asp:Button Text="Cancel" ID="Button1" runat="server" Width="70px" CssClass="formButton" OnClick="Button1_Click" /></p>
</asp:Content>
