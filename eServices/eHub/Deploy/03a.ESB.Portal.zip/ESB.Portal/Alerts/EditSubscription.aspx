<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="EditSubscription.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Alerts.EditSubscription" Title="ESB Management Console - Edit Subscription"%>
<%@ Register Src="~/Alerts/SubscriptionEdit.ascx" TagName="EditSubscription" TagPrefix="ESB" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div>
        <ESB:EditSubscription ID="editSubscriptionControl" runat="server" />
    </div>
</asp:Content>