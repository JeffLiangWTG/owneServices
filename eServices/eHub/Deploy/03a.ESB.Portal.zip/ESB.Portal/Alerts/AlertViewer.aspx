<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="AlertViewer.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Alerts.AlertViewer" Title="ESB Management Console - Alert Viewer" %>

<%@ Register Src="../Lists/ConditionList.ascx" TagName="ConditionList" TagPrefix="esb" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<h1 class="iconAlert">
		Alert Viewer</h1>
	<table border="0" cellpadding="4" cellspacing="0">
		<tr>
			<td>
				<h2 class="label">
					Name:</h2>
			</td>
			<td>
				<h2 class="labelvalue">
					<asp:Label ID="lblName" runat="server">Alert Name</asp:Label></h2>
			</td>
		</tr>
		<tr>
			<td>
				<h2 class="label">
					Owner:</h2>
			</td>
			<td>
				<h2 class="labelvalue">
					<asp:Label ID="lblOwner" runat="server"></asp:Label></h2>
			</td>
		</tr>
		<tr>
			<td>
				<h2 class="label">
					Create Date:</h2>
			</td>
			<td>
				<h2 class="labelvalue">
					<asp:Label ID="lblCreateDate" runat="server"></asp:Label></h2>
			</td>
		</tr>
	</table>
	<div style="float: left; width: 590px;">
		<h3>
			Conditions</h3>
		<table cellspacing="0" cellpadding="0" border="0" width="100%">
			<tr class="tableHeader">
				<th>
					Condition List</th>
			</tr>
			<tr>
				<td>
					<asp:Repeater ID="repeaterCondiations" runat="server">
						<ItemTemplate>
							<div class="itemList">
								<asp:Label Width="85px" ID="labelLeftSide" runat="server" />&nbsp;&nbsp;
								<asp:Label Width="15px" ID="labelOperator" runat="server" />&nbsp;&nbsp;
								<asp:Label ID="labelRightSide" runat="server" />
							</div>
						</ItemTemplate>
					</asp:Repeater>
				</td>
			</tr>
		</table>
	</div>
	<div style="float: left; width: 590px; padding-left: 10px;">
		<h3>
			Subscriptions</h3>
		<table cellspacing="0" cellpadding="0" border="0" width="100%">
			<tr class="tableHeader">
				<th colspan="3">
					Subscribers</th>
			</tr>
			<asp:Repeater ID="repeaterSubscriptions" runat="server">
				<ItemTemplate>
					<tr class="tableRow">
						<td width="18">
							<img src="../Images/Icons/16_subscribe.gif" />
						</td>
						<td>
							<asp:Label ID="labelSubscriber" runat="server" />
						</td>
						<td width="50">
							<img src="../Images/Icons/16_edit.gif" />
							<asp:HyperLink ID="linkEditSubscription" runat="server" Text="Edit" ToolTip="Edit" />
						</td>
					</tr>
				</ItemTemplate>
			</asp:Repeater>
		</table>
		<p>
			<img src="../Images/Icons/16_new.gif" />
			<asp:HyperLink ID="linkAddSubscriptions" runat="server">Add Subscriptions</asp:HyperLink>
		</p>
	</div>
	<p>
		<asp:Button ID="deleteButton" runat="server" Text="Delete Alert" OnClick="deleteButton_Click" Visible="false" />
		<asp:Label ID="deleteMessageLabel" runat="server" Visible="false" />
	</p>
	<br clear="all" />
	<div>
		<a href="../Alerts/Alerts.aspx">< Back to Alerts</a>
	</div>
</asp:Content>
