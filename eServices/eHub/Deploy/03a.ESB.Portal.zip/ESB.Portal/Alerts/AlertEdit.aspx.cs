//---------------------------------------------------------------------
// File: AlertAdd.aspx.cs
// 
// Summary: This page provides users the ability to create new alerts.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using ESB.Exceptions.Service.Implementation;
using System.Text;

namespace Microsoft.Practices.ESB.Portal.Alerts
{
    public partial class AlertEdit : System.Web.UI.Page
    {
        DataSets.Alerts.AlertRow alertRow = null;
        DataSets.Alerts.AlertConditionDataTable alertConditions = null;
        Alert alert = null;
        Microsoft.Practices.ESB.Portal.DataSets.Alerts alerts;
        List<AlertCondition> alertConditionEntities = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                SetRightSide();


                Guid alertID = new Guid(Request["esb:AlertID"].ToString());

                IExceptionService client = null;

                try
                {
                    alerts = new Microsoft.Practices.ESB.Portal.DataSets.Alerts();
                    client = PortalHelper.GetExceptionService();

                    alert = client.GetAlertById(alertID);

                    alertConditionEntities = client.GetAlertConditionsByAlertId(alertID);

                    //DataSets.AlertsTableAdapters.AlertTableAdapter alertTableAdapter = new Microsoft.Practices.ESB.Portal.DataSets.AlertsTableAdapters.AlertTableAdapter();

                    //DataSets.Alerts.AlertDataTable alertTable = alertTableAdapter.GetData(alertID);
                    //alertRow = (DataSets.Alerts.AlertRow)alertTable.Rows[0];

                    //DataSets.AlertsTableAdapters.AlertConditionTableAdapter conditionTableAdapter = new Microsoft.Practices.ESB.Portal.DataSets.AlertsTableAdapters.AlertConditionTableAdapter();
                    //alertConditions = new Microsoft.Practices.ESB.Portal.DataSets.Alerts.AlertConditionDataTable();

                    //conditionTableAdapter.Fill(alertConditions, alertID);

                    alertConditions = alerts.GetAlertConditionsDataTable(alertConditionEntities);

                    alertRow = alerts.GetAlertRow(alert);

                    Session["AlertEditRow"] = alertRow;
                    Session["AlertEditConditions"] = alertConditions;
                    this.txtName.Text = alert.Name;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }
            else
            {
                alertRow = (DataSets.Alerts.AlertRow)Session["AlertEditRow"];
                alertConditions = (DataSets.Alerts.AlertConditionDataTable)Session["AlertEditConditions"];
            }

            TheConditionList.AlertConditions = alertConditions;
            ownerName.Text = alertRow.InsertedBy;
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (this.IsPostBack)
            {
                noConditionsCheck();
                // this.noNameErrorMessage.Visible = string.IsNullOrEmpty(txtName.Text);
            }
        }

        protected void btnAddCondition_Click(object sender, EventArgs e)
        {
            if (ddlLeftSide.SelectedItem != null)
            {
                if (ddlLeftSide.SelectedValue.Equals("Application"))
                {
                    //add to dataset
                    alertConditions.AddAlertConditionRow(Guid.NewGuid(), alertRow,
                        ddlLeftSide.SelectedValue, ddlApplications.SelectedValue, ddlOperator.SelectedValue);
                    ddlApplications.SelectedIndex = 0;
                }
                else if (ddlLeftSide.SelectedValue.Equals("ServiceName"))
                {
                    //add to dataset
                    alertConditions.AddAlertConditionRow(Guid.NewGuid(), alertRow,
                        ddlLeftSide.SelectedValue, ddlServiceNames.SelectedValue, ddlOperator.SelectedValue);
                    ddlServiceNames.SelectedIndex = 0;
                }
                else if (ddlLeftSide.SelectedValue.Equals("FaultGenerator"))
                {
                    //add to dataset
                    alertConditions.AddAlertConditionRow(Guid.NewGuid(), alertRow,
                        ddlLeftSide.SelectedValue, ddlFaultGenerator.SelectedValue, ddlOperator.SelectedValue);
                    ddlFaultGenerator.SelectedIndex = 0;
                }
                else if (!string.IsNullOrEmpty(txtRightSide.Text.Trim()))
                {
                    //add to dataset
                    alertConditions.AddAlertConditionRow(Guid.NewGuid(), alertRow,
                        ddlLeftSide.SelectedValue, txtRightSide.Text, ddlOperator.SelectedValue);
                    //clear                    
                    txtRightSide.Text = string.Empty;
                }

                ddlOperator.SelectedIndex = 0;
            }
        }

        private void LoadApplications()
        {
            this.ddlApplications.Visible = true;
            this.txtRightSide.Visible = false;
            this.ddlServiceNames.Visible = false;
            this.ddlFaultGenerator.Visible = false;

            //Call the BTQuery Service
            List<BizTalkOperationsService.BTApplication> applications = PortalHelper.GetAllApplications();

            //Populate the applications list with the applications from BizTalk                
            this.ddlApplications.DataSource = applications;
            this.ddlApplications.DataTextField = "Name";
            this.ddlApplications.DataValueField = "Name";
            this.ddlApplications.DataBind();
        }

        private void LoadServiceNames()
        {
            this.ddlApplications.Visible = false;
            this.txtRightSide.Visible = false;
            this.ddlServiceNames.Visible = true;
            this.ddlFaultGenerator.Visible = false;

            //Call the BTQuery Service
            List<string> serviceNames = PortalHelper.GetServiceNames();
            this.ddlServiceNames.DataSource = serviceNames;
            this.ddlServiceNames.DataBind();
        }

        protected void ddlLeftSide_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetRightSide();
        }

        private void SetRightSide()
        {
            if (ddlLeftSide.SelectedValue.Equals("Application"))
            {
                LoadApplications();
            }
            else if (ddlLeftSide.SelectedValue.Equals("ServiceName"))
            {
                LoadServiceNames();
            }
            else if (ddlLeftSide.SelectedValue.Equals("FaultGenerator"))
            {
                this.ddlServiceNames.Visible = false;
                this.ddlApplications.Visible = false;
                this.ddlFaultGenerator.Visible = true;
                this.txtRightSide.Visible = false;
            }
            else
            {
                this.ddlServiceNames.Visible = false;
                this.ddlApplications.Visible = false;
                this.txtRightSide.Visible = true;
                this.ddlFaultGenerator.Visible = false;
            }
        }

        private void noConditionsCheck()
        {
            this.noConditionsErrorMessage.Visible = !(alertConditions.Count > 0);
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            if (alertConditions.Count > 0 && !string.IsNullOrEmpty(txtName.Text))
            {
                alertRow.Name = txtName.Text;

                //build conditions string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < alertConditions.Count; i++)
                {
                    Microsoft.Practices.ESB.Portal.DataSets.Alerts.AlertConditionRow acr = alertConditions[i];

                    sb.AppendFormat(" {0} {1} '{2}{3}{2}'", acr.LeftSide, acr.Operator, acr.Operator == "like" ? "%" : string.Empty,
                        acr.RightSide.Replace("'", "''"));

                    if (i < alertConditions.Count - 1) sb.AppendFormat(" AND");
                }

                // hook service instead of using the dataset
                IExceptionService client = null;
                try
                {
                    client = PortalHelper.GetExceptionService();

                    Alert update = client.GetAlertById(alertRow.AlertID);
                    update.ConditionsString = sb.ToString();
                    update.InsertedBy = alertRow.InsertedBy;
                    update.InsertedDate = alertRow.InsertedDate;
                    update.Name = alertRow.Name;

                    client.UpdateAlert(update);

                    foreach (Microsoft.Practices.ESB.Portal.DataSets.Alerts.AlertConditionRow ac in alertConditions.Rows)
                    {
                        client.UpdateAlertCondition(new AlertCondition()
                        {
                            AlertConditionID = ac.AlertConditionID,
                            AlertID = update.AlertID,
                            InsertedDate = update.InsertedDate,
                            LeftSide = ac.LeftSide,
                            RightSide = ac.RightSide,
                            Operator = ac.Operator
                        });
                    }

                    if (alertRow.AlertID.ToString().Length > 0)
                    {
                        Session.Remove("Remove");
                        Session.Remove("AlertDataSet");
                        Response.Redirect("../Admin/Alerts.aspx");
                    }
                    else
                    {
                        this.noNameErrorMessage.Visible = true;
                        this.noNameErrorMessage.Text = "Could not create record - Alert name already exists!";
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }
            else
            {
                this.noConditionsErrorMessage.Visible = !(alertConditions.Count > 0);
                // this.noNameErrorMessage.Visible = string.IsNullOrEmpty(txtName.Text);
            }
        }

        protected string GetOwnerName()
        {
            return User.Identity.Name.ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("../Admin/Alerts.aspx");
        }
    }
}