//---------------------------------------------------------------------
// File: AlertViewer.cs
// 
// Summary: This page displays the details of a single alert.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal.Alerts
{
    /// <summary>
    /// Base class for the AlertViewer page.
    /// </summary>
    public partial class AlertViewer : System.Web.UI.Page
    {
        protected Microsoft.Practices.ESB.Portal.DataSets.Alerts alerts;

        /// <summary>
        /// Indicates whether the user originally created the alert.
        /// </summary>
        private bool _userIsAlertOwner;
        private bool UserIsAlertOwner
        {
            get { return _userIsAlertOwner; }
            set { _userIsAlertOwner = value; }
        }

        /// <summary>
        /// Indicates whether one or more users other than the current user have subscribed to the alert.
        /// </summary>
        private bool _othersHaveSubscribed;
        private bool OthersHaveSubscribed
        {
            get { return _othersHaveSubscribed; }
            set { _othersHaveSubscribed = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                alerts = new Microsoft.Practices.ESB.Portal.DataSets.Alerts();
                IExceptionService client = null;
                try
                {
                    Guid id = new Guid(Request.QueryString["esb:AlertID"]);

                    client = PortalHelper.GetExceptionService();

                    Alert alert = client.GetAlertById(id);
                    List<AlertSubscription> subscription = client.GetAlertSubscriptionsByAlertId(id);
                    List<AlertCondition> conditions = client.GetAlertConditionsByAlertId(id);

                    if (alert != null)
                    {
                        UserIsAlertOwner = (alert.InsertedBy.Equals(Page.User.Identity.Name, StringComparison.InvariantCultureIgnoreCase));

                        linkAddSubscriptions.NavigateUrl = string.Format("AddSubscriptions.aspx?esb:AlertID={0}", Request.QueryString["esb:AlertID"]);

                        lblName.Text = alert.Name;
                        lblOwner.Text = alert.InsertedBy;
                        lblCreateDate.Text = alert.InsertedDate.ToString();
                    }

                    this.repeaterCondiations.ItemDataBound += new RepeaterItemEventHandler(repeaterCondiations_ItemDataBound);
                    this.repeaterCondiations.DataSource = alerts.GetAlertConditionsView(conditions);
                    this.repeaterCondiations.DataBind();

                    this.repeaterSubscriptions.ItemDataBound += new RepeaterItemEventHandler(repeaterSubscriptions_ItemDataBound);
                    this.repeaterSubscriptions.DataSource = alerts.GetAlertSubscriptionsView(subscription);
                    this.repeaterSubscriptions.DataBind();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }
        }

        void repeaterCondiations_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            Label labelLeftSide = e.Item.FindControl("labelLeftSide") as Label;
            Label labelOperator = e.Item.FindControl("labelOperator") as Label;
            Label labelRightSide = e.Item.FindControl("labelRightSide") as Label;

            DataRowView drv = e.Item.DataItem as DataRowView;

            labelLeftSide.Text = drv["LeftSide"].ToString();
            labelOperator.Text = drv["Operator"].ToString();
            labelRightSide.Text = drv["RightSide"].ToString();
        }

        void repeaterSubscriptions_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            DataRow dr = ((DataRowView)e.Item.DataItem).Row;
            Label labelSubscriber = e.Item.FindControl("labelSubscriber") as Label;
//            HtmlGenericControl divEdit = e.Item.FindControl("divEdit") as HtmlGenericControl;
            HyperLink linkEditSubscription = e.Item.FindControl("linkEditSubscription") as HyperLink;

//            divEdit.Visible = UserIsAlertOwner;
            linkEditSubscription.NavigateUrl = "../Alerts/EditSubscription.aspx?esb:AlertID=" + dr["AlertID"].ToString() + "&ID=" + dr["AlertSubscriptionID"].ToString();


            labelSubscriber.Text = dr["Subscriber"].ToString();
        }

        /// <summary>
        /// This method checks whether other users have subscribed to the alert, and
        /// sets the visibility of the delete controls accordingly.  If other users
        /// have subscribed, deleting the alert is not allowed.
        /// </summary>
        private void SetDeleteControlVisibility()
        {
            if (UserIsAlertOwner && !OthersHaveSubscribed)
            {
                this.deleteButton.Visible = true;
            }
            else if (!UserIsAlertOwner)
            {
                this.deleteMessageLabel.Visible = true;
                this.deleteMessageLabel.Text = "You cannot delete the alert because someone else created it.";
            }
            else if (OthersHaveSubscribed)
            {
                this.deleteMessageLabel.Visible = true;
                this.deleteMessageLabel.Text = "You cannot delete the alert because others have subscribed to it.";
            }
        }

        /// <summary>
        /// Deletes the alert.
        /// </summary>
        protected void deleteButton_Click(object sender, EventArgs e)
        {
            Guid id = new Guid(Request.QueryString["esb:AlertID"]);
            IExceptionService client = null;

            try
            {
                client.DeleteAlertSubscriptionById(id);
                Response.Redirect("Alerts.aspx");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }
    }
}