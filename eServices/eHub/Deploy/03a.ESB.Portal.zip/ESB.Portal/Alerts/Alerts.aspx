<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="Alerts.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Alerts.Alerts" Title="ESB Management Console - Alerts"%>

<%@ Register Src="../Lists/SubscriptionsList.ascx" TagName="SubscriptionsList" TagPrefix="uc2" %>
<%@ Register Src="../Lists/AlertListSample.ascx" TagName="AlertList" TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
<h1 class="iconAlert">Alerts</h1>

<p><img src="../Images/Icons/16_new.gif" /><asp:LinkButton ID="linkAddAlert" runat="server" PostBackUrl="~/Alerts/AlertAdd.aspx" Text="Create Alert" ToolTip="Create Alert" /></p>


	<uc1:AlertList ID="AlertList1" runat="server" EnableTheming="true" ></uc1:AlertList>
	<uc2:SubscriptionsList ID="SubscriptionsList1" runat="server" />

</asp:Content>
