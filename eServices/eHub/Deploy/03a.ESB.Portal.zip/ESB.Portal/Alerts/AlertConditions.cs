//---------------------------------------------------------------------
// File: AlertCondition.cs
// 
// Summary: This class serves as an intermediary between data table stored
//          in the Session, and a GridView.  The class is used as an
//          ObjectDataSource bound to the GridView.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Diagnostics;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


namespace Microsoft.Practices.ESB.Portal.Alerts
{
   public class AlertConditions
   {
      public DataSets.Alerts AlertsDS;

      //public DataSets.Alerts.AlertConditionDataTable Select()
      //{
      //   return AlertsDS.AlertCondition;
      //}

      //public void Update(Guid conditionID, string leftSide, string op, string rightSide)
      //{
      //   DataSets.Alerts.AlertConditionRow theRow = AlertsDS.AlertCondition.FindByAlertConditionID(conditionID);
      //   theRow.LeftSide = leftSide;
      //   theRow.Operator = op;
      //   theRow.RightSide = rightSide;
      //}

      //public void Delete(Guid conditionID)
      //{
      //   DataSets.Alerts.AlertConditionRow theRow = AlertsDS.AlertCondition.FindByAlertConditionID(conditionID);
      //   theRow.Delete();
      //}

      //public void Insert(string leftSide, string op, string rightSide)
      //{
      //   AlertsDS.AlertCondition.AddAlertConditionRow(new Guid(), AlertsDS.Alert[0], leftSide, rightSide, op); 
      //}
   }
}