//---------------------------------------------------------------------
// File: AlertHistory.aspx.cs
// 
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ESB.Exceptions.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Admin
{
    public partial class AlertHistory : System.Web.UI.Page
    {
        private string AlertName
        {
            get
            {
                return Request.QueryString["esb:alertName"];
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();

                GridView1.DataSource = client.GetAlertHistoryByName(AlertName);
                GridView1.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            this.labelNoRecords.Visible = (this.GridView1.Rows.Count == 0);
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            BindGrid();
            GridViewExportUtil.ExcelExport(String.Format("AlertHistory_{0}.xls", DateTime.Now.ToShortDateString()), GridView1);
        }
    }
}
