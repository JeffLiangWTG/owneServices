<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="AlertHistory.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Admin.AlertHistory" Title="ESB Management Console - Alert History" %>

<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers" TagPrefix="cc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<div style="clear: both; width: 100%;">
		<div style="clear: both;">
			<h1><img src="../Images/AlertLarge.gif" style="vertical-align: middle;" /> Alert History</h1>
		</div>
		<asp:Image ID="Image1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
    <asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton>
    
		<asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="false" AllowPaging="true" AllowSorting="true" PageSize="25" Width="100%" >
			<HeaderStyle CssClass="tableHeader" />
			<RowStyle CssClass="tableRow" />
			<Columns>
				<asp:BoundField DataField="AlertName" HeaderText="Alert Name" SortExpression="AlertName" />
				<asp:BoundField DataField="Application" HeaderText="Application" SortExpression="Application" />
				<asp:BoundField DataField="ServiceName" HeaderText="Service Name" SortExpression="ServiceName" />          
                <asp:TemplateField  HeaderText="Date" SortExpression="InsertedDate">
			        <ItemTemplate>
				         <%# Microsoft.Practices.ESB.Portal.PortalHelper.UTC_to_ClientLocalTime(DataBinder.Eval(Container.DataItem, "InsertedDate")).ToString()%>
			        </ItemTemplate>
		        </asp:TemplateField>
				<asp:TemplateField HeaderText="Actions">
					<ItemTemplate>
						<a href="../Faults/FaultViewer.aspx?esb:FaultID=<%# DataBinder.Eval(Container.DataItem, "FaultID")%>" title="View Fault"><img src="../Images/Icons/16_View.gif" alt="View Fault" /></a>
					</ItemTemplate>
				</asp:TemplateField>
			</Columns>
		</asp:GridView>
		<br />
		<asp:Label ID="labelNoRecords" runat="server" Visible="False">There are no alerts for <b>'<%= Request.QueryString["esb:alertName"] %>'</b>.</asp:Label>
		<cc1:GridViewSortExtender ID="GridViewSortExtender1" runat="server" AscendingImageUrl="~/Images/asc_order.gif" DescendingImageUrl="~/Images/desc_order.gif" ExtendeeID="GridView1">
		</cc1:GridViewSortExtender>
		<%--<asp:ObjectDataSource ID="ObjectDataSource1" runat="server" OldValuesParameterFormatString="original_{0}" SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.AlertHistoryByNameTableAdapters.usp_select_AlertHistoryByNameTableAdapter">
			<SelectParameters>
				<asp:QueryStringParameter Name="AlertName" QueryStringField="esb:alertName" Type="String" />
			</SelectParameters>
		</asp:ObjectDataSource>--%>
	</div>
</asp:Content>
