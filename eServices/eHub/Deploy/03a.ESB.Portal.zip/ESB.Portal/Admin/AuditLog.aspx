<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="AuditLog.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Admin.AuditLog1" Title="ESB Management Console - Audit Log" %>
<%@ Register Src="AuditLog.ascx" TagName="AuditLog" TagPrefix="esb" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <h1 class="iconReport">Audit Log</h1>
    <esb:AuditLog ID="theAuditLog" runat="Server" />
</asp:Content>
