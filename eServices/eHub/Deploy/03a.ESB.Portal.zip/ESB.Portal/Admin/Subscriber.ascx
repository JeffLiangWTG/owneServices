<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Subscriber.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Admin.Subscriber" %>

<div style="margin-left: 15px; margin-top: 7px; cursor: pointer; height: 20px; ">
	<div style="float: left; " onmouseover="showSubscriptionDetails('<%= IsGroup %>', '<%= CustomEmail %>', '<%= UseStartEndTime %>', '<%= StartTime %>', '<%= EndTime %>', '<%= BlackOutStartDate %>', '<%= LastFired %>', '<%= IntervalMinutes %>', '<%= ModifiedBy %>');" onmouseout="hideSubscriptionDetails(this);">
		<img src="../Images/Icons/16_subscribe.gif" alt="" />
		<asp:Label ID="lblSubscriberName" runat="server"></asp:Label>
	</div>
	<div style="float: right;">
		<a href="EditSubscription.aspx?esb:AlertID=<%= AlertID %>&ID=<%= SubscriptionID %>"><img src="../Images/Icons/16_edit.gif" /></a>
		<a onclick="return confirm('Are you sure you want to delete this subscription?')" href="DeleteSubscription.aspx?esb:AlertID=<%= AlertID %>&esb:SubscriptionID=<%= SubscriptionID %>"><img src="../Images/Icons/16_delete.gif" /></a>
		<asp:ImageButton ID="ibDelete" runat="server" ToolTip="Delete" ImageUrl="~/Images/Icons/16_delete.gif" Visible="false"   /> 
	</div>
</div>