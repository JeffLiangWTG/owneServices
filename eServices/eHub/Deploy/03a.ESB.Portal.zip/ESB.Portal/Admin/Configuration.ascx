<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="Configuration.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Admin.Configuration" %>

<h1 class="iconFault">Fault Settings</h1>
<div class="formHeader">Audit Options</div>
<div class="formBody">
	<div class="formRow">
		<div class="formLabel"></div>
		<div class="formField"><asp:CheckBox runat="Server" ID="auditSaveBox" />Audit Save</div>
	</div>
	<div class="formRow">
		<div class="formLabel"></div>
		<div class="formField"><asp:CheckBox runat="Server" ID="auditSuccessfulResubmitBox" />Audit Successful Resubmit</div>    
	</div>
	<div class="formRow">
		<div class="formLabel"></div>
		<div class="formField" align="left"><asp:CheckBox runat="Server" ID="auditUnsuccessfulResubmitBox" />Audit Unsuccessful Resubmit</div>    
	</div>
</div>

<div class="formField" style="height: 31px; width: 1209px"></div>
<div class="formBody">
	<div class="formRow">
		<div class="formHeader">Alert Queue Options</div>
		<div class="formField"><asp:CheckBox runat="Server" ID="AlertQueueEnabledBox" />Enable Alert Queue Service</div>
	</div>
	<div class="formRow">
		<div class="formField"></div>
	</div>
	<div class="formRow">
		<div class="formLabel">Polling Interval:</div>
		<div class="formField"><asp:TextBox runat="Server" ID="QueuePollingIntervalBox" Width="350" /> Milliseconds</div>
	</div>
	<div class="formRow">
		<div class="formLabel">Batch Size:</div>
		<div class="formField"><asp:TextBox runat="Server" ID="QueueBatchSizeBox" Width="350" /></div>
	</div>
	<div class="formRow">
		<div class="formLabel">Active Directory Cache Interval:</div>
		<div class="formField"><asp:TextBox runat="Server" ID="ADCacheIntervalBox" Width="350" /></div>
	</div>
</div>

<div class="formField" style="height: 33px"></div>
<div class="formBody">
	<div class="formRow">
		<div class="formHeader">Alert Email Options</div>
		<div class="formField" style="height: 29px"><asp:CheckBox runat="Server" ID="AlertEmailEnabledBox" />Enable Alert Email Service</div>
	</div>
	<div class="formRow">
		<div class="formLabel">Email Server:</div>
		<div class="formField"><asp:TextBox runat="Server" Width="350" ID="EmailServerBox" /></div>
	</div>
	<div class="formRow">
		<div class="formLabel">Email Service Polling Interval:</div>
		<div class="formField"><asp:TextBox runat="Server" ID="EmailIntervalBox" Width="350" />Milliseconds</div>
	</div>
	<div class="formRow">
		<div class="formLabel">Email Service Batch Size:</div>
		<div class="formField"><asp:TextBox runat="Server" ID="EmailBatchSizeBox" Width="350" /></div>
	</div>
	<div class="formRow">
		<div class="formLabel">Email XSLT File Absolute Path:</div>
		<div class="formField"><asp:TextBox runat="Server" ID="XSLTPathBox" Width="350" /></div>
	</div>
	<div class="formRow">
		<div class="formLabel">Email From Address:</div>
		<div class="formField"><asp:TextBox runat="Server" ID="EmailSenderAddress" Width="350" /></div>
	</div>
</div>
			
<div class="formSubmit">
	<asp:Button ID="submitButton" Text="Update" runat="Server" OnClick="submitButton_Click" CssClass="formButton"  />
	<asp:Button ID="UpdateCancelButton" runat="server" CssClass="formButton"  CausesValidation="False" CommandName="Cancel" Text="Cancel"></asp:Button>

</div>
