//---------------------------------------------------------------------
// File: AuditLog.ascx.cs
// 
// Summary: This is the codebehind file for the AuditLog.ascx control.
//          This control displays an audit table of the events being
//          logged in the portal.  Possible events are:
//             1. Message Download
//             2. Successful Message Resubmission
//             3. Failed Message Resubmission
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Threading;
using ESB.Exceptions.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Admin
{
    public partial class AuditLog : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();

                GridView1.DataSource = client.GetAuditLog(ActionName, MessageID, FaultID, AuditUserName, StartDate, EndDate, ApplicationName);
                GridView1.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }

        private string ActionName
        {
            get
            {
                return Request.QueryString["esb:ActionName"];
            }
        }

        private string MessageID
        {
            get
            {
                return Request.QueryString["esb:MessageID"];
            }
        }

        private string FaultID
        {
            get
            {
                return Request.QueryString["esb:FaultID"];
            }
        }

        private string AuditUserName
        {
            get
            {
                return Request.QueryString["esb:AuditUserName"];
            }
        }

        private string ApplicationName
        {
            get
            {
                return string.IsNullOrEmpty(Request.QueryString["esb:Application"]) ? "-1": Request.QueryString["esb:Application"];
            }
        }

        private DateTime StartDate
        {
            get
            {
                return string.IsNullOrEmpty(Request.QueryString["esb:StartDate"]) ? DateTime.MinValue : DateTime.Parse(Request.QueryString["esb:StartDate"], Thread.CurrentThread.CurrentCulture);
            }
        }

        private DateTime EndDate
        {
            get
            {
                return string.IsNullOrEmpty(Request.QueryString["esb:EndDate"]) ? DateTime.MinValue : DateTime.Parse(Request.QueryString["esb:EndDate"], Thread.CurrentThread.CurrentCulture);
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            BindGrid();
            GridViewExportUtil.ExcelExport(String.Format("AuditLog_{0}.xls", DateTime.UtcNow.ToShortDateString()), GridView1);
        }
    }
}