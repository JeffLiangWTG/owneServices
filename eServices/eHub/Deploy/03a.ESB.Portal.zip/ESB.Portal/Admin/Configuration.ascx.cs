
//---------------------------------------------------------------------
// File: Configuration.ascx.cs
// 
// Summary: This user control provides a web interface to the ESB portal
//          configuration.
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//using Microsoft.Practices.ESB.Portal.DataSets.ConfigurationTableAdapters;
using System.ComponentModel;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal.Admin
{
    public partial class Configuration : System.Web.UI.UserControl
    {
        /// <summary>
        /// The page load event handler retrieves configuration information from the EsbExceptionDb database
        /// and displays it to the user.  The user will then have the option to edit the configuration
        /// and resubmit it to the database.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 

        private List<ConfigurationItem> ConfigurationItems
        {
            get
            {
                return Session["configuration"] as List<ConfigurationItem>;
            }
            set
            {
                Session["configuration"] = value;
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IExceptionService client = null;
                try
                {
                    client = PortalHelper.GetExceptionService();

                    Dictionary<string, ConfigurationItem> configurations = client.GetConfiguration();

                    CreateConfigurationItemList(configurations);

                    //Retrieve the AuditSave configuration
                    this.auditSaveBox.Checked =
                       configurations["AuditSave"].Value == "1" ? true : false;

                    //Retrieve the AuditSuccessfulResubmit configuration
                    this.auditSuccessfulResubmitBox.Checked =
                      configurations["AuditSuccessfulResubmit"].Value == "1" ? true : false;

                    //Retrieve the AuditUnsuccessfulResubmit configuration
                    this.auditUnsuccessfulResubmitBox.Checked =
                       configurations["AuditUnsuccessfulResubmit"].Value == "1" ? true : false;

                    //Retrieve the alert queue enabled/disabled configuration
                    this.AlertQueueEnabledBox.Checked = 
                        configurations["IsQueueEnabled"].Value == "1" ? true : false;                       

                    //Retrieve the alert queue service polling interval
                    this.QueuePollingIntervalBox.Text =
                       configurations["QueueInterval"].Value;

                    //Retrieve the alert queue batch Size
                    this.QueueBatchSizeBox.Text =
                       configurations["QueueBatchSize"].Value;

                    //Retrieve the alert queue Active Directory cache interval
                    this.ADCacheIntervalBox.Text = configurations["ADCacheInterval"].Value;

                    //Retrieve the enabled/disabled email service setting
                    this.AlertEmailEnabledBox.Checked = bool.Parse(configurations["IsEmailEnabled"].Value);

                    //Retrieve the SMTP email server configuration
                    this.EmailServerBox.Text = configurations["EmailServer"].Value;

                    //Retrieve the email polling interval
                    this.EmailIntervalBox.Text = configurations["EmailInterval"].Value;

                    //Retrieve the batch size of the email service
                    this.EmailBatchSizeBox.Text = configurations["EmailBatchSize"].Value;

                    //Retrieve the absolute path to the email XSLT file
                    this.XSLTPathBox.Text = configurations["XsltPath"].Value;

                    //Retrieve the email from address
                    this.EmailSenderAddress.Text = configurations["Sender"].Value;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }
        }

        private void CreateConfigurationItemList(Dictionary<string, ConfigurationItem> configuration)
        {
            List<ConfigurationItem> items = new List<ConfigurationItem>();

            foreach (var i in configuration.Values)
            {
                items.Add(i);
            }

            ConfigurationItems = items;
        }

        /// <summary>
        /// This submit button click event handler retrieves all of the configuration options
        /// on the page, and updates any changes to the database.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void submitButton_Click(object sender, EventArgs e)
        {
            //Create a new table adapter and data table
            List<ConfigurationItem> configuration = ConfigurationItems;

            string modifiedBy = HttpContext.Current.User.Identity.Name;

            //Retrieve the value of the Audit Save checkbox from the page, and add it to the data table
            ConfigurationItem item = configuration.Find(c => c.Name == "AuditSave");

            if (item != null)
            {
                item.Value = this.auditSaveBox.Checked ? "1" : "0";
            }

            item = configuration.Find(c => c.Name == "AuditSuccessfulResubmit");

            if (item != null)
            {
                item.Value = this.auditSuccessfulResubmitBox.Checked ? "1" : "0";
            }

            item = configuration.Find(c => c.Name == "AuditUnsuccessfulResubmit");

            if (item != null)
            {
                item.Value = this.auditUnsuccessfulResubmitBox.Checked ? "1" : "0";
            }

            item = configuration.Find(c => c.Name == "IsQueueEnabled");

            if (item != null)
            {
                item.Value = this.AlertQueueEnabledBox.Checked ? "1" : "0";
            }

            item = configuration.Find(c => c.Name == "QueueInterval");

            if (item != null)
            {
                item.Value = this.QueuePollingIntervalBox.Text;
            }

            item = configuration.Find(c => c.Name == "QueueBatchSize");

            if (item != null)
            {
                item.Value = this.QueueBatchSizeBox.Text;
            }

            item = configuration.Find(c => c.Name == "ADCacheInterval");

            if (item != null)
            {
                item.Value = this.ADCacheIntervalBox.Text;
            }

            item = configuration.Find(c => c.Name == "IsEmailEnabled");

            if (item != null)
            {
                item.Value = this.AlertEmailEnabledBox.Checked ? "true" : "false";
            }

            item = configuration.Find(c => c.Name == "EmailServer");

            if (item != null)
            {
                item.Value = this.EmailServerBox.Text;
            }

            item = configuration.Find(c => c.Name == "EmailInterval");

            if (item != null)
            {
                item.Value = this.EmailIntervalBox.Text;
            }

            item = configuration.Find(c => c.Name == "EmailBatchSize");

            if (item != null)
            {
                item.Value = this.EmailBatchSizeBox.Text;
            }

            item = configuration.Find(c => c.Name == "XsltPath");

            if (item != null)
            {
                item.Value = this.XSLTPathBox.Text;
            }

            item = configuration.Find(c => c.Name == "Sender");

            if (item != null)
            {
                item.Value = this.EmailSenderAddress.Text;
            }

            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();
                client.InsertConfiguration(configuration);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }
    }
}