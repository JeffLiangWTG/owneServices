<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="Alerts.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Admin.Alerts" Title="ESB Management Console - Alerts" %>

<%@ Register Src="../Lists/SubscriptionsList.ascx" TagName="SubscriptionsList" TagPrefix="uc2" %>
<%@ Register Src="../Lists/AlertList.ascx" TagName="AlertList" TagPrefix="uc1" %>
<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers" TagPrefix="cc1" %>
<%@ Register Src="~/Admin/Subscriber.ascx" TagName="subscriber" TagPrefix="uc3" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<script type="text/javascript" language="javascript">
		var currentViewDetails = null;

		function toggleSubscribers(row)
		{
			var toggleRow = document.getElementById("toggleRow" + row);
			var div = document.getElementById("alert" + row + "Subscribers");
			
			if (div.style.display == "inline")
			{
				div.style.display = "none";
				toggleRow.innerHTML = "+ View Subscribers";
			}
			else
			{
				div.style.display = "inline";
				toggleRow.innerHTML = "- Hide Subscribers";
			}
		}
		
		function showSubscriptionDetails(isGroup, customEmail, useStartEndTime, startTime, endTime, blackOutStartDate,
			lastFired, intervalMinutes, modifiedBy )
		{
			if (currentViewDetails != null)
			{
				document.body.removeChild(currentViewDetails);
			}
			
			var details = document.createElement("div");
			
			details.style.position = "absolute";
			details.style.left = event.clientX + 15 + "px";
			details.style.top = event.clientY + "px";
			
			details.style.border = "1px solid black";
			details.style.backgroundColor = "darkblue";
			details.style.color = "white";
			details.style.zIndex = 100;
			details.style.width = "300px";
			details.style.fontSize = "11px";	
			details.onmouseout = hideSubscriptionDetails;
						
			var detailsHTML = "<table cellpadding='5'>";
			
			detailsHTML += "<tr><td>Is Group:</td><td>" + isGroup + "<td></tr>";
			detailsHTML += "<tr><td>Custom Email:</td><td>" + customEmail + "<td></tr>";
			detailsHTML += "<tr><td>Use Start and End Time:</td><td>" + useStartEndTime + "<td></tr>";
			detailsHTML += "<tr><td>Start Time:</td><td>" + startTime + "<td></tr>";
			detailsHTML += "<tr><td>End Time:</td><td>" + endTime + "<td></tr>";
			detailsHTML += "<tr><td>Black Out Start Date:</td><td>" + blackOutStartDate + "<td></tr>";
			detailsHTML += "<tr><td>Last Fired:</td><td>" + lastFired + "<td></tr>";
			detailsHTML += "<tr><td>Interval Minutes:</td><td>" + intervalMinutes + "<td></tr>";
			detailsHTML += "<tr><td>Modified By:</td><td>" + modifiedBy + "<td></tr>";
			detailsHTML += "</table>";
			
			details.innerHTML = detailsHTML;

			document.body.appendChild(details);
			currentViewDetails = details;
		}
		
		function hideSubscriptionDetails()
		{
			if (currentViewDetails != null)
			{
				document.body.removeChild(currentViewDetails);
				currentViewDetails = null;
			}
		}
	</script>
		<h1><img src="../Images/AlertLarge.gif" style="vertical-align: middle;" /> Alerts</h1>
		<p>
			<a href="../Alerts/AlertAdd.aspx" title="Create Alert"><img src="../Images/Icons/16_new.gif" /></a>
			<asp:LinkButton ID="linkAddAlert" runat="server" PostBackUrl="~/Alerts/AlertAdd.aspx" Text="Create Alert" ToolTip="Create Alert" />
		</p>
        <asp:Image ID="Image1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
        <asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton>
		<asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" DataKeyNames="AlertID" BorderWidth="0"
				 AllowPaging="true" AllowSorting="true" Width="100%" OnRowCommand="GridView1_RowCommand"
				 OnRowDataBound="GridView1_RowDataBound" >
			<HeaderStyle CssClass="tableHeader" />
			<RowStyle CssClass="tableRow" />
			<Columns>
				<asp:BoundField DataField="AlertId" Visible="false" />
				<asp:TemplateField HeaderText="Alert Name" SortExpression="Name">
					<ItemTemplate>
						<%# DataBinder.Eval(Container.DataItem, "Name") %>
					</ItemTemplate>
				</asp:TemplateField>
				<asp:BoundField DataField="InsertedBy" HeaderText="Created By" SortExpression="InsertedBy" />
				<asp:TemplateField HeaderText="Statistics">
					<ItemTemplate>
						<img src="../Images/SeverityInformation.gif" />&nbsp;<%# GetAlertCountString(DataBinder.Eval(Container.DataItem, "AlertCountLastHour"))%> within last hour<br />
						<img src="../Images/SeverityInformation.gif" />&nbsp;<%# GetAlertCountString(DataBinder.Eval(Container.DataItem, "AlertCountLastDay"))%> within last day<br />
						<img src="../Images/SeverityInformation.gif" />&nbsp;<%# GetAlertCountString(DataBinder.Eval(Container.DataItem, "AlertCountLastMonth"))%> within last month
					</ItemTemplate>
				</asp:TemplateField>
				<asp:TemplateField  HeaderText="Subscribers" SortExpression="AlertSubscriptionCount">
					<ItemTemplate>
						<div>
							<%# GetSubscriptionCountString(DataBinder.Eval(Container.DataItem, "AlertSubscriptionCount"))%>
						</div>
								<div>
									<asp:LinkButton ID="lbViewHideSubscribers" runat="server" Onclick="lbViewHideSubscribers_Click" >+ View Subscribers</asp:LinkButton>
								</div>
								<div>
									<asp:PlaceHolder ID="ph1" runat="server"></asp:PlaceHolder>
								</div>
					</ItemTemplate>
				</asp:TemplateField>
				<asp:TemplateField  HeaderText="Actions">
					<ItemTemplate>
						<a href="../Alerts/AlertViewer.aspx?esb:AlertID=<%# DataBinder.Eval(Container.DataItem, "AlertID") %>"><img src="../Images/Icons/16_View.gif" alt="View" /></a>
						<a href="AlertHistory.aspx?esb:alertName=<%# DataBinder.Eval(Container.DataItem, "Name") %>"><img src="../Images/Icons/16_View_log.gif" alt="View History" /></a>
						<a href="AddSubscriptions.aspx?esb:AlertID=<%# DataBinder.Eval(Container.DataItem, "AlertID") %>"><img src="../Images/Icons/16_new.gif" alt="Add Subscriptions" /></a>
						<a href="../Alerts/AlertEdit.aspx?esb:AlertID=<%# DataBinder.Eval(Container.DataItem, "AlertID") %>"><asp:Image ID="imgEdit" runat="server" ImageUrl="~/Images/spacer.gif" AlternateText="Edit" Width="16px" Height="16px" /></a>
						<a href="DeleteAlert.aspx?esb:AlertId=<%# DataBinder.Eval(Container.DataItem, "AlertID") %>&UrlReferrer=Alerts.aspx" onclick="return confirm('Are you sure you want to delete this alert?')"><img src="../Images/Icons/16_delete.gif" alt="Delete" /></a>
					</ItemTemplate>
				</asp:TemplateField>
			</Columns>
		</asp:GridView>
		<%--<asp:ObjectDataSource ID="AlertsAllDataSource" runat="server" OldValuesParameterFormatString="original_{0}"
			SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.AlertStatsTableAdapters.usp_select_AlertStatisticsTableAdapter">
		</asp:ObjectDataSource>--%>
		<cc1:GridViewSortExtender ID="GridViewSortExtender1" runat="server" AscendingImageUrl="~/Images/asc_order.gif"
			DescendingImageUrl="~/Images/desc_order.gif" ExtendeeID="GridView1">
		</cc1:GridViewSortExtender>
&nbsp;<br />
</asp:Content>
