<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="Configuration.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Admin.Configuration1" EnableViewState="True" Title="ESB Management Console - Configuration" %>
<%@ Register Src="Configuration.ascx" TagName="Configuration" TagPrefix="esb" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

<esb:Configuration ID="theConfiguration" runat="Server" />
    
</asp:Content>
