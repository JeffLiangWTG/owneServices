//---------------------------------------------------------------------
// File: AlertViewer.cs
// 
// Summary: This page displays the details of a single alert.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal.Admin
{
    /// <summary>
    /// Base class for the AlertViewer page.
    /// </summary>
    public partial class AlertViewer : System.Web.UI.Page
    {
       protected Microsoft.Practices.ESB.Portal.DataSets.Alerts alerts;

       protected void Page_Load(object sender, EventArgs e)
       {
           if (!Page.IsPostBack)
           {
               IExceptionService client = null;
               try
               {
                   client = PortalHelper.GetExceptionService();

                   DataSets.Alerts alerts = new Microsoft.Practices.ESB.Portal.DataSets.Alerts();
                   linkAddSubscriptions.NavigateUrl = string.Format("AddSubscriptions.aspx?esb:AlertID={0}", Request.QueryString["esb:AlertID"]);
                   Guid id = new Guid(Request.QueryString["esb:AlertID"]);
                   alerts = new Microsoft.Practices.ESB.Portal.DataSets.Alerts();
                   //load data
                   Alert alert = client.GetAlertById(id);
                   List<AlertSubscription> subscriptions = client.GetAlertSubscriptionsByAlertId(id);
                   List<AlertCondition> conditions = client.GetAlertConditionsByAlertId(id);

                   lblName.Text = alert.Name;

                   this.TheConditionList.AlertConditions = alerts.GetAlertConditionsDataTable(conditions);
                   this.SubscriptionsList1.AlertSubscriptions = alerts.GetAlertSubscriptionsView(subscriptions);
               }
               catch (Exception ex)
               {
                   throw ex;
               }
               finally
               {
                   if (client != null)
                   {
                       ((IDisposable)client).Dispose();
                   }
               }
           }
       }

       /// <summary>
       /// Deletes the alert.
       /// </summary>
       protected void deleteButton_Click(object sender, EventArgs e)
       {
          Guid id = new Guid(Request.QueryString["esb:AlertID"]);
          alerts = new Microsoft.Practices.ESB.Portal.DataSets.Alerts();
          Microsoft.Practices.ESB.Portal.DataSets.AlertsTableAdapters.AlertTableAdapter alertTA =
            new Microsoft.Practices.ESB.Portal.DataSets.AlertsTableAdapters.AlertTableAdapter();
          alertTA.DeleteAlertByID(id);
          Response.Redirect("Alerts.aspx");
       }
    }
}
