<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="AlertViewer.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Admin.AlertViewer" Title="ESB Management Console - Alert Viewer" %>

<%@ Register Src="../Lists/SubscriptionsList.ascx" TagName="SubscriptionsList" TagPrefix="esb" %>

<%@ Register Src="../Lists/ConditionList.ascx" TagName="ConditionList" TagPrefix="esb" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

<div style="float: left; width: 590px;">
<table border="1">
   <tr>
       <th colspan='2'>Alert Details</th>
   </tr>
   <tr>
      <td>Alert Name</td>
      <td><asp:Label ID="lblName" runat="server">Alert Name</asp:Label></td>
   </tr>
   <tr>
      <td>Condition(s)</td>
      <td><esb:ConditionList ID="TheConditionList" runat="server" EnableDelete="False" /></td>
   </tr>
</table>
</div>

<div style="float: left; padding-left: 10px; width: 590px;">
<table border="1">
   <tr>
      <td>Subscriptions(s)</td>
      <td><esb:SubscriptionsList ID="SubscriptionsList1" runat="server" />
      <asp:HyperLink ID="linkAddSubscriptions" runat="server">Add Subscriptions</asp:HyperLink></td>
   </tr>
   <tr>
      <td>Delete Options</td>
      <td>
         <asp:Button ID="deleteButton" runat="server" Text="Delete Alert" OnClick="deleteButton_Click" Visible="true" />
         <asp:Label ID="deleteMessageLabel" runat="server" Visible="false" />
      </td>
   </tr>
</table>
</div>
<br clear="all" />
<p>
	<a href="Alerts.aspx"><-- Return to Alerts</a>
</p>
</asp:Content>
