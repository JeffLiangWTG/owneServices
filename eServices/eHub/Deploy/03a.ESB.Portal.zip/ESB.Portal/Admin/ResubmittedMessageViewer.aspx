<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="ResubmittedMessageViewer.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Admin.ResubmittedMessageViewerPage" Title="ESB Management Console - Resubmitted Message Viewer" %>
<%@ Register Src="ResubmittedMessageViewer.ascx" TagName="ResubmittedMessageViewer" TagPrefix="ESB" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
<ESB:ResubmittedMessageViewer ID="theMessageViewer" runat="server" />
</asp:Content>