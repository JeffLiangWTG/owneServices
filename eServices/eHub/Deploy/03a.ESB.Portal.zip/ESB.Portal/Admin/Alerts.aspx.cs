//---------------------------------------------------------------------
// File: Alerts.aspx.cs
// 
// Summary: This is the codebehind file for the Alerts.aspx page.  The
//          page allows users to view, create, and subscribe to alerts.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using ESB.Exceptions.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Admin
{
    public partial class Alerts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();

                GridView1.DataSource = client.GetAlertStatistics();
                GridView1.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }

        void repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            DataSets.AlertStats.usp_select_AlertStatisticsRow row = (DataSets.AlertStats.usp_select_AlertStatisticsRow)((DataRowView)e.Item.DataItem).Row;

            Label labelAlertName = e.Item.FindControl("labelAlertName") as Label;
            Label labelInsertedBy = e.Item.FindControl("labelInsertedBy") as Label;
            Label labelSubscriptionCount = e.Item.FindControl("labelSubscriptionCount") as Label;

            HyperLink linkSubscribe = e.Item.FindControl("linkSubscribe") as HyperLink;
            HyperLink linkEdit = e.Item.FindControl("linkEdit") as HyperLink;

            labelAlertName.Text = row.Name;
            labelInsertedBy.Text = row.InsertedBy;

            if (row.AlertSubscriptionCount == 1)
            {
                labelSubscriptionCount.Text = row.AlertSubscriptionCount.ToString() + " Subscription";
            }
            else
            {
                labelSubscriptionCount.Text = row.AlertSubscriptionCount.ToString() + " Subscriptions";
            }

            if (linkSubscribe != null)
                linkSubscribe.NavigateUrl = "AddSubscriptions.aspx?esb:AlertID=" + row.AlertID.ToString();

            if (linkEdit != null)
                linkEdit.NavigateUrl = "../Alerts/AlertViewer.aspx?esb:AlertID=" + row.AlertID.ToString();

        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "AlertSubscriptionCount")) == 0)
                {
                    ((Image)e.Row.FindControl("imgEdit")).ImageUrl = "~/Images/Icons/16_edit.gif";
                }
            }
        }

        protected void lbViewHideSubscribers_Click(object sender, EventArgs e)
        {
            LinkButton lb = (LinkButton)sender;
            GridViewRow row = (GridViewRow)(lb).NamingContainer;
            int rowIndex = row.RowIndex;

            if (lb.Text.ToLower().Contains("view"))
            {
                lb.Text = "- Hide Subscribers";

                IExceptionService client = null;
                try
                {
                    Guid alertId = (Guid)GridView1.DataKeys[rowIndex]["AlertID"];

                    client = PortalHelper.GetExceptionService();

                    List<AlertSubscription> subscriptions = client.GetAlertSubscriptionsByAlertId(alertId);
                    
                    foreach(AlertSubscription alertSubscription in subscriptions)
                    {
                        Subscriber ctlSubscriber = (Subscriber)LoadControl("Subscriber.ascx");
                        ctlSubscriber.SubscriberName = alertSubscription.Subscriber;
                        ctlSubscriber.IsGroup = alertSubscription.IsGroup.ToString();
                        ctlSubscriber.CustomEmail = alertSubscription.CustomEmail;
                        ctlSubscriber.UseStartEndTime = alertSubscription.UseStartAndEndTime.ToString();
                        ctlSubscriber.StartTime = alertSubscription.StartUTCHour + ":" + alertSubscription.StartUTCMinute;
                        ctlSubscriber.EndTime = alertSubscription.EndUTCHour.ToString() + ":" + alertSubscription.EndUTCMinute.ToString();
                        ctlSubscriber.BlackOutStartDate = alertSubscription.BlackOutStartDate.ToString();
                        ctlSubscriber.LastFired = alertSubscription.LastFired.ToString();
                        ctlSubscriber.IntervalMinutes = alertSubscription.IntervalMinutes.ToString();
                        ctlSubscriber.ModifiedBy = alertSubscription.ModifiedBy;
                        ctlSubscriber.AlertID = alertSubscription.AlertID.ToString();
                        ctlSubscriber.SubscriptionID = alertSubscription.AlertSubscriptionID.ToString();

                        ((PlaceHolder)row.FindControl("ph1")).Controls.Add(ctlSubscriber);
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }
            else
            {
                lb.Text = "+ View Subscribers";
                ((PlaceHolder)row.FindControl("ph1")).Controls.Clear();
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {

        }

        protected string GetSubscriptionCountString(object c)
        {
            int count = Convert.ToInt32(c);

            if (count == 1)
                return "1 Subscription";
            else return count.ToString() + " Subscriptions";
        }

        protected string GetAlertCountString(object c)
        {
            int count = Convert.ToInt32(c);

            if (count == 1)
                return "1 Alert";
            else return count.ToString() + " Alerts";
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            //GridView gv = new GridView();
            //gv.AllowPaging = false;
            ////gv.DataSource = AlertsAllDataSource;
            //gv.DataBind();
            //gv.Dispose();

            BindGrid();

            GridViewExportUtil.ExcelExport(String.Format("Alerts_{0}.xls", DateTime.UtcNow.ToShortDateString()), GridView1);
        }
    }
}