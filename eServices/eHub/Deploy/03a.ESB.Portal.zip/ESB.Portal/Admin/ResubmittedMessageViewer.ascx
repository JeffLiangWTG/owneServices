<%@ Control Language="C#"  AutoEventWireup="true" CodeBehind="ResubmittedMessageViewer.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Admin.ResubmittedMessageViewer" %>
<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers" TagPrefix="cc1" %>

<script language="javascript" src="../Script/Scripts.js"></script>
<%--<asp:ObjectDataSource ID="AuditLogDataSource" runat="server" InsertMethod="Insert"
    OldValuesParameterFormatString="original_{0}" SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.AuditLogTableAdapters.AuditLogTableAdapter">
    <SelectParameters>
        <asp:QueryStringParameter Name="ActionName" QueryStringField="esb:ActionName" Type="String" />
        <asp:QueryStringParameter Name="MessageID" QueryStringField="esb:MessageID" Type="String" />
        <asp:QueryStringParameter Name="FaultID" QueryStringField="esb:FaultID" Type="String" />
        <asp:QueryStringParameter Name="AuditUserName" QueryStringField="esb:AuditUserName" Type="String" />
        <asp:QueryStringParameter Name="StartDate" QueryStringField="esb:StartDate" Type="DateTime" />
        <asp:QueryStringParameter Name="EndDate" QueryStringField="esb:EndDate" Type="DateTime" />
        <asp:QueryStringParameter Name="Application" QueryStringField="esb:EndDate" Type="String" DefaultValue='-1' />
        <asp:Parameter Name="Debug" Type="Boolean" />
    </SelectParameters>
</asp:ObjectDataSource>--%>
<asp:FormView ID="MessageView" runat="server" Width="100%"> 
   <ItemTemplate>
   <div style="clear: both; padding-bottom: 15px;">
			<a href="../Admin/AuditLog.aspx">
				< Back to Audit Log</a>
		</div>
		<h1>
		    <asp:Label ID="labelHeaderCaption" runat="server" Text="Audit Log - Message Viewer" CssClass="iconReport"></asp:Label>
		 </h1>
		<h3>Message Details</h3>
		<div class="formBodyNoForm">
			<div class="formRow">
				<div class="formLabel">Resubmitted By:</div>
				<div class="formField">
					
					<asp:Label Visible="true" Text='<%#DataBinder.Eval(Container.DataItem, "AuditUserName")%>'
						ID="messageIdLabel" runat="server" /></div>
			</div>
			<div class="formRow">
				<div class="formLabel">Resubmitted On:</div>
				<div class="formField">
					<script language="javascript">                    
                  document.write(utcToLocalDate('<%#System.Convert.ToDateTime(DataBinder.Eval(Container.DataItem, "AuditDate")).ToString("")%>').toLocaleString());
               </script>
				</div>
			</div>
			<div class="formRow">
				<div class="formLabel">
					Resubmit URL:</div>
				<div class="formField">
					<asp:Label Text='<%#DataBinder.Eval(Container.DataItem, "ResubmitURL")%>' ID="routingURLLabel"
						runat="server" /></div>
			</div>
			
			<div class="formRow">
				<div class="formLabel">Message Data:</div>
				<div class="formField">
					<asp:TextBox 
						Visible="true" 
						ID="TextBox1" 
						runat="server" 
						ReadOnly="true"  
						TextMode="MultiLine"
						CssClass="formFieldInput" Height="400" Width="700" Text='<%#DataBinder.Eval(Container.DataItem, "MessageData")%>'>
					</asp:TextBox>
					
					</div>
				</div>
			</div>
     
   </ItemTemplate>
</asp:FormView>
