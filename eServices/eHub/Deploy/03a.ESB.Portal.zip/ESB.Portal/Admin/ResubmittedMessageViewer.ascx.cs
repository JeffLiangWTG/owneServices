//---------------------------------------------------------------------
// File: ResubmittedMessageViewer.ascx.cs
// 
// Summary: This user control displays the properties of a message
//          that has been edited and resubmitted, including the edited
//          message body.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ESB.Exceptions.Service.Implementation;
using System.Threading;

namespace Microsoft.Practices.ESB.Portal.Admin
{
    public partial class ResubmittedMessageViewer : System.Web.UI.UserControl
    {
        protected void Page_PreRender(object sender, EventArgs e)
        {
            TextBox messageData = MessageView.FindControl("TextBox1") as TextBox;
            if (messageData != null)
            {
                messageData.BackColor = System.Drawing.Color.WhiteSmoke;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private string ActionName
        {
            get
            {
                return Request.QueryString["esb:ActionName"];
            }
        }

        private string MessageID
        {
            get
            {
                return Request.QueryString["esb:MessageID"];
            }
        }

        private string FaultID
        {
            get
            {
                return Request.QueryString["esb:FaultID"];
            }
        }

        private string AuditUserName
        {
            get
            {
                return Request.QueryString["esb:AuditUserName"];
            }
        }

        private string ApplicationName
        {
            get
            {
                return string.IsNullOrEmpty(Request.QueryString["esb:Application"]) ? "-1" : Request.QueryString["esb:Application"];
            }
        }

        private DateTime StartDate
        {
            get
            {
                return string.IsNullOrEmpty(Request.QueryString["esb:StartDate"]) ? DateTime.MinValue : DateTime.Parse(Request.QueryString["esb:StartDate"], Thread.CurrentThread.CurrentCulture);
            }
        }

        private DateTime EndDate
        {
            get
            {
                return string.IsNullOrEmpty(Request.QueryString["esb:EndDate"]) ? DateTime.MinValue : DateTime.Parse(Request.QueryString["esb:EndDate"], Thread.CurrentThread.CurrentCulture);
            }
        }

        private void BindGrid()
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();

                MessageView.DataSource = client.GetAuditLog(ActionName, MessageID, FaultID, AuditUserName, StartDate, EndDate, ApplicationName);
                MessageView.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }
    }
}