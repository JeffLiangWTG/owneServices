//---------------------------------------------------------------------
// File: Subscriber.ascx.cs
// 
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Microsoft.Practices.ESB.Portal.Admin
{
    public partial class Subscriber : System.Web.UI.UserControl
    {
        #region members

        public string IsGroup = String.Empty;
        public string CustomEmail = String.Empty;
        public string UseStartEndTime = String.Empty;
        public string StartTime = String.Empty;
        public string EndTime = String.Empty;
        public string BlackOutStartDate = String.Empty;
        public string LastFired = String.Empty;
        public string IntervalMinutes = String.Empty;
        public string CreatedDate = String.Empty;
        public string CreatedBy = String.Empty;
        public string ModifiedDate = String.Empty;
        public string ModifiedBy = String.Empty;

        public string AlertID;
        public string SubscriptionID;

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region properties

        public string SubscriberName
        {
            get { return lblSubscriberName.Text; }
            set { lblSubscriberName.Text = value; }
        }

        #endregion
    }
}