<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="AuditLog.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Admin.AuditLog" %>
<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers"
    TagPrefix="cc1" %>
<script language="javascript" src="../Script/Scripts.js"></script>
<%--<asp:ObjectDataSource ID="AuditLogDataSource" runat="server" InsertMethod="Insert"
   OldValuesParameterFormatString="original_{0}" SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.AuditLogTableAdapters.AuditLogTableAdapter">
   <SelectParameters>
      <asp:QueryStringParameter Name="ActionName" QueryStringField="esb:ActionName" Type="String" />
      <asp:QueryStringParameter Name="MessageID" QueryStringField="esb:MessageID" Type="String" />
      <asp:QueryStringParameter Name="FaultID" QueryStringField="esb:FaultID" Type="String" />
      <asp:QueryStringParameter Name="AuditUserName" QueryStringField="esb:AuditUserName" Type="String" />
      <asp:QueryStringParameter Name="StartDate" QueryStringField="esb:StartDate" Type="DateTime" />
      <asp:QueryStringParameter Name="EndDate" QueryStringField="esb:EndDate" Type="DateTime" />
      <asp:QueryStringParameter Name="Application" QueryStringField="esb:Application" Type="String" DefaultValue="-1" />
      <asp:Parameter Name="Debug" Type="Boolean" />
   </SelectParameters>
   <InsertParameters>
      <asp:Parameter Name="ActionName" Type="String" />
      <asp:Parameter Name="MessageID" Type="Object" />
      <asp:Parameter Name="MessageData" Type="String" />
      <asp:Parameter Name="ResubmitUrl" Type="String" />
      <asp:Parameter Name="ResubmitCode" Type="String" />
      <asp:Parameter Name="ResubmitMessage" Type="String" />
      <asp:Parameter Name="AuditUserName" Type="String" />
      <asp:Parameter Name="Debug" Type="Boolean" />
   </InsertParameters>
</asp:ObjectDataSource>--%>
<asp:Image ID="Image1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
<asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton>
&nbsp;
<asp:GridView ID="GridView1" runat="server" AllowPaging="True" 
    AutoGenerateColumns="False" CssClass="FaulViewer" BorderWidth="0" PageSize="25" 
    Width="100%">
<HeaderStyle CssClass="tableHeader" />
	<RowStyle CssClass="tableRow" />
    <Columns>
        <asp:BoundField DataField="ActionName" HeaderText="Action" SortExpression="ActionName" />
        <asp:TemplateField HeaderText="MessageID" SortExpression="MessageID">
         <ItemTemplate>
            <%# (string)DataBinder.Eval(Container.DataItem, "ActionName") == "SuccessfulResubmit" ? "<a href='../Faults/MessageViewer.aspx?esb:MessageID=" + DataBinder.Eval(Container.DataItem, "MessageID") + "&esb:ActionName=SuccessfulResubmit'>" + DataBinder.Eval(Container.DataItem, "MessageID") + "</a>" : DataBinder.Eval(Container.DataItem, "MessageID")%>
         </ItemTemplate>
        </asp:TemplateField>
        <asp:TemplateField HeaderText="Result" SortExpression="ResubmitCode">
            <ItemTemplate>
               <%#DataBinder.Eval(Container.DataItem, "ResubmitCode") + " - " + DataBinder.Eval(Container.DataItem, "ResubmitMessage") %>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:TemplateField HeaderText="Date" SortExpression="AuditDate">
            <ItemTemplate>
                <script language="javascript">
                    document.write(utcToLocalDate('<%#System.Convert.ToDateTime(DataBinder.Eval(Container.DataItem, "AuditDate")).ToString("")%>').toLocaleString());
                </script>
            </ItemTemplate>
            <ItemStyle HorizontalAlign="Left" />
        </asp:TemplateField>
        <asp:BoundField DataField="AuditUserName" HeaderText="User Name" SortExpression="AuditUserName"/>
        <asp:TemplateField  HeaderText="Action">
					<ItemTemplate>
					<%# (string)DataBinder.Eval(Container.DataItem, "ActionName") == "SuccessfulResubmit" ? "<a href='../Admin/ResubmittedMessageViewer.aspx?esb:MessageID=" + DataBinder.Eval(Container.DataItem, "MessageID") + "'><img src='../Images/Icons/16_View_log.gif' alt='View Edited Message' /></a>" : " "%>
					</ItemTemplate>
		</asp:TemplateField>
    </Columns>
</asp:GridView>
<cc1:GridViewSortExtender ID="GridViewSortExtender1" runat="server" AscendingImageUrl="~/Images/asc_order.gif"
    DescendingImageUrl="~/Images/desc_order.gif" ExtendeeID="GridView1">
</cc1:GridViewSortExtender>

