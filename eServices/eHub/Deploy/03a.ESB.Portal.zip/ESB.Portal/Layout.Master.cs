using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Microsoft.Practices.ESB.Portal
{
    public partial class Layout : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string tzoqry = Request.QueryString["tzo"];
            if (!string.IsNullOrEmpty(tzoqry))
                
                Session["tzo"] =int.Parse ( tzoqry);
            if (Session["tzo"] == null) 
                //need this to make it work in production
                if (Request.ApplicationPath=="/")
                    Response.Redirect("/getTZO.aspx?url=" + HttpUtility.UrlEncode(Request.RawUrl));
                else 
            Response.Redirect(Request.ApplicationPath + "/getTZO.aspx?url=" + HttpUtility.UrlEncode(Request.RawUrl));
            //                Response.Redirect( "/getTZO.aspx?url=" + HttpUtility.UrlEncode(Request.RawUrl));
            
        }

        public string GetMenuItemLeftCssClass(string isSelected)
        {

            if (bool.Parse(isSelected))
            {
                return "menuItemLeftSelected";
            }
            else
            {
                return "menuItemLeft";
            }
        }

        public string GetMenuItemRightCssClass(string isSelected)
        {
            if (bool.Parse(isSelected))
            {
                return "menuItemRightSelected";
            }
            else
            {
                return "menuItemRight";
            }
        }

        protected void Menu1_PreRender(object sender, EventArgs e)
        {
            
        }
       
    }
}
