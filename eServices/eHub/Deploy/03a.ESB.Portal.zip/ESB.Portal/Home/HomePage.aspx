<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="HomePage.aspx.cs"
	Inherits="Microsoft.Practices.ESB.Portal.HomePage" Title="ESB Management Console - Home" %>

<%@ Register Src="../Admin/AuditLog.ascx" TagName="AuditLog" TagPrefix="uc" %>
<%@ Register Src="../Charts/FaultCountByApp.ascx" TagName="FaultCountByApp" TagPrefix="uc" %>
<%@ Register Src="../Charts/FaultCountByErrorType.ascx" TagName="FaultCountByErrorType"
	TagPrefix="uc" %>
<%@ Register Src="../Charts/FaultCountOverTimeByApp.ascx" TagName="FaultCountOverTimeByApp"
	TagPrefix="uc" %>
<%@ Register Src="../Lists/RegistrySummary.ascx" TagName="RegistrySummary" TagPrefix="uc" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

	<script language="javascript">

		function redirect(url)
		{
			document.location = url;
		}
		
		function toggleApplicationSettings(isVisible)
		{
			if(isVisible)
			{
				document.getElementById("applicationSettingsContainer").style.display = "inline";
			}
			else
			{
				document.getElementById("applicationSettingsContainer").style.display = "none";
			}
		}
		
		function selectAllApplications(select)
		{
			var totalAppCount = document.getElementById("totalApplicationCount").value;
			
			for(var i=0; i<totalAppCount; i++)
			{
				if (select)
				{
					document.getElementById("appSetting" + i).checked = true;
				}
				else
				{
					document.getElementById("appSetting" + i).checked = false;
				}
			}
		}
	
	</script>
	<div id="applicationSettingsContainer" style="display: none; position: absolute;
		left: 35px; top: 85px; z-index: 2100; background-color: WhiteSmoke; border: 1px solid black;
		padding: 10px 10px 0px 10px;">
		<div style="clear: both;">
			<div id="applicationSettings" runat="server">
			</div>
			<div style="clear:both; padding-left:8px;">
				Select:&nbsp;&nbsp;<span style="text-decoration:underline; cursor:hand;" onclick="selectAllApplications(true);">All</span>&nbsp;&nbsp;<span style="text-decoration:underline; cursor:hand;"  onclick="selectAllApplications(false);">None</span>
			</div>
		</div>
		<div style="clear: both;">
			<div style="float: left; padding-top: 10px; padding-bottom:8px; margin-left: 0px;">
				<input type="submit" class="formButton" value="Save" style="height: 28px; width:60px; font-size: .9em;" />
				<input type="button" class="formButton" value="Cancel" style="height: 28px; width:60px; font-size: .9em;"
					onclick="toggleApplicationSettings(false);" />
			</div>
		</div>
	</div>
	
	<div style="clear: both;">
		<div style="clear: both; padding-bottom: 5px;;">
			<span style="font-family: Trebuchet MS; font-size: 1em; cursor: pointer;" onclick="toggleApplicationSettings(true);">
				<img src="../images/configure.gif" style="vertical-align: middle;" />
				Select Applications</span> <span style="font-family: Trebuchet MS; font-size: 1em;
					margin-left: 10px;">Date Range:
					<asp:DropDownList ID="dropDownTimeRange" runat="server" AutoPostBack="true" Font-Size="1em"
						Font-Names="Trebuchet MS">
						<asp:ListItem Text="Hour" Value="Hour" />
						<asp:ListItem Text="Day" Value="Day" />
						<asp:ListItem Text="Week" Value="Week" />
						<asp:ListItem Text="Month" Value="Month" />
						<asp:ListItem Text="Quarter" Value="Quarter" />
						<asp:ListItem Text="Year" Value="Year" />
						<asp:ListItem Text="All" Value="All" />
					</asp:DropDownList>
				</span>
		</div>
		
		<!-- Charts Start -->
		<div style="clear: both; height: 320px; width: 100%;">
			<div style="float: left; width: 400px;">
				<iframe src="../Charts/FaultCountByApp.aspx" frameborder="0" width="400px" height="340px"></iframe>
			</div>
			<div style="float: left; width: 400px;">
				<iframe src="../Charts/FaultCountByErrorType.aspx" frameborder="0" width="400px" height="340px"></iframe>
			</div>
			<div style="float: left; width: 400px;">
				<iframe src="../Charts/FaultCountOverTimeByApp.aspx" frameborder="0" width="400px" height="340px"></iframe>
			</div>
		</div>
		<!-- Charts End -->

		<!-- Summary Start -->
		<div style="clear: both; margin-left: 10px; width:1220;">
			<div style="float: left; width: 600px; border-style:none;">
<%--				<div style="clear: both;">
					<iframe src="../Lists/RegistrySummaryContainer.aspx" frameborder="0" style="width: 610px; height:265px; border-style:none;"></iframe>
				</div>--%>
				<div style="clear: both;">
					<iframe src="../Lists/AlertSummaryContainer.aspx" frameborder="0" style="width: 610px; height: 250px"></iframe>
				</div>
			</div>
			<div style="float: left; width: 600px;">
				<div style="clear: both;">
					<iframe src="../Lists/FaultSummaryContainer.aspx" frameborder="0" style="width: 610px; height:540px;"></iframe>
				</div>
			</div>
		</div>
		<!-- Summary End -->
		
	</div>
</asp:Content>
