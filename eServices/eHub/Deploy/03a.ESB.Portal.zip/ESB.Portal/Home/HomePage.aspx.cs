//---------------------------------------------------------------------
// File: HomePage.aspx.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Practices.ESB.Portal;

namespace Microsoft.Practices.ESB.Portal
{
    public partial class HomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            if (this.IsPostBack)
            {
                saveSettings();
            }
            else
            {
                this.dropDownTimeRange.SelectedValue = PortalHelper.GetUserFilterDateRange(this.Context).ToString();
            }

        }

        protected void Page_PreRender(object sender, EventArgs e)
        {
            renderApplicationSettings();

        }

        private void renderApplicationSettings()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            System.Collections.Generic.List<string> userApps = PortalHelper.GetUserApplications(Context);

            int column = 0;
            int index = 0;
            foreach (BizTalkOperationsService.BTApplication application in PortalHelper.GetAllApplications())
            {
                if (column == 0)
                {
                    sb.Append("<div style='clear:both;'>");
                }


                sb.Append("<div style='float:left; margin-left:5px; width:300px;'>");

                if (userApps.Contains(application.Name))
                {
                    sb.Append("<input type='checkbox' name='appSetting" + index + "' checked value='" + application.Name + "'/>");
                }
                else
                {
                    sb.Append("<input type='checkbox' id='appSetting" + index + "' name='appSetting" + index + "' value='" + application.Name + "'/>");
                }

                sb.Append(application.Name + "</div>");


                if (column == 2)
                {
                    column = 0;
                    sb.Append("</div>");
                }
                else
                {
                    column++;
                }
                index++;
            }

            sb.Append("<input type='hidden' id='totalApplicationCount' value='" + index.ToString() + "'>");

            if (column != 0)
            {
                sb.Append("</div>");
            }

            applicationSettings.InnerHtml = sb.ToString();
        }

        private void saveSettings()
        {
            string settingsValue = "";

            bool first = true;
            foreach (string key in Request.Form.Keys)
            {
                if (key.Contains("appSetting"))
                {
                    if (first)
                    {
                        first = false;
                    }
                    else
                    {
                        settingsValue += ",";
                    }
                    settingsValue += Request.Form[key];
                }
            }

            PortalHelper.SaveUserSetting(this.Context, "DefaultApplications", settingsValue);
            PortalHelper.SaveUserSetting(this.Context, "UserFilterDateRange", this.dropDownTimeRange.SelectedValue);
            PortalHelper.LoadUserSettingsToSession(this.Context);
        }
    }
}
