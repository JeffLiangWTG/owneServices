<%@Page Language="C#" AutoEventWireup="true" CodeBehind="AlertSummaryContainer.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Lists.AlertSummaryContainer" Title="ESB Management Console - Alert Summary" %>

<%@Register Src="AlertSummary.ascx" TagName="AlertSummary" TagPrefix="uc1" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
	<link type="text/css" rel="stylesheet" href="../css/Style.css" />
	<script language="javascript" src="../Script/Scripts.js" ></script>
</head>
<body style="margin: 0px; padding: 0px;">
    <form id="form1" runat="server" class="formContainer">
		<div style="width: 570px;">
			<h2>Alert History</h2>
			<div class="summaryContainer" style="padding: 0px; margin: v; width:570px; height:190px; border-style:none;">
				<div class="summaryArea">
					<div class="summaryHeader">
						<div class="summaryColumn0 summaryHeaderColumn" style="width:400px;">Alert Name</div>
						<div class="summaryColumn1 summaryHeaderColumn" style="width:150px;">Date</div>
						<div style="clear:both; overflow: auto; height: 150px; border:0px solid black;">
							<uc1:AlertSummary ID="AlertSummary1" runat="server" />
						</div>
					</div>
				</div>
			</div>
		</div>
    </form>
</body>
</html>
