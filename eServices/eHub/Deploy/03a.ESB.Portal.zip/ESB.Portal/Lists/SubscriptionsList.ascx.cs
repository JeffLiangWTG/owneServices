using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Microsoft.Practices.ESB.Portal.Lists
{
    public partial class SubscriptionsList : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private bool isAdmin;

        public bool IsAdmin
        {
            get { return isAdmin; }
            set { isAdmin = value; }
        }

        private DataView alertSubscriptions;

        public DataView AlertSubscriptions
        {
            get { return alertSubscriptions; }
            set { alertSubscriptions = value; }
        }

        protected void GridView1_PreRender(object sender, EventArgs e)
        {
            GridView1.Columns[1].Visible = isAdmin;
            GridView1.Columns[2].Visible = isAdmin;
            GridView1.DataSource = alertSubscriptions;
            GridView1.DataBind();
            //lblNoneFound.Visible = alertSubscriptions.Count == 0;
        }

        protected string GetLocalTime(object Hour, object Minute)
        {
            if (Hour == null || Minute == null)
           
                return "";
            else
                return PortalHelper.UTC_to_ClientLocalTime(DateTime.Parse(Hour + ":" + Minute)).ToShortTimeString() ;

        }

	
    }
}