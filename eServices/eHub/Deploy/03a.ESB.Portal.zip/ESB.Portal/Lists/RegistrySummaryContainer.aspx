<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="RegistrySummaryContainer.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Lists.RegistrySummaryContainer" %>

<%@ Register Src="RegistrySummary.ascx" TagName="RegistrySummary" TagPrefix="uc1" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
	<link type="text/css" rel="stylesheet" href="../css/Style.css" />
</head>
<body style="margin: 0px; padding: 0px;">
    <form id="form1" runat="server" style="margin: 0px; padding: 0px;">
		<div class="sectionContainer">
			<h2>Registry</h2>
			<div style="line-height: 20px;">
				<span>Auto Publish is <asp:Label ID="labelAutoPublishSwitch" runat="server" /></span>&nbsp;| 
				<span class="linkUnderline" onclick="javascript:parent.redirect('../Uddi/UDDIAdmin.aspx');">Change</span> | 	
				<span class="linkUnderline" id="linkPendingRequests" runat="server" onclick="javscript:parent.redirect('../Uddi/UDDIPendingRequests.aspx');"></span>
			</div>						

			<div class="summaryContainer" style="padding: 0px; margin: 0px; width:570px; height:211px; border-style:none;">
				<div class="summaryArea">
					<div class="summaryHeader">
						<div class="summaryColumn0 summaryHeaderColumn">
							Type</div>
						<div class="summaryColumn1 summaryHeaderColumn" style="width:250px;">
							Name</div>
						<div class="summaryColumn2 summaryHeaderColumn" style="width:170px;">
							User</div>
					</div>
					<div style="overflow: auto; border-style:none; height: 190px; border:0px solid black;">
						<uc1:RegistrySummary id="RegistrySummary1" runat="server"/>
					</div>
				</div>
			</div>
		</div>
    </form>
</body>
</html>
