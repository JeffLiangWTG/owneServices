//---------------------------------------------------------------------
// File: AlertSummary.ascx.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal.Lists
{
    public partial class AlertSummary : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            IExceptionService client = PortalHelper.GetExceptionService();

            List<usp_select_AlertHistoryResult> alerts = client.GetAlertHistory(10);
			//List<usp_select_AlertsResult> alerts = client.GetAlerts();

            ((IDisposable)client).Dispose();

            this.Repeater1.ItemDataBound +=new RepeaterItemEventHandler(Repeater1_ItemDataBound);
            this.Repeater1.DataSource = alerts;
            this.Repeater1.DataBind();            
        }

        void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            usp_select_AlertHistoryResult alert = e.Item.DataItem as usp_select_AlertHistoryResult;
            HtmlGenericControl alertSummaryRow = e.Item.FindControl("alertSummaryRow") as HtmlGenericControl;

			//alertSummaryRow.Attributes.Add("onclick", "parent.document.location='../Alerts/AlertViewer.aspx?esb:AlertID=" + Server.UrlEncode(alert.AlertHistoryID.ToString()) + "'");
			alertSummaryRow.Attributes.Add("onclick", "parent.document.location='../Faults/FaultViewer.aspx?esb:FaultID=" + Server.UrlEncode(alert.FaultID.ToString()) + "'");

            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                ((Label)(e.Item.FindControl("labelAlertName"))).Text = PortalHelper.CrumbString(alert.AlertName, 30);
                ((Label)(e.Item.FindControl("labelApplication"))).Text = PortalHelper.CrumbString(alert.Application, 15);
                ((Label)(e.Item.FindControl("labelService"))).Text = PortalHelper.CrumbString(alert.ServiceName, 15);
                ((Label)(e.Item.FindControl("labelAlertDate"))).Text = PortalHelper.UTC_to_ClientLocalTime(alert.InsertedDate).ToString();
            }          
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
        }
    }
}