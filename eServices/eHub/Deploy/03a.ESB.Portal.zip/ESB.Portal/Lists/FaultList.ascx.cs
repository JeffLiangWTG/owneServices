//---------------------------------------------------------------------
// File: FaultList.ascx.cs
// 
// Summary: Displays a sortable and filterable table of multiple faults.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using ESB.Exceptions.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Lists
{
    /// <summary>
    /// Base class for the FaultList class
    /// </summary>
    public partial class FaultList : System.Web.UI.UserControl
    {
        int lowMediumSeverityThreshold;
        int mediumHighSeverityThreshold;
        string lowSeverityImagePath;
        string mediumSeverityImagePath;
        string highSeverityImagePath;

		protected void Page_Load(object sender, EventArgs e)
		{
			Response.Cache.SetCacheability(HttpCacheability.NoCache);
			loadConfigSettings();

			if (!IsPostBack)
			{
				populateApplicationList();

				//this.FaultsDataSource.SelectParameters["StartDate"].DefaultValue = PortalHelper.GetStartDate(PortalHelper.GetUserFilterDateRange(this.Context)).ToString();
				//this.FaultsDataSource.SelectParameters["EndDate"].DefaultValue = DateTime.UtcNow.ToString();
				BindGrid();
				this.dateRangeInterval.SelectedValue = PortalHelper.GetUserFilterDateRange(this.Context).ToString().ToLower();

				consumeURLParams();

				if (ResetGrid)
				{
					Faults.PageIndex = 0;
				}
			}
		}

        /// <summary>
        /// Indicates whether the fault list GridView should be refreshed.  A new filter being applied triggers this condition.
        /// </summary>
        private bool ResetGrid
        {
            get { return (string)Request.Form["resetGrid"] == "true"; }
        }

        private Guid FaultID
        {
            get
            {
                if (string.IsNullOrEmpty(Request.QueryString["esb:faultID"]))
                {
                    return Guid.Empty;
                }
                else
                {
                    return new Guid(Request.QueryString["esb:faultID"]);
                }
            }
        }

        private string FaultCode
        {
            get { return faultCodeBox.Text; }
        }

        private string ErrorType
        {
            get { return errorTypeBox.Text; }
        }

        private string FailureCategory
        {
            get { return failureCategoryBox.Text; }
        }

        private string ApplicationName
        {
			get { return appList.SelectedIndex == 0 ? null : appList.SelectedValue; }
        }

        private int FaultSeverity
        {
            get
            { 
				int result;
				if (!int.TryParse(maxFaultSeverityBox.Text, out result))
				{
					return 4;
				}
				return result;
            }
        }

		private string SortDirection
		{
			get { return (string)ViewState["SortDirection"] ?? "asc"; }
			set { ViewState["SortDirection"] = value; }
		}

        private List<Fault> GetFaults()
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();
                return client.GetFaults(FaultID, ApplicationName, PortalHelper.GetStartDate(PortalHelper.GetUserFilterDateRange(this.Context)), DateTime.UtcNow, FaultCode, FailureCategory, ErrorType, FaultSeverity);
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        } 

        private void BindGrid()
        {
            List<Fault> faults = GetFaults();
            Faults.DataSource = faults;
            Faults.DataBind();
        }

        public string GetCrumbedString(object t, int crumbAt)
        {
            string text = t.ToString();
            if (text.Length > crumbAt)
            {
                return "<span title='" + text + "'>" + PortalHelper.CrumbString(text, crumbAt) + "</span>";
            }
            else
            {
                return text;
            }
        }

        public string GetSeverity(object severity)
        {
            int sever = int.Parse(severity.ToString());
            return "<img src='../" + PortalHelper.TranslateSeverityImages(sever) + "' style='vertical-align:middle;' /> <span class='" + PortalHelper.TranslateSeverityCssClass(sever) + "'>" + PortalHelper.TranslateSeverityText(sever) + "</span>";
        }

        public string GetDateRange(string value)
        {
            FilterDateRange filterDateRange;

            switch (value)
            {
                case "day":
                    filterDateRange = FilterDateRange.Day;
                    break;
                case "week":
                    filterDateRange = FilterDateRange.Week;
                    break;
                case "month":
                    filterDateRange = FilterDateRange.Month;
                    break;
                case "quarter":
                    filterDateRange = FilterDateRange.Quarter;
                    break;
                case "year":
                    filterDateRange = FilterDateRange.Year;
                    break;
                case "all":
                    filterDateRange = FilterDateRange.All;
                    break;
                default:
                    filterDateRange = FilterDateRange.Hour;
                    break;
            }

            return PortalHelper.GetDateParamsQueryString(filterDateRange);
        }

        public string GetEndDate()
        {
            return Server.UrlEncode(DateTime.UtcNow.ToString());
        }

        /// <summary>
        /// Populates the application selection drop down list by calling
        /// the BizTalkOperationsService.
        /// </summary>
        private void populateApplicationList()
        {
            //Call the BTQuery Service
            List<BizTalkOperationsService.BTApplication> applications = PortalHelper.GetAllApplications();

            //Add a default selection to the applications list
            this.appList.Items.Add(new ListItem("All Applications", null));

            //Populate the applications list with the applications from BizTalk
            this.appList.AppendDataBoundItems = true;
            this.appList.DataSource = applications;
            this.appList.DataTextField = "Name";
            this.appList.DataValueField = "Name";
            this.appList.DataBind();
        }

        /// <summary>
        /// Loads the configuration settings from the web.config file.
        /// </summary>
        private void loadConfigSettings()
        {
            lowMediumSeverityThreshold = Convert.ToInt32(ConfigurationManager.AppSettings["SeverityThreshold_LowMedium"]);
            mediumHighSeverityThreshold = Convert.ToInt32(ConfigurationManager.AppSettings["SeverityThreshold_MediumHigh"]);
            lowSeverityImagePath = ConfigurationManager.AppSettings["SeverityImage_Low"];
            mediumSeverityImagePath = ConfigurationManager.AppSettings["SeverityImage_Medium"];
            highSeverityImagePath = ConfigurationManager.AppSettings["SeverityImage_High"];
        }

        /// <summary>
        /// Reads in a set of parameters that were passed in the querystring of the URL.
        /// </summary>
        private void consumeURLParams()
        {
            appList.SelectedValue = Request.QueryString["esb:App"] ?? "All Applications";
            faultCodeBox.Text = Request.QueryString["esb:code"] ?? "";
            failureCategoryBox.Text = Request.QueryString["esb:category"] ?? "";
            errorTypeBox.Text = Request.QueryString["esb:type"] ?? "";
            minFaultSeverityBox.Text = Request.QueryString["esb:minSeverity"] ?? "";
            maxFaultSeverityBox.Text = Request.QueryString["esb:maxSeverity"] ?? "";
        }

        /// <summary>
        /// Gets the image to display for a given fault severity.
        /// Images can be green, yellow, or red circles, depending
        /// on how severe the faults are.
        /// </summary>
        /// <param name="severity">An integer indicating the severity of the fault.</param>
        /// <returns>The full path to the image file to display for the fault severity.</returns>
        protected string getFaultSeverityImagePath(int severity)
        {
            if (severity <= lowMediumSeverityThreshold)
            {
                return lowSeverityImagePath;
            }
            else if ((severity > lowMediumSeverityThreshold) && (severity <= mediumHighSeverityThreshold))
            {
                return mediumSeverityImagePath;
            }
            else //severity > mediumHighSeverityThreshold
            {
                return highSeverityImagePath;
            }
        }

        protected void FaultsDataSource_Selected(object sender, ObjectDataSourceStatusEventArgs e)
        {
            if (e.ReturnValue != null)
            {
                DataTable dt = (DataTable)e.ReturnValue;
                this.labelTotalRecords.Text = "Total records: " + dt.Rows.Count.ToString();
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridView gv = new GridView();
            gv.AllowPaging = false;
            gv.DataSource = GetFaults();
            gv.DataBind();
            gv.Dispose();
           
            GridViewExportUtil.ExcelExport(String.Format("Faults_{0}.xls", DateTime.Now.ToShortDateString()), gv);            
        }

        protected void filter_Click(object sender, EventArgs e)
        {
            BindGrid();
        }

		protected void OnSorting(object sender, GridViewSortEventArgs e)
		{
			DataView dv = new DataView(PortalHelper.GetDataTable(GetFaults()));
			this.SortDirection = this.SortDirection == "asc" ? "desc" : "asc";
			dv.Sort = e.SortExpression + " " + this.SortDirection;
			Faults.DataSource = dv;
			Faults.DataBind();
		}

		protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
		{
			if (e.Row.RowType == DataControlRowType.Header)
			{
				Image img = new Image();
				img.ImageUrl = this.SortDirection == "asc" ? "../images/asc_order.gif" : "../images/desc_order.gif";
				e.Row.Cells[0].Controls.AddAt(0, img);
				e.Row.Cells[0].Controls.AddAt(1, new LiteralControl(" "));
			}
			if (e.Row.RowType == DataControlRowType.DataRow)
			{
				DataRowView drv = e.Row.DataItem as DataRowView;
				Guid faultID = (Guid)DataBinder.Eval(e.Row.DataItem, "FaultID");
				e.Row.Attributes.Add("onclick", "javascript:document.location='FaultViewer.aspx?esb:FaultID=" + faultID.ToString() + "'");
				e.Row.Attributes.Add("class", "GridRow");
				e.Row.Attributes.Add("title", "Click to view fault details");
			}
		}

		protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
		{
			Faults.PageIndex = e.NewPageIndex;
			Faults.DataSource = GetFaults();
			Faults.DataBind();
		}

		protected void OnDateRangeIntervalChanged(object sender, EventArgs e)
		{
			PortalHelper.SetUserFilterDateRange(this.Context, this.dateRangeInterval.SelectedValue);
		}

		protected void OnRecordsPerPageChange(object sender, EventArgs e)
		{
			int page;
			if (int.TryParse(this.recordsPerPage.SelectedValue, out page))
			{
				Faults.PageSize = page;
			}
		}
    }
}