<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="MySetting.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Lists.MySetting" %>


	<script language="javascript">

		function redirect(url)
		{
			document.location = url;
		}
		
		function toggleApplicationSettings(isVisible)
		{
			if(isVisible)
			{
				document.getElementById("applicationSettingsContainer").style.display = "inline";
			}
			else
			{
				document.getElementById("applicationSettingsContainer").style.display = "none";
			}
		}
		
		function selectAllApplications(select)
		{
			var totalAppCount = document.getElementById("totalApplicationCount").value;
			
			for(var i=0; i<totalAppCount; i++)
			{
				if (select)
				{
					document.getElementById("appSetting" + i).checked = true;
				}
				else
				{
					document.getElementById("appSetting" + i).checked = false;
				}
			}
		}
	
	</script>
	<div id="applicationSettingsContainer" style="display: none; position: absolute;
		left: 35px; top: 85px; z-index: 2100; background-color: WhiteSmoke; border: 1px solid black;
		padding: 10px 10px 0px 10px;">
		<div style="clear: both;">
			<div id="applicationSettings" runat="server">
			</div>
			<div style="clear:both; padding-left:8px;">
				Select:&nbsp;&nbsp;<span style="text-decoration:underline; cursor:hand;" onclick="selectAllApplications(true);">All</span>&nbsp;&nbsp;<span style="text-decoration:underline; cursor:hand;"  onclick="selectAllApplications(false);">None</span>
			</div>
		</div>
		<div style="clear: both;">
			<div style="float: left; padding-top: 10px; padding-bottom:8px; margin-left: 0px;">
				<input type="submit" class="formButton" value="Save" style="height: 28px; width:70px; font-size: 11px;" />
				<input type="button" class="formButton" value="Cancel" style="height: 28px; width:70px; font-size: 11px;"
					onclick="toggleApplicationSettings(false);" />
			</div>
		</div>
	</div>
	
	
		<div style="clear: both; padding-bottom: 5px;;">
			<span style="font-family: Trebuchet MS; font-size: 12px; cursor: pointer;" onclick="toggleApplicationSettings(true);">
				<img src="../images/configure.gif" style="vertical-align: middle;" />
				Select Applications</span> <span style="font-family: Trebuchet MS; font-size: 12px;
					margin-left: 10px;">Date Range:
					<asp:DropDownList ID="dropDownTimeRange" runat="server" AutoPostBack="true" Font-Size="12px"
						Font-Names="Trebuchet MS" OnSelectedIndexChanged="dropDownTimeRange_SelectedIndexChanged">
						<asp:ListItem Text="Hour" Value="Hour" />
						<asp:ListItem Text="Day" Value="Day" />
						<asp:ListItem Text="Week" Value="Week" />
						<asp:ListItem Text="Month" Value="Month" />
						<asp:ListItem Text="Quarter" Value="Quarter" />
						<asp:ListItem Text="Year" Value="Year" />
						<asp:ListItem Text="All" Value="All" />
					</asp:DropDownList>
				</span>
		</div>
		
		