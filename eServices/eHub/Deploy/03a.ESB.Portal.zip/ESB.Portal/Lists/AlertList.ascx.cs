//---------------------------------------------------------------------
// File: AlertList.ascx.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using Microsoft.Practices.ESB.Portal.DataSets;
using ESB.Exceptions.Service.Implementation;

namespace Microsoft.Practices.ESB.Portal.Lists
{
    public partial class AlertList : System.Web.UI.UserControl
    {
        private DataSets.Alerts.AlertDataTable alertDataTable = new Microsoft.Practices.ESB.Portal.DataSets.Alerts.AlertDataTable();
        private DataSets.Alerts.AlertSubscriptionDataTable alertSubscriptionDataTable = new Microsoft.Practices.ESB.Portal.DataSets.Alerts.AlertSubscriptionDataTable();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                IExceptionService client = null;
                try
                {
                    client = PortalHelper.GetExceptionService();

                    //client.GetAlerts();

                    DataSets.AlertsTableAdapters.AlertTableAdapter alertTableAdapter = new Microsoft.Practices.ESB.Portal.DataSets.AlertsTableAdapters.AlertTableAdapter();
                    alertTableAdapter.FillAlerts(alertDataTable);

                    DataSets.AlertsTableAdapters.AlertSubscriptionTableAdapter alertSubscriptionTableAdapter = new Microsoft.Practices.ESB.Portal.DataSets.AlertsTableAdapters.AlertSubscriptionTableAdapter();
                    alertSubscriptionTableAdapter.FillAlertSubscriptions(alertSubscriptionDataTable);

                    this.Repeater1.ItemDataBound += new RepeaterItemEventHandler(Repeater1_ItemDataBound);
                    this.Repeater1.DataSource = alertDataTable;
                    this.Repeater1.DataBind();

                    this.GridView1.DataSource = alertDataTable;
                    this.GridView1.DataBind();

                    DataSets.AlertsTableAdapters.AlertSubscriptionTableAdapter ta = new Microsoft.Practices.ESB.Portal.DataSets.AlertsTableAdapters.AlertSubscriptionTableAdapter();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }
        }

        void AlertsGridView_RowCreated(object sender, RepeaterItemEventArgs e)
        {
        }

        protected string GetCrumbedString(object t, int crumbAt)
        {
            string text = t.ToString();
            if (text.Length > crumbAt)
            {
                return "<span title='" + text + "'>" + PortalHelper.CrumbString(text, crumbAt) + "</span>";
            }
            else
            {
                return text;
            }
        }


        void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataSets.Alerts.AlertRow alertRow = (DataSets.Alerts.AlertRow)((DataRowView)e.Item.DataItem).Row;

                Label labelDeletable = e.Item.FindControl("labelDeletable") as Label;
                Label labelAlertName = e.Item.FindControl("labelAlertName") as Label;
                LinkButton linkAlertViewer = e.Item.FindControl("linkAlertViewer") as LinkButton;
                ImageButton imageButtonAlertViewer = e.Item.FindControl("imageButtonAlertViewer") as ImageButton;
                ImageButton imageButtonDelete = e.Item.FindControl("imageButtonDelete") as ImageButton;
                ImageButton imageButtonSubscribe = e.Item.FindControl("imageButtonSubscribe") as ImageButton;

                labelAlertName.Text = alertRow.Name;
                linkAlertViewer.ToolTip = "View Alert '" + alertRow.Name + "'";
                linkAlertViewer.PostBackUrl = "../Alerts/AlertViewer.aspx?esb:AlertID=" + alertRow.AlertID.ToString();
                imageButtonAlertViewer.PostBackUrl = "../Alerts/AlertViewer.aspx?esb:AlertID=" + alertRow.AlertID.ToString();
                imageButtonDelete.Visible = false;
                
                if (isDeletable(alertRow))
                {
                    labelDeletable.Text = "<span class=\"linkUnderline\" onclick=\"javascript:deleteAlert('" + Server.UrlEncode(alertRow.AlertID.ToString()) + "');\">Delete</span>";
                    imageButtonDelete.Visible = true;
                    imageButtonDelete.Attributes.Add("onclick", "javascript:deleteAlert('" + Server.UrlEncode(alertRow.AlertID.ToString()) + "');");
                }
            }
        }

        private bool isDeletable(DataSets.Alerts.AlertRow alertRow)
        {
            if (string.Compare(alertRow.InsertedBy, Context.User.Identity.Name, true) == 0)
            {
                DataTable dt = (DataTable)alertSubscriptionDataTable;

                int subscriptionCount = dt.Select("[AlertID]='" + alertRow.AlertID.ToString() + "'").Length;

                if (subscriptionCount == 0)
                {
                    return true;
                }
            }
            return false;
        }
    }
}