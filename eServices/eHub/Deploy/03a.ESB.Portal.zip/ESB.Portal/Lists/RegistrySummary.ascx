<%@ Control Language="C#" AutoEventWireup="true" Codebehind="RegistrySummary.ascx.cs"
	Inherits="Microsoft.Practices.ESB.Portal.Lists.RegistrySummary" %>
<asp:Repeater ID="Repeater1" runat="server">
	<ItemTemplate>
		<div id="registrySummaryRow" class="summaryAreaRow" runat="server" onmouseover="this.style.backgroundColor='whitesmoke';"
			onmouseout="this.style.backgroundColor='#ffffff';">
			<div class="summaryColumn0">
				<asp:Label ID="labelBindingType" runat="server"></asp:Label></div>
			<div class="summaryColumn1" style="width:250px;">
				<asp:Label ID="labelEndPointName" runat="server"></asp:Label></div>
			<div class="summaryColumn2" style="width:170px;">
				<asp:Label ID="labelSubmittedBy" runat="server"></asp:Label></div>
		</div>
		<div class="faultSummaryRowBreak">
		</div>
	</ItemTemplate>
</asp:Repeater>
