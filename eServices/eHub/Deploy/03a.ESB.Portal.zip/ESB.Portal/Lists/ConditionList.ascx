<%@ Control Language="C#" AutoEventWireup="true" Codebehind="ConditionList.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Lists.ConditionList" %>

<div class="formHeader">Conditions</div>
<table>
    <tr>
        <td align="right">
                <asp:LinkButton ID="linkButtonDelete" runat="server" OnClick="linkButtonDelete_Click"
                    Visible="False">Delete</asp:LinkButton>
        </td>
    </tr>
    <tr>
        <td align="left">
            <asp:GridView ID="GridView1" runat="server" 
	            AutoGenerateColumns="False"
	            Width="600px" PageSize="100" BorderWidth="0">
	            <HeaderStyle CssClass="tableHeader" />
	            <RowStyle CssClass="tableRow" />
	            <Columns>
                    <asp:TemplateField Visible="false" >
                        <ItemTemplate>
                            <asp:Label runat="server"  ID="AlertConditionId" Text='<%# Eval("AlertConditionId") %>' Visible="false" />
                        </ItemTemplate>
                    </asp:TemplateField>
	                <asp:BoundField DataField="AlertId" Visible="false" />
	                <asp:BoundField DataField="LeftSide"  HeaderText="Criteria" />
	                <asp:BoundField DataField="Operator" HeaderText="Operator" />
	                <asp:BoundField DataField="RightSide" HeaderText="Value" ItemStyle-Width="400px" />
                    <asp:TemplateField >
                        <ItemTemplate>
                            <asp:CheckBox runat="server"  ID="RowLevelCheckBox" />
                        </ItemTemplate>
                    </asp:TemplateField>
	            </Columns>
            </asp:GridView>
        </td>
    </tr>
</table>
