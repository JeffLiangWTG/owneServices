//---------------------------------------------------------------------
// File: RegistrySummary.ascx.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Microsoft.Practices.ESB.Portal.Lists
{
    public partial class RegistrySummary : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            Uddi.UDDIPendingRequestsDbTableAdapters.usp_get_pending_requestsTableAdapter da = new Microsoft.Practices.ESB.Portal.Uddi.UDDIPendingRequestsDbTableAdapters.usp_get_pending_requestsTableAdapter();
            Uddi.UDDIPendingRequestsDb.usp_get_pending_requestsDataTable dt = da.GetData();

            this.Repeater1.ItemDataBound += new RepeaterItemEventHandler(Repeater1_ItemDataBound);
            this.Repeater1.DataSource = dt;
            this.Repeater1.DataBind();

        }

        void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            System.Data.DataRowView drv = (DataRowView)e.Item.DataItem;
            Uddi.UDDIPendingRequestsDb.usp_get_pending_requestsRow dr = (Uddi.UDDIPendingRequestsDb.usp_get_pending_requestsRow) drv.Row;

            HtmlGenericControl registrySummaryRow = e.Item.FindControl("registrySummaryRow") as HtmlGenericControl;
            registrySummaryRow.Attributes.Add("onclick", "parent.document.location='../Uddi/UDDIDetails.aspx?id=" + Server.UrlEncode(dr.BiztalkApplication + "|" + dr.EndpointName) + "'");

            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                ((Label)(e.Item.FindControl("labelEndPointName"))).Text = PortalHelper.CrumbString(dr.EndpointName, 40);
                ((Label)(e.Item.FindControl("labelBindingType"))).Text = EndPointIcon(dr.BindingType.ToString()) + dr.BindingType;
                ((Label)(e.Item.FindControl("labelSubmittedBy"))).Text = PortalHelper.CrumbString(dr.ModifiedBy, 30);
            }
        }

        string EndPointIcon(string endpointName)
        {
            string spacer = "<img src='../images/spacer.gif' width='2px'>";
            switch (endpointName.ToLower())
            {
                case "send":
                    return "<img src='../images/icons/16_send.gif'>" + spacer ;
                case "receive":
                    return "<img src='../images/icons/16_receive.gif'>" + spacer;
                default:
                    return "<img src='../images/spacer.gif' width='16px' height='16px'>" + spacer;
            }
        }
    }
}