<%@ Control Language="C#" AutoEventWireup="true" Codebehind="AlertSummary.ascx.cs"
	Inherits="Microsoft.Practices.ESB.Portal.Lists.AlertSummary" %>
<asp:Repeater ID="Repeater1" runat="server" OnItemCommand="Repeater1_ItemCommand">
	<ItemTemplate>
		<div id="alertSummaryRow" class="summaryAreaRow" style="font-size:11px;" runat="server" onmouseover="this.style.backgroundColor='whitesmoke';"
			onmouseout="this.style.backgroundColor='#ffffff';">
			<div style="float:left; width:190px; padding-top:5px;"><img alt='Alert' src="../Images/Icons/16_alert.gif" style="vertical-align:middle;" /><img alt='' src="../Images/spacer.gif" width="4px" /><asp:Label ID="labelAlertName" runat="server" /> </div> 
			<div style="float:left; width:100px; padding-top:5px; padding-left:10px;"><asp:Label ID="labelApplication" runat="server" /> </div> 
			<div style="float:left; width:90px; padding-top:5px; padding-left:10px;"><asp:Label ID="labelService" runat="server" /> </div> 
			<div style="float:left; width:90px; padding-top:5px; padding-left:10px;"><asp:Label ID="labelAlertDate" runat="server" /></div>
		</div>
		<div class="faultSummaryRowBreak">
		</div>
	</ItemTemplate>
</asp:Repeater>
