//---------------------------------------------------------------------
// File: RegistrySummaryContainer.aspx.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Microsoft.Practices.ESB.Portal.Lists
{
    public partial class RegistrySummaryContainer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
        }

        protected void Page_PreRender(object s, EventArgs e)
        {
            Uddi.UDDIPendingRequestsDbTableAdapters.usp_get_pending_requestsTableAdapter da = new Microsoft.Practices.ESB.Portal.Uddi.UDDIPendingRequestsDbTableAdapters.usp_get_pending_requestsTableAdapter();
            Uddi.UDDIPendingRequestsDb.usp_get_pending_requestsDataTable dt = da.GetData();

            if (dt.Rows.Count == 0)
            {
                linkPendingRequests.InnerText = "There are no pending requests.";
            }
            else
            {
                linkPendingRequests.InnerText = "There are " + dt.Rows.Count.ToString() + " pending requests.";
            }

            Uddi.UDDIAdminDbTableAdapters.usp_get_uddi_adminTableAdapter ta = new Microsoft.Practices.ESB.Portal.Uddi.UDDIAdminDbTableAdapters.usp_get_uddi_adminTableAdapter();

            Uddi.UDDIAdminDb.usp_get_uddi_adminRow dr = ta.GetData(1).Rows[0] as Uddi.UDDIAdminDb.usp_get_uddi_adminRow;


            if (dr.AutoPublish)
            {
                this.labelAutoPublishSwitch.Text = "ON";
                this.labelAutoPublishSwitch.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                this.labelAutoPublishSwitch.Text = "OFF";
                this.labelAutoPublishSwitch.ForeColor = System.Drawing.Color.DarkBlue;
            }
        }
    }
}
