<%@ Control Language="C#" AutoEventWireup="true" Codebehind="FaultsSummary.ascx.cs"
	Inherits="Microsoft.Practices.ESB.Portal.Lists.FaultsSummary" %>
<asp:Repeater ID="repeaterFaults" runat="server">
	<ItemTemplate>
		<div id="linkApplicationFault" runat="server" class="faultsApplicationTitle" ></div>
		<!--
		<div style="background-color: #24618E; width:100%; height:2px; clear:both;"></div>
		<div style="clear:both;">
		-->
	<asp:Repeater ID="Repeater1" runat="server">
	
		<ItemTemplate>
			<div id="faultsSummaryRow" class="summaryAreaRow" runat="server" onmouseover="this.style.backgroundColor='whitesmoke';" onmouseout="this.style.backgroundColor='#ffffff';"
				style="vertical-align:middle;">
				<div class="summaryColumn0" style="vertical-align:middle;"><span id="severityIcon" runat="server"></span><span id="severityText" runat="server"></span></div>
				<div class="summaryColumn1" style="vertical-align:middle; padding-top:0px;"><asp:Label ID="labelServiceName" runat="server"/></div>
				<div class="summaryColumn2" style="vertical-align:middle; padding-top:0px;"><asp:Label ID="labelErrorType" runat="server"/></div>
				<div class="summaryColumn3" style="vertical-align:middle; padding-top:0px;"><asp:Label ID="labelDateTime" runat="server"/></div>
			</div>
			<div class="faultSummaryRowBreak"></div>
		</ItemTemplate>
	</asp:Repeater>		
		<!--	
		</div>
		<br />
		-->
	</ItemTemplate>
</asp:Repeater>
