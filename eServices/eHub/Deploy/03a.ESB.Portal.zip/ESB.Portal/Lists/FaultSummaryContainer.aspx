<%@ Page Language="C#" AutoEventWireup="true" Codebehind="FaultSummaryContainer.aspx.cs"
	Inherits="Microsoft.Practices.ESB.Portal.Lists.FaultSummaryContainer" %>

<%@ Register Src="FaultsSummary.ascx" TagName="FaultsSummary" TagPrefix="uc1" %>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
	<title>Untitled Page</title>
	<link type="text/css" rel="stylesheet" href="../css/Style.css" />
	<script src="../Script/Scripts.js"></script>
</head>
<body style="margin: 0px; padding: 0px;">
	<form id="form1" runat="server" class="formContainer">
		<div class="sectionContainer">
			<h2>Faults</h2>
			<div style="line-height: 20px;">
				Total Faults: <asp:Label ID="label1" runat="server"></asp:Label></span> | 
				Sort By:
				<asp:RadioButton ID="sortDate" runat="server" Text="Date" Checked="true" GroupName="SortFilter"
					AutoPostBack="true" />&nbsp;
				<asp:RadioButton ID="sortFilter" runat="server" Text="Severity" GroupName="SortFilter"
					AutoPostBack="true" />
			</div>

			<asp:Label ID="labelFaultSummaryTotalCount" runat="server"></asp:Label>
			<div class="summaryContainer" style="padding: 0px; margin: 0px; height:410px; border-style:none;">
				<div class="summaryArea">
					<div class="summaryHeader">
						<div class="summaryColumn0 summaryHeaderColumn">
							Severity</div>
						<div class="summaryColumn1 summaryHeaderColumn">
							Service Name</div>
						<div class="summaryColumn2 summaryHeaderColumn">
							Error</div>
						<div class="summaryColumn3 summaryHeaderColumn">
							Date</div>
					</div>
					<div style="overflow: auto; height: 395px; border: 0px solid black;">
						<uc1:FaultsSummary ID="FaultsSummary1" runat="server" />
					</div>
				</div>
			</div>

		</div>
	</form>
</body>
</html>
