//---------------------------------------------------------------------
// File: ConditionList.ascx.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Microsoft.Practices.ESB.Portal.Lists
{
    public partial class ConditionList : System.Web.UI.UserControl
    {
        private DataSets.Alerts.AlertConditionDataTable alertConditions;

        public DataSets.Alerts.AlertConditionDataTable AlertConditions
        {
            get { return alertConditions; }
            set { alertConditions = value; }
        }


        private void BindAlertConditions()
        {
            this.GridView1.DataSource = alertConditions;
            this.GridView1.DataBind();

            if(this.GridView1.Rows.Count > 0)
                this.linkButtonDelete.Visible = true;
            else
                this.linkButtonDelete.Visible = false;

        }


        protected void Page_PreRender(object sender, EventArgs e)
        {
            BindAlertConditions();         
        }

        protected void linkButtonDelete_Click(object sender, EventArgs e)
        {

            //Enumerate the GridViewRows
            for(int x=0; x < GridView1.Rows.Count; x++)
            {
                //Programmatically access the CheckBox from the TemplateField
                CheckBox cb = (CheckBox) GridView1.Rows[x].FindControl("RowLevelCheckBox");
                
                //If it's checked, delete it...
                if(cb.Checked == true)
                {
                    Label AlertConditionId = (Label) GridView1.Rows[x].FindControl("AlertConditionId");
                    Guid aid = new Guid(AlertConditionId.Text);
                    if (alertConditions != null)
                    {
                        DataSets.Alerts.AlertConditionRow row = alertConditions.FindByAlertConditionID(aid);
                        alertConditions.RemoveAlertConditionRow(row);
                    }
                }

            }

            BindAlertConditions();
        }


        protected bool RemoveCondition(string AlertConditionId)
        {
            return true;
        }
    }
}