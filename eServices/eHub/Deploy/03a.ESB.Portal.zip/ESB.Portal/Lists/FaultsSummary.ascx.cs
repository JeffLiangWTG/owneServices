//---------------------------------------------------------------------
// File: FaultsSummary.ascx.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;
using System.Reflection;

namespace Microsoft.Practices.ESB.Portal.Lists
{
    public partial class FaultsSummary : System.Web.UI.UserControl
    {
        Hashtable applicationCounts = new Hashtable();

        protected void Page_Load(object sender, EventArgs e)
        {

            SortedList faultApplication = new SortedList();

            int totalCount = 0;
            DateTime stime = PortalHelper.GetUserStartDate(Context);
            DateTime etime = DateTime.UtcNow;
            foreach (string application in PortalHelper.GetUserApplications(this.Context))
            {
                IExceptionService client = null;
                try
                {
                    client = PortalHelper.GetExceptionService();

                    List<Fault> faults = client.GetFaults(Guid.Empty, application, stime, etime, null, null, null, 4);

                    faultApplication.Add(application, faults);

                    applicationCounts.Add(application, faults.Count);
                    totalCount += faults.Count;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }
            }

            Session["FaultSummaryTotalCount"] = totalCount;
            this.repeaterFaults.ItemDataBound += new RepeaterItemEventHandler(repeaterFaults_ItemDataBound);
            this.repeaterFaults.DataSource = faultApplication;
            this.repeaterFaults.DataBind();
        }

        void repeaterFaults_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DictionaryEntry de = (DictionaryEntry)e.Item.DataItem;
                Repeater r = ((Repeater)(e.Item.FindControl("Repeater1")));

                List<Fault> faults = de.Value as List<Fault>;

                DataView dv = new DataView(PortalHelper.GetDataTable(faults));

                if (dv.Count > 0)
                {
                    if (Session["FaultSummarySort"] != null)
                    {
                        if (Session["FaultSummarySort"].ToString() == "Severity")
                        {
                            dv.Sort = "FaultSeverity desc, DateTime desc";
                        }
                    }
                    else
                    {
                        dv.Sort = "DateTime desc";
                    }
                }

                r.ItemDataBound += new RepeaterItemEventHandler(Repeater1_ItemDataBound);
                FilterRows dv5 = new FilterRows(dv, 5);

                r.DataSource = dv5;
                r.DataBind();

                HtmlGenericControl linkApplicationFault = (HtmlGenericControl)(e.Item.FindControl("linkApplicationFault"));
                string appFaultsLink = "<a href=\"javascript:parent.redirect('../Faults/Faults.aspx?esb:app=" + Server.UrlEncode(de.Key.ToString()) + "&" + PortalHelper.GetDateParamsQueryString(PortalHelper.GetUserFilterDateRange(this.Context)) + "');\" title=\"View faults for " + de.Key.ToString() + "\" >";

                int appTotalRecordCount = (int)applicationCounts[de.Key.ToString()];

                if (appTotalRecordCount == 0)
                {
                    linkApplicationFault.Visible = false;
                }
                else if (appTotalRecordCount == 1)
                {
                    appFaultsLink += de.Key.ToString() + "&nbsp;&nbsp;(1 item)</a>";
                }
                else
                {
                    appFaultsLink += de.Key.ToString() + "&nbsp;&nbsp;(" + dv5.Count.ToString() + " of " + (appTotalRecordCount).ToString() + " items)</a>";
                }

                linkApplicationFault.InnerHtml = appFaultsLink;
            }
        }

        void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            System.Data.DataRowView dr = e.Item.DataItem as DataRowView;

            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HtmlGenericControl severityIcon = e.Item.FindControl("severityIcon") as HtmlGenericControl;
                HtmlGenericControl severityText = e.Item.FindControl("severityText") as HtmlGenericControl;

                int faultSeverity = (int)dr["FaultSeverity"];

                severityIcon.InnerHtml = "<img src='../" + PortalHelper.TranslateSeverityImages(faultSeverity) + "' style='vertical-align:middle;'>&nbsp;";

                severityText.Attributes.Add("class", PortalHelper.TranslateSeverityCssClass(faultSeverity));
                severityText.InnerText = PortalHelper.TranslateSeverityText(faultSeverity);

                HtmlGenericControl faultsSummaryRow = e.Item.FindControl("faultsSummaryRow") as HtmlGenericControl;
                faultsSummaryRow.Attributes.Add("onclick", "parent.document.location='../Faults/FaultViewer.aspx?esb:FaultID=" + dr["FaultID"].ToString() + "'");

                Label labelErrorType = e.Item.FindControl("labelErrorType") as Label;

                labelErrorType.Text = PortalHelper.CrumbString(dr["ErrorType"].ToString(), 15);
                labelErrorType.ToolTip = dr["ErrorType"].ToString();

                Label labelServiceName = e.Item.FindControl("labelServiceName") as Label;
                labelServiceName.Text = PortalHelper.CrumbString(dr["ServiceName"].ToString(), 25);
                labelServiceName.ToolTip = dr["ServiceName"].ToString();

                ((Label)(e.Item.FindControl("labelDateTime"))).Text = PortalHelper.UTC_to_ClientLocalTime(dr["DateTime"]).ToString();
            }
        }
    }
}