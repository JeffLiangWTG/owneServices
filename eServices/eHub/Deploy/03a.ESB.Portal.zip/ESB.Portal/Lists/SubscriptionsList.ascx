<%@ Control Language="C#" AutoEventWireup="true" Codebehind="SubscriptionsList.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Lists.SubscriptionsList" %>

<script type="text/javascript" language="javascript" src="../Script/Scripts.js"></script>


<h2 class="iconAddSubscriber">My Subscriptions</h2>
<asp:Label ID="lblNoneFound" ForeColor="Red" Visible="false" runat="server">No subscriptions were found.</asp:Label>
	<asp:GridView 
		ID="GridView1" 
		runat="server" 
		AutoGenerateColumns="False" 
		GridLines="None" 
		OnPreRender="GridView1_PreRender"
		Width="500"
		>
	<HeaderStyle CssClass="tableHeader" />
	<RowStyle CssClass="tableRow" />
		<Columns>
			<asp:TemplateField HeaderText="Alert">
				<ItemTemplate>
					<%# Eval("AlertName") %>
				</ItemTemplate>
			</asp:TemplateField>
			<asp:TemplateField HeaderText="Type">
				<ItemTemplate>
					<%#System.Convert.ToBoolean(Eval("IsGroup")) ? "Group" : "User" %>
				</ItemTemplate>
			</asp:TemplateField>
			<asp:BoundField DataField="Subscriber" HeaderText="Subscriber" ReadOnly="True" Visible="False" />
			<asp:TemplateField HeaderText="Start Time">
				<ItemTemplate>
				   
				<%# System.Convert.ToBoolean( Eval("UseStartAndEndTime"))? GetLocalTime(Eval("startUTCHour"), Eval("startUTCMinute")):"12:00AM" %>
				</ItemTemplate>
			</asp:TemplateField>
			<asp:TemplateField HeaderText="End Time">
				<ItemTemplate>
					<%# System.Convert.ToBoolean(Eval("UseStartAndEndTime")) ? GetLocalTime(Eval("endUTCHour"), Eval("endUTCMinute")) : "12:00AM"%>
				</ItemTemplate>
			</asp:TemplateField>
			<asp:TemplateField>
				<ItemTemplate>
					<img src="../Images/Icons/16_edit.gif" />
					<a href="EditSubscription.aspx?esb:AlertID=<%# Eval("AlertID") %>&id=<%# Eval("AlertSubscriptionID") %>">Edit</a>
				</ItemTemplate>
			</asp:TemplateField>
			<asp:TemplateField>
				<ItemTemplate>
					<img src="../Images/Icons/16_delete.gif" />
					<a onclick="return confirm('Are you sure you want to delete this subscription?')" href="DeleteSubscription.aspx?esb:AlertID=<%# Eval("AlertID") %>&esb:SubscriptionID=<%# Eval("AlertSubscriptionID") %>">Unsubscribe</a>
				</ItemTemplate>
			</asp:TemplateField>
		</Columns>
	</asp:GridView>