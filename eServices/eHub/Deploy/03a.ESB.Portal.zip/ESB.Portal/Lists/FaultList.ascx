<%@ Control Language="C#" AutoEventWireup="true" Codebehind="FaultList.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Lists.FaultList" %>
<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers"
    TagPrefix="cc1" %>
<%@ Register Assembly="Microsoft.ReportViewer.WebForms, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a" Namespace="Microsoft.Reporting.WebForms" TagPrefix="rsweb" %>

<script language="javascript" src="../Script/Scripts.js"></script>

<script language="javascript" type="text/javascript">
            function getDateRange(filterDateRange)
            {
				switch(filterDateRange)
				{
					case "day":
						return '<%=GetDateRange("day")%>';
						break;
					case "week":
						return '<%=GetDateRange("week")%>';
						break;
					case "month":
						return '<%=GetDateRange("month")%>';
						break;
					case "quarter":
						return '<%=GetDateRange("quarter")%>';
						break;
					case "year":
						return '<%=GetDateRange("year")%>';
						break;

					case "all":
						return '<%=GetDateRange("all")%>';
						break;
					default:
						return '<%=GetDateRange("hour")%>';
						break;
				}
            }
            
			
			/// <summary>
			/// Applies the filters that the user selected in the fault list.  This works by appending the filter
			/// values to the URL, and resubmitting the page form.
			/// </summary>
			/// <param name="mainForm">DHTML form object.  This should be the main form for the page.</param>
			function submitFilters(mainForm)
			{
				var selectedDateRange = document.getElementById("<%=dateRangeInterval.ClientID%>").value;
				if (selectedDateRange == "year" || selectedDateRange == "all")
				{
					/*
					if (!confirm("The time range you have selected may return too many results.  Do you want to continue?"))
					{
						return;
					}
					*/
				}
				
			    var navigateUrl = stripESBQueryStringParams(mainForm.action);	  
			    
			    if(navigateUrl.indexOf("?") < 0)
			    {
			        navigateUrl += "?";
			    }
			    else
			    {
			        navigateUrl += "&";
			    }
			    
			    
			    navigateUrl += ((document.getElementById("<%=appList.ClientID%>").value == "") || (document.getElementById("<%=appList.ClientID%>").value == "All Applications")) ? "" : ("esb:App=" + document.getElementById("<%=appList.ClientID%>").value + "&");
			    navigateUrl += (document.getElementById("<%=faultCodeBox.ClientID%>").value == "") ? "" : ("esb:code=" + document.getElementById("<%=faultCodeBox.ClientID%>").value + "&");
			    navigateUrl += (document.getElementById("<%=failureCategoryBox.ClientID%>").value == "") ? "" : ("esb:category=" + document.getElementById("<%=failureCategoryBox.ClientID%>").value + "&");
			    navigateUrl += (document.getElementById("<%=errorTypeBox.ClientID%>").value == "") ? "" : ("esb:type=" + document.getElementById("<%=errorTypeBox.ClientID%>").value + "&");
			    navigateUrl += (document.getElementById("<%=minFaultSeverityBox.ClientID%>").value == "") ? "" : ("esb:minSeverity=" + document.getElementById("<%=minFaultSeverityBox.ClientID%>").value + "&");
			    navigateUrl += (document.getElementById("<%=maxFaultSeverityBox.ClientID%>").value == "") ? "" : ("esb:maxSeverity=" + document.getElementById("<%=maxFaultSeverityBox.ClientID%>").value + "&");			    
			    navigateUrl += getDateRange(selectedDateRange);
			    
			    
			    //Clean up the end of the querystring.
                if(navigateUrl.substring(navigateUrl.length - 1, navigateUrl.length) == "?"
                    || navigateUrl.substring(navigateUrl.length - 1, navigateUrl.length) == "&")
                {
                    navigateUrl = navigateUrl.substring(0, navigateUrl.length - 1);
                }  
			    
			    document.getElementById('resetGrid').value = "true";
			    mainForm.action = navigateUrl;
			    mainForm.submit();
			}			
</script>
<input type="hidden" id='resetGrid" ' name="resetGrid" value="false" />
<!-- Filter Start -->
<div class="filterHeader">Filter Results</div>
<div class="filterTable">
	<div class="filterRow">
		<div class="filterCell">
			Application:&nbsp;
			<asp:DropDownList ID="appList" runat="server" CssClass="formDropDown" /></div>
		<div class="filterCell">
			Retrieve records within last  
			<asp:DropDownList ID="dateRangeInterval" runat="server" CssClass="formDropDown" 
                onselectedindexchanged="OnDateRangeIntervalChanged" >
				<asp:ListItem Text="hour" Value="hour"></asp:ListItem>
				<asp:ListItem Text="day" Value="day"></asp:ListItem>
				<asp:ListItem Text="week" Value="week"></asp:ListItem>
				<asp:ListItem Text="month" Value="month"></asp:ListItem>
				<asp:ListItem Text="quarter" Value="quarter"></asp:ListItem>
				<asp:ListItem Text="year" Value="year"></asp:ListItem>
				<asp:ListItem Text="all" Value="all"></asp:ListItem>
			</asp:DropDownList>
		</div>
		<div class="filterCell">
			Records Per Page:
			<asp:DropDownList ID="recordsPerPage" runat="server" CssClass="formDropDown" 
                onselectedindexchanged="OnRecordsPerPageChange" >
				<asp:ListItem Text="10" Value="10"></asp:ListItem>
				<asp:ListItem Text="20" Value="20" Selected="true"></asp:ListItem>
				<asp:ListItem Text="50" Value="50"></asp:ListItem>
				<asp:ListItem Text="100" Value="100"></asp:ListItem>
			</asp:DropDownList>
		</div>
	</div>
	<div class="filterRow">
		<div class="filterCell">
			Fault Code:&nbsp;
			<asp:TextBox ID="faultCodeBox" runat="server" CssClass="formFieldInput"></asp:TextBox></div>
		<div class="filterCell">
			Fault Category:&nbsp;
			<asp:TextBox ID="failureCategoryBox" runat="server" CssClass="formFieldInput"></asp:TextBox></div>
		<div class="filterCell">
			Error Type:&nbsp;
			<asp:TextBox ID="errorTypeBox" runat="server" CssClass="formFieldInput"></asp:TextBox></div>
		<div class="filterCell">
			Min. Fault Severity (1-4):&nbsp;
			<asp:TextBox ID="minFaultSeverityBox" runat="server" CssClass="formFieldInput"></asp:TextBox></div>
		<div class="filterCell">
			Max. Fault Severity (1-4):&nbsp;<asp:TextBox ID="maxFaultSeverityBox" runat="server" CssClass="formFieldInput"></asp:TextBox></div>
	</div>
	<div style="clear: both;">
	    <asp:Button ID="filter" runat="server" Text="Apply Filters" 
            onclick="filter_Click" CssClassclass="formButton" />
		<%--<input id="filterButton" class="formButton" type="button" style="width:100px" value="Apply Filters" onclick="submitFilters(document.forms[0]);" />--%>
	</div>
</div>

<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td>
            <asp:ImageButton ID="ImageButton1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
            <asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton>
        </td>
    <td align="right">
        <div class="tableResultCount"><asp:Label ID="labelTotalRecords" runat="server"></asp:Label></div>
    </td>
    </tr>
    <tr>
        <td colspan="2">
        <!-- Faults Table Start -->
        <asp:GridView 
	        ID="Faults" runat="server" AllowPaging="True" AllowSorting="True"
	        AutoGenerateColumns="False" DataKeyNames="FaultID"
	        Width="100%" PageSize="20" BorderWidth="0px" 
                onpageindexchanging="OnPageIndexChanging" onsorting="OnSorting" 
                onrowdatabound="OnRowDataBound">
	        <HeaderStyle CssClass="tableHeader" />
	        <RowStyle CssClass="tableRow" />
	        <Columns>
		        <asp:TemplateField HeaderText="Severity" SortExpression="FaultSeverity">
			        <ItemTemplate>
				        <%# GetSeverity(DataBinder.Eval(Container.DataItem, "FaultSeverity"))  %>
			        </ItemTemplate>		
                    <ItemStyle Wrap="False" />
		        </asp:TemplateField>
		        <asp:TemplateField HeaderText="Date" SortExpression="DateTime">
			        <ItemTemplate>
				        <%# Microsoft.Practices.ESB.Portal.PortalHelper.UTC_to_ClientLocalTime(DataBinder.Eval(Container.DataItem, "DateTime")).ToString() %>
			        </ItemTemplate>
			        <HeaderStyle HorizontalAlign="Center" />
                    <ItemStyle Wrap="False" />
		        </asp:TemplateField>
		        <asp:BoundField DataField="FaultCode" HeaderText="Code" SortExpression="FaultCode" />
		        <asp:BoundField DataField="FailureCategory" HeaderText="Category" SortExpression="FailureCategory" />
		        <asp:BoundField DataField="Application" HeaderText="Application" SortExpression="Application" />
		        <asp:TemplateField  HeaderText="Error Type" SortExpression="ErrorType">
			        <ItemTemplate>
				        <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "ErrorType"), 35)%>
			        </ItemTemplate>
		        </asp:TemplateField>
		        <asp:TemplateField  HeaderText="Scope" SortExpression="Scope">
			        <ItemTemplate>
				        <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "Scope"), 50)%>
			        </ItemTemplate>
		        </asp:TemplateField>
		        <asp:TemplateField HeaderText="Service Name" SortExpression="ServiceName">
			        <ItemTemplate>
				        <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "ServiceName"), 40)%>
			        </ItemTemplate>
		        </asp:TemplateField>
		        <asp:BoundField DataField="FaultGenerator" HeaderText="Fault Generator" SortExpression="FaultGenerator" />
		        <asp:BoundField DataField="MachineName" HeaderText="Machine Name" SortExpression="MachineName" />
	        </Columns>
        	
        </asp:GridView>
        <cc1:GridViewSortExtender ID="GridViewSortExtender1" runat="server" AscendingImageUrl="~/Images/asc_order.gif"
            DescendingImageUrl="~/Images/desc_order.gif" ExtendeeID="Faults">
        </cc1:GridViewSortExtender>
        <!-- Faults Table End -->

        </td>
    </tr>
</table>
<!-- Filter Start -->


<!-- Data Binding Start -->
<%--<asp:ObjectDataSource ID="FaultsDataSource" runat="server" OldValuesParameterFormatString="original_{0}"
	SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.FaultsTableAdapters.Faults2TableAdapter"  OnSelected="FaultsDataSource_Selected" OnSelecting="FaultsDataSource_Selecting" >
	<SelectParameters>
		<asp:QueryStringParameter Name="FaultID" QueryStringField="esb:faultID" Type="String"/>
		<asp:QueryStringParameter Name="Application" QueryStringField="esb:app" Type="String" DefaultValue="" />
		<asp:QueryStringParameter Name="StartDate" QueryStringField="esb:startDate"
			Type="DateTime"/>
		<asp:QueryStringParameter Name="EndDate" QueryStringField="esb:endDate"
			Type="DateTime" />
		<asp:QueryStringParameter Name="FaultCode" QueryStringField="esb:code" Type="String" />
		<asp:QueryStringParameter Name="FailureCategory" QueryStringField="esb:category"
			Type="String" />
		<asp:QueryStringParameter Name="ErrorType" QueryStringField="esb:type" Type="String" DefaultValue="" />
		<asp:QueryStringParameter Name="MaxFaultSeverity" QueryStringField="esb:maxSeverity"
			Type="Int32" DefaultValue="4"/>
		<asp:Parameter Name="Debug" Type="Boolean" DefaultValue="False" />
	</SelectParameters>
</asp:ObjectDataSource>--%><!-- Data Binding End -->