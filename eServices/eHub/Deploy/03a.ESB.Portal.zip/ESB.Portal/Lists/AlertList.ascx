<%@ Control Language="C#" AutoEventWireup="true" Codebehind="AlertList.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Lists.AlertList" %>

<script type="text/javascript" language="javascript">
	function deleteAlert(alertId)
	{
		if (confirm("Are you sure you want to delete this alert?"))
		{
			document.location = "../Admin/DeleteAlert.aspx?esb:AlertId=" + alertId + "&UrlReferrer=..%2fAlerts%2fAlerts.aspx";
		}
	}
	
	
</script>

<h1 class="iconAlert">Alerts</h1>

<table cellspacing="0" cellpadding="0" border="0" width="100%">
	<tr class="tableHeader">
		<th>Alerts</th>
		<th>Owner Name</th>
		<th colspan="3">Options</th>
	</tr>
	<asp:Repeater ID="Repeater1" runat="server">
		<ItemTemplate>
			<tr class="tableRow">
				<td>
					<asp:Label ID="labelAlertName" runat="server" Font-Bold="true"></asp:Label><br />
					Created: 00/00/0000 | Modified: 00/00/0000<br />
					00 Subscribers
				</td>
				<td>
					<asp:Label ID="label1" runat="server" Text="Owner Name" Font-Bold="true"></asp:Label>&nbsp;
				</td>
				<td>
					<asp:ImageButton ID="imageButtonAlertViewer" runat="server" ToolTip="View" ImageUrl="../Images/Icons/16_view.gif" />
					<asp:LinkButton ID="linkAlertViewer" runat="server" Text="View"></asp:LinkButton>&nbsp;
				</td>
				<td>
					<asp:ImageButton ID="imageButtonSubscribe" runat="server" ToolTip="Subscribe" ImageUrl="" />
					<a href="AddSubscriptions.aspx?esb:AlertID=<%#Eval("AlertID") %>">Subscribe</a>&nbsp;
				</td>
				<td>
					<asp:ImageButton ID="imageButtonDelete" runat="server" ToolTip="Delete" ImageUrl="../Images/Icons/16_delete.gif" />
					<asp:Label ID="labelDeletable" runat="server"></asp:Label>&nbsp;
				</td>
			</tr>
		</ItemTemplate>
	</asp:Repeater>
</table>
<asp:GridView ID="GridView1" runat="server">
</asp:GridView>
