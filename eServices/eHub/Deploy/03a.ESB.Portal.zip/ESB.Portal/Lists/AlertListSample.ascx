<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="AlertListSample.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Lists.AlertListSample" %>
<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers"
    TagPrefix="cc1" %>
    
    <script type="text/javascript" language="javascript">
	function deleteAlert(alertId)
	{
		if (confirm("Are you sure you want to delete this alert?"))
		{
			document.location = "../Admin/DeleteAlert.aspx?esb:AlertId=" + alertId + "&UrlReferrer=..%2fAlerts%2fAlerts.aspx";
		}
	}
	
	
</script>


<asp:Image ID="Image1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
<asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton>
&nbsp;

<asp:GridView ID="GridView1" runat="server" AutoGenerateColumns="False" DataKeyNames="AlertID" BorderWidth="0"
     AllowSorting="true" Width="100%" AllowPaging="True" >
    <HeaderStyle CssClass="tableHeader" />
	<RowStyle CssClass="tableRow" />
    <Columns>
        <asp:BoundField DataField="AlertId" Visible="False" />
        <asp:BoundField DataField="Name" HeaderText="Name" SortExpression="Name" />
		<asp:TemplateField  HeaderText="Condition" SortExpression="ConditionsString">
			<ItemTemplate>
				<%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "ConditionsString"), 40)%>
			</ItemTemplate>
		</asp:TemplateField>
        <asp:BoundField DataField="InsertedBy" HeaderText="Owner" SortExpression="InsertedBy" />
        <asp:BoundField DataField="InsertedDate" HeaderText="Create Date" SortExpression="InsertedDate" />
        <asp:TemplateField >
			<ItemTemplate>
				<img alt="Subscribers" src="../Images/Icons/16_subscribe.gif" />
			</ItemTemplate>
		</asp:TemplateField>
        <asp:BoundField DataField="TotalSubscriberCount" HeaderText="Subscribers" SortExpression="TotalSubscriberCount" />
        <asp:TemplateField  HeaderText="Action" >
			<ItemTemplate>
				<%# DisplayLinks(DataBinder.Eval(Container.DataItem, "AlertID"), DataBinder.Eval(Container.DataItem, "InsertedBy"), DataBinder.Eval(Container.DataItem, "TotalSubscriberCount"))%>
			</ItemTemplate>
		</asp:TemplateField>
        </Columns>
</asp:GridView>
<%--<asp:ObjectDataSource ID="AlertsAllDataSource" runat="server" OldValuesParameterFormatString="original_{0}"
    SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.AlertsAllTableAdapters.usp_select_AlertsTableAdapter">
</asp:ObjectDataSource>--%>
<cc1:GridViewSortExtender ID="GridViewSortExtender1" runat="server" AscendingImageUrl="~/Images/asc_order.gif"
    DescendingImageUrl="~/Images/desc_order.gif" ExtendeeID="GridView1">
</cc1:GridViewSortExtender>
