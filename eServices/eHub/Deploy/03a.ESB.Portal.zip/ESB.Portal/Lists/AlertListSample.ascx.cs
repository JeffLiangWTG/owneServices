//---------------------------------------------------------------------
// File: AlertListSample.ascx.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal.Lists
{
    public partial class AlertListSample : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GridView1.DataSource = GetAlerts();
                GridView1.DataBind();
            }
        }

        public string GetCrumbedString(object t, int crumbAt)
        {
            string text = t.ToString();
            if (text.Length > crumbAt)
            {
                return String.Format("<span title=\"{0}\">{1}</span>", text, PortalHelper.CrumbString(text, crumbAt));
            }
            else
            {
                return text;
            }
        }

        protected string DisplayLinks(object aid, object iby, object sc)
        {
            string InsertedBy = iby.ToString();
            string AlertId = aid.ToString();
            string SubCount = sc.ToString();
            string Links = "";
            string spacer = "<img src='../images/spacer.gif' width='4px' height='16px' />";

            // show the view icon first
            Links = String.Format("<a href='AlertViewer.aspx?esb:AlertID={0}'><img alt='View' src='../images/icons/16_view.gif' width='16px'></a>", AlertId);
            Links += spacer;
            Links += String.Format("<a href='AddSubscriptions.aspx?esb:AlertID={0}'><img alt='Add Subscriptions' src='../images/icons/16_new.gif' width='16px'></a>", AlertId);
            Links += spacer;

            if (isDeletable(InsertedBy, SubCount))
                Links += String.Format("<a href='#' onclick=\"javascript:deleteAlert('{0}');\"><img alt='Delete' src='../images/icons/16_delete.gif' /></a>", AlertId);
            else
                Links += "<img src='../images/spacer.gif' width='16px' height='16px' />";

            return Links;
        }

        protected string DisplaySubscribers(string Count, string AlertId)
        {
            return "";
        }

        private bool isDeletable(string InsertedBy, string Count)
        {
            // Check to see if the alert is deletable...
            // It is ONLY deletable if
            //  1. The current user is the author
            //  2. The count is 0
            if (string.Compare(InsertedBy, Context.User.Identity.Name, true) == 0)
                if (Convert.ToInt16(Count) == 0)
                    return true;
                else
                    return false;
            else
                return false;
        }

        private List<usp_select_AlertsResult> GetAlerts()
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();
                
                return client.GetAlerts();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridView gv = new GridView();
            gv.AllowPaging = false;
            gv.DataSource = GetAlerts();
            gv.DataBind();
            gv.Dispose();
 
            GridViewExportUtil.ExcelExport(String.Format("Alerts_{0}.xls", DateTime.Now.ToShortDateString()),gv);
        }

    }
}