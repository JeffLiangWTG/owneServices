//---------------------------------------------------------------------
// File: Global.asax.cs
// 
// Summary: Handles applicaton wide events.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

namespace Microsoft.Practices.ESB.Portal
{
    public class Global : System.Web.HttpApplication
    {
        protected void Session_OnStart(object sender, EventArgs e)
        {
            PortalHelper.LoadUserSettingsToSession(this.Context);
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            HttpContext ctx = HttpContext.Current;
            Exception ex = ctx.Error.GetBaseException();

            // Handle site exceptions
			try
			{
				ExceptionPolicy.HandleException(ex, "Log Policy");
			}
			catch (Exception exception)
			{
				ctx.Trace.Write("Application_Error", ex.Message, ex);
				ctx.Trace.Write("ExceptionPolicy_Error", exception.Message, exception);
			}
        }
    }
}