<%@Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="PortalSettings.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.PortalSettings" Title="ESB Management Console - My Settings" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<script language="javascript">
		function redirect(url)
		{
			document.location = url;
		}
		
		function toggleApplicationSettings(isVisible)
		{
			if(isVisible)
			{
				document.getElementById("applicationSettingsContainer").style.display = "inline";
			}
			else
			{
				document.getElementById("applicationSettingsContainer").style.display = "none";
			}
		}
		
		function selectAllApplications(select)
		{
			var totalAppCount = document.getElementById("totalApplicationCount").value;
			
			for(var i=0; i<totalAppCount; i++)
			{
				if (select)
				{
					document.getElementById("appSetting" + i).checked = true;
				}
				else
				{
					document.getElementById("appSetting" + i).checked = false;
				}
			}
		}
	</script>
	<h1 class="iconSettings">My Settings</h1>
	<h2>Applications</h2>
	<div style="clear:both;padding-bottom:5px;">
		<asp:Label ID="labelSaveSuccess" runat="server" Visible="false" ForeColor="green">Changes were saved successfully.</asp:Label>
	</div>
	<div id="applicationSettingsContainer" class="filterTable">
		<div class="filterRow">
			<div id="applicationSettings" runat="server"></div>
		</div>
		<div class="filterRow">
			Select: 
				<a href="javascript:selectAllApplications(true);">All</a> | 
				<a href="javascript:selectAllApplications(false);">None</a>
		</div>
	</div>
	<h2>Date Range</h2>

	<div>
	Select the time range to show faults:
		<asp:DropDownList CssClass="formDropDown" ID="dropDownTimeRange" runat="server">
<asp:ListItem Text="Hour" Value="Hour" />
						<asp:ListItem Text="Day" Value="Day" />
						<asp:ListItem Text="Week" Value="Week" />
						<asp:ListItem Text="Month" Value="Month" />
						<asp:ListItem Text="Quarter" Value="Quarter" />
						<asp:ListItem Text="Year" Value="Year" />
						<asp:ListItem Text="All" Value="All" />
		</asp:DropDownList>
	</div>

	<p>
		<asp:Button ID="submit" runat="server" Text="Save" CssClass="formButton" OnClick="submit_Click" />
		<asp:Button ID="Button1" runat="server" Text="Cancel" CssClass="formButton" OnClick="submit_Click" />
	</p>
	
</asp:Content>
