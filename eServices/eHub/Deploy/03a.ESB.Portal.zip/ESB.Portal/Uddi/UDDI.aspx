<%@Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="UDDI.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Uddi.UDDI"
	Title="ESB Management Console - Registry" %>

<%@Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers"
    TagPrefix="cc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
<h1 class="iconRegistry">New Registry Entry</h1>

<div class="filterHeader">Filter Registry Entries: Select a BizTalk application to view all end points</div>
<div class="filterTable">
	<div class="filterRow">
		View
		<asp:DropDownList ID="_typeDropDownList" runat="server" CssClass="formDropDown">
			<asp:ListItem>Receive Locations</asp:ListItem>
			<asp:ListItem>Send Ports</asp:ListItem>
			<asp:ListItem Selected="True">All Endpoints</asp:ListItem>
		</asp:DropDownList>
		for
		<asp:DropDownList ID="_statusDropDownList" runat="server" CssClass="formDropDown">
			<asp:ListItem>Registered</asp:ListItem>
			<asp:ListItem>Not Registered</asp:ListItem>
			<asp:ListItem>Pending</asp:ListItem>
			<asp:ListItem Selected="True" Value="All Status">All</asp:ListItem>
		</asp:DropDownList>
		status for application:
		<asp:DropDownList ID="_applicationDropDownList" runat="server" CssClass="formDropDown" DataTextField="Name" DataValueField="Name">
		</asp:DropDownList>
		<asp:ImageButton ImageUrl="../Images/Icons/16_go.gif" ToolTip="Next" ID="_viewButton" runat="server" OnClick="_applyButton_Click" />
	</div>
</div>
				
<asp:Label ID="lblMessage" runat="server" Font-Size="Small" ForeColor="Red" Text="Label" Visible="False"></asp:Label>

<asp:Image ID="Image1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
<asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton>
&nbsp;
<asp:GridView 
	ID="GridView1" 
	runat="server" 
	AutoGenerateColumns="False" 
	GridLines="Horizontal" 
	OnRowDataBound="GridView1_RowDataBound" 
	OnRowCommand="GridView1_RowCommand"
	DataSourceID="EndpointsDataSource" AllowSorting="true" AllowPaging="true" >
	<HeaderStyle CssClass="tableHeader" />
	<RowStyle CssClass="tableRow" />
	<Columns>
	    <asp:TemplateField>
	        <ItemTemplate>
	           <%#   Microsoft.Practices.ESB.Portal.PortalHelper.EndPointIcon(Eval("BindingType").ToString() )  %>
	            
	        </ItemTemplate>
	    </asp:TemplateField>
		<asp:BoundField DataField="BindingType" HeaderText="Type" SortExpression="BindingType">
			<ItemStyle Width="65px" />
		</asp:BoundField>
		<asp:TemplateField  HeaderText="Name" SortExpression="EndpointName">
			<ItemTemplate>
				<%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "EndpointName"), 35)%>
			</ItemTemplate>
		</asp:TemplateField>
		<asp:TemplateField  HeaderText="Transport" SortExpression="TransportType">
			<ItemTemplate>
				<%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "TransportType"), 45)%>
			</ItemTemplate>
		</asp:TemplateField>
		<asp:TemplateField  HeaderText="URI" SortExpression="TransportLocation">
			<ItemTemplate>
				<%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "TransportLocation"), 45)%>
			</ItemTemplate>
		</asp:TemplateField>
		<asp:BoundField DataField="Status" HeaderText="Status" SortExpression="Status">
			<ItemStyle Width="110px" />
		</asp:BoundField>
		<asp:ButtonField HeaderText="Action" Text="Button" />
		<asp:ButtonField Text="Button" />
	</Columns>
</asp:GridView>

	
	<asp:ObjectDataSource ID="EndpointsDataSource" runat="server" OnSelecting="EndpointsDataSource_Selecting" SelectMethod="GetEndpointsByApplication" TypeName="Microsoft.Practices.ESB.Portal.Uddi.ServiceProxy">
		<SelectParameters>
			<asp:ControlParameter ControlID="_applicationDropDownList" Name="applicationName" PropertyName="SelectedValue" Type="String" />
			<asp:Parameter Name="getSendPorts" Type="Boolean" />
			<asp:Parameter Name="getRcvLocations" Type="Boolean" />
		</SelectParameters>
	</asp:ObjectDataSource>
    <cc1:gridviewsortextender id="GridViewSortExtender1" runat="server" ascendingimageurl="~/Images/asc_order.gif"
        descendingimageurl="~/Images/desc_order.gif" extendeeid="GridView1"></cc1:gridviewsortextender>

</asp:Content>
