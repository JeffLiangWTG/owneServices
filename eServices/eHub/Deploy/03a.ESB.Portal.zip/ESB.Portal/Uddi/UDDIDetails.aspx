<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="UDDIDetails.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Uddi.UDDIDetails" Title="ESB Management Console - Registry" %>

<%@ Import Namespace="Microsoft.Practices.ESB.Portal.Uddi" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<asp:FormView ID="FormView1" runat="server" DataSourceID="EndPointDataSource" DefaultMode="Edit" OnDataBound="FormView1_DataBound" OnItemCreated="FormView1_ItemCreated" OnPageIndexChanging="FormView1_PageIndexChanging">
		<HeaderTemplate>
		</HeaderTemplate>
		<ItemTemplate>
			<h1 class="iconRegistry">
				Registry Details</h1>
			<div class="formBodyNoForm">
				<div class="formHeader">
					Registry Details</div>
				<div class="formRow">
					<div class="formLabel">
						BizTalk Application:</div>
					<div class="formField">
						<asp:Label ID="BizTalkApplication" runat="server" Text='<%# Bind("BizTalkApplication") %>' />
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						EndPoint Name:</div>
					<div class="formField">
						<asp:Label ID="_endPointNameLbl" runat="server" Text='<%# Bind("EndpointName") %>'></asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Binding Type:</div>
					<div class="formField">
						<asp:Label ID="_bindingTypeLbl" runat="server" Text='<%# Eval("BindingType") %>' />
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Transport Type:</div>
					<div class="formField">
						<asp:Label ID="_transportTypeLabel" runat="server" Text='<%# string.Format("{0} ({1})", BindingTypeMapper.ToUddiBindingType(Eval("TransportType").ToString()), Eval("TransportType")) %>' />
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Exchange Pattern:</div>
					<div class="formField">
						<asp:Label ID="ExchangeLbl" runat="server" Text='<%# Eval("MessageExchangePattern") %>' />
					</div>
				</div>
			</div>
			<br clear="all" />
			<!-- REGISTRY SERVICE -->
			<div>
				<div class="formHeader">
					Registry Service</div>
				<div class="formRow">
					<div class="formLabel">
						Business Provider:</div>
					<div class="formField">
						<asp:Label ID="_businessProviderReadOnlyLabel" CssClass="formField" runat="server" Text='<%# Bind("BusinessProvider") %>'></asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Service Name:</div>
					<div class="formField">
						<asp:Label Visible="true" ID="_serviceNameLabel" CssClass="formField" runat="server" Text='<%# Bind("ServiceName") %>'></asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Description:</div>
					<div class="formField">
						<asp:Label Visible="true" ID="_descriptionLabel" CssClass="formField" runat="server" Text='<%# Bind("Description") %>'></asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						End Point:</div>
					<div class="formField">
						<asp:Label Visible="true" ID="_endPointLabel" CssClass="formField" runat="server" Text='<%# Bind("EndpointValue") %>'></asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Category:</div>
					<div class="formField">
						<asp:Label ID="_categoryLabel" CssClass="formField" runat="server">microsoft-com:esb:runtimeresolution</asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Target Namespace:</div>
					<div class="formField">
						<asp:Label Visible="true" ID="_targetNamespaceLabel" CssClass="formField" runat="server" Text='<%# Bind("TargetNamespace") %>'></asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Service Action:</div>
					<div class="formField">
						<asp:Label Visible="true" ID="_serviceActionLabel" CssClass="formField" runat="server" Text='<%# Bind("ServiceAction") %>'></asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Cache TimeOut:</div>
					<div class="formField">
						<asp:Label Visible="true" ID="_cacheTimeOutLabel" CssClass="formField" runat="server" Text='<%# Bind("CacheTimeOut") %>'></asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Jax RPC Response:</div>
					<div class="formField">
						<asp:Label Visible="true" ID="_JaxRpcResponseLabel" CssClass="formField" runat="server" Text='<%# Bind("JaxRPCResponse") %>'></asp:Label>
					</div>
				</div>
			</div>
			<asp:HiddenField runat="server" ID="RequestAction" Value='<%# Bind("RequestAction")%>' />
			<div class="formBody">
				<div class="formHeader">
					Registry Contact</div>
				<div class="formRow">
					<div class="formLabel">
						Contact Name:
					</div>
					<div class="formField">
						<asp:Label Visible="true" ID="_contactNameLabel" CssClass="formField" runat="server" Text='<%# Bind("UDDIContactName") %>'></asp:Label>
					</div>
				</div>
			</div>
			<div style="clear: both;">
				<div class="formRow">
					<div class="formLabel">
						E-Mail:
					</div>
					<div class="formField">
						<asp:Label Visible="true" ID="_emailLabel" CssClass="formField" runat="server" Text='<%# Bind("UDDIEmail") %>'></asp:Label>
					</div>
				</div>
			</div>
			<div style="clear: both;">
				<div class="formRow">
					<div class="formLabel">
						User Type:
					</div>
					<div class="formField">
						<asp:Label Visible="true" ID="__userTypeTxtBox" CssClass="formField" runat="server" Text='<%# Bind("UDDIUserType") %>'></asp:Label>
					</div>
				</div>
			</div>
			<div style="clear: both; margin-top: 35px;">
				<asp:Button Visible="true" ID="_cancelButton" CssClass="formButton" runat="server" Style="margin: 0 5px;" Width="70px" Text="OK" OnClick="_cancelButton_Click" />
			</div>
		</ItemTemplate>
		<EditItemTemplate>
			<h1 class="iconRegistry">
				Registry Details</h1>
			<div class="formBodyNoForm">
				<div class="formHeader">
					Registry Details</div>
				<div class="formRow">
					<div class="formLabel">
						BizTalk Application:</div>
					<div class="formField">
						<asp:Label ID="BizTalkApplication" runat="server" Text='<%# Bind("BizTalkApplication") %>' />
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						EndPoint Name:</div>
					<div class="formField">
						<asp:Label ID="_endPointNameLbl" runat="server" Text='<%# Bind("EndpointName") %>'></asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Binding Type:</div>
					<div class="formField">
						<asp:Label ID="_bindingTypeLbl" runat="server" Text='<%# Eval("BindingType") %>' />
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Transport Type:</div>
					<div class="formField">
						<asp:Label ID="_transportTypeLabel" runat="server" Text='<%# string.Format("{0} ({1})", BindingTypeMapper.ToUddiBindingType(Eval("TransportType").ToString()), Eval("TransportType")) %>' />
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Exchange Pattern:</div>
					<div class="formField">
						<asp:Label ID="ExchangeLbl" runat="server" Text='<%# Eval("MessageExchangePattern") %>' />
					</div>
				</div>
			</div>
			<br clear="all" />
			<!-- REGISTRY SERVICE -->
			<div>
				<div class="formHeader">
					Registry Service</div>
				<div class="formRow">
					<div class="formLabel">
						Business Provider:</div>
					<div class="formField">
						<div style="float: left;">
							<asp:DropDownList Visible='true' ID="ddlbBusinesses" CssClass="formDropDown" runat="server" SelectedValue='<%# Bind("BusinessProvider") %>' OnSelectedIndexChanged="ddlbBusinesses_SelectedIndexChanged" AutoPostBack="true">
							</asp:DropDownList>
						</div>
						<div style="float: left;">
							<asp:TextBox ID="businessProviderCustom" runat="server" Text="" Visible="false" Width="200px" Height="15px"></asp:TextBox>
						</div>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Service Name:</div>
					<div class="formField">
						<asp:TextBox Visible='true' ID="ServiceName" MaxLength="255" runat="server" Width="400px" CssClass="formFieldInput" Text='<%# Bind("ServiceName") %>'></asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Description:</div>
					<div class="formField">
						<asp:TextBox Visible='true' ID="_descriptionTxtBox" MaxLength="255" runat="server" Width="400px" CssClass="formFieldInput" Font-Names="Calibri" Font-Size="10pt" Height="50px" TextMode="MultiLine" Text='<%# Bind("Description") %>'></asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						End Point:</div>
					<div class="formField">
						<asp:TextBox Visible='true' ID="_endPointTxtBox" MaxLength="255" runat="server" Width="400px" CssClass="formFieldInput" Text='<%# Bind("EndpointValue") %>'></asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Category:</div>
					<div class="formField">
						<asp:Label ID="_categoryLabel" CssClass="formField" runat="server">microsoft-com:esb:runtimeresolution</asp:Label>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Target Namespace:</div>
					<div class="formField">
						<asp:TextBox Visible='true' ID="TargetNamespace" MaxLength="255" runat="server" Width="400px" CssClass="formFieldInput" Text='<%# Bind("TargetNamespace") %>'></asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Service Action:</div>
					<div class="formField">
						<asp:TextBox Visible='true' ID="ServiceAction" runat="server" MaxLength="75" Width="400px" CssClass="formFieldInput" Text='<%# Bind("ServiceAction") %>'></asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Cache TimeOut:</div>
					<div class="formField">
						<asp:TextBox Visible='true' ID="CacheTimeOut" runat="server" MaxLength="10" Width="20px" CssClass="formFieldInput" Text='<%# Bind("CacheTimeOut") %>'></asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Jax RPC Response:</div>
					<div class="formField">
						<asp:DropDownList Visible='true' ID="JaxRPCResponse" runat="server" CssClass="formDropDown" SelectedValue='<%# Bind("JaxRPCResponse") %>'>
							<asp:ListItem>True</asp:ListItem>
							<asp:ListItem>False</asp:ListItem>
						</asp:DropDownList>
					</div>
				</div>
			</div>
			<asp:HiddenField runat="server" ID="RequestAction" Value='<%# Bind("RequestAction")%>' />
			<div class="formBody">
				<div class="formHeader">
					Registry Contact</div>
				<div class="formRow">
					<div class="formLabel">
						Contact Name:
					</div>
					<div class="formField">
						<asp:TextBox Visible='true' ID="_contactNameTxtBox" runat="server" MaxLength="50" Width="200px" CssClass="formFieldInput" Text='<%# Bind("UDDIContactName") %>'></asp:TextBox>
					</div>
				</div>
			</div>
			<div style="clear: both;">
				<div class="formRow">
					<div class="formLabel">
						E-Mail:
					</div>
					<div class="formField">
						<asp:TextBox Visible='true' ID="_emailTxtBox" runat="server" MaxLength="50" Width="200px" CssClass="formFieldInput" Text='<%# Bind("UDDIEmail") %>'></asp:TextBox>
					</div>
				</div>
			</div>
			<div style="clear: both;">
				<div class="formRow">
					<div class="formLabel">
						User Type:
					</div>
					<div class="formField">
						<asp:TextBox Visible='true' ID="_userTypeTxtBox" runat="server" MaxLength="20" Width="200px" CssClass="formFieldInput" Text='<%# Bind("UDDIUserType") %>'></asp:TextBox>
					</div>
				</div>
			</div>
			<div class="formSubmit">
				<asp:Button Visible="true" ID="_publishButton" CssClass="formButton" runat="server" Style="margin: 0 5px;" Width="70px" Text="Publish" CommandName="Update" />
				<asp:Button Visible="true" ID="_deleteButton" CssClass="formButton" runat="server" Style="margin: 0 5px;" Width="70px" Text="Delete" OnClick="_deleteButton_Click" OnClientClick="javascript:return confirm('Are you sure you want to delete this Registry entry?');" />
				<asp:Button Visible="true" ID="_cancelButton" CssClass="formButton" runat="server" Style="margin: 0 5px;" Width="70px" Text="Cancel" OnClick="_cancelButton_Click" />
			</div>
		</EditItemTemplate>
	</asp:FormView>
	<asp:Label ID="lblMessage" runat="server" Font-Size="Small" ForeColor="Red" Text="Label" Visible="False" Width="860px"></asp:Label>
	<asp:ObjectDataSource ID="EndPointDataSource" runat="server" TypeName="Microsoft.Practices.ESB.Portal.Uddi.UDDIDetails" SelectMethod="GetEndPoint" UpdateMethod="UpdateEndPoint" OnObjectCreating="EndPointDataSource_ObjectCreating" OldValuesParameterFormatString="original_{0}">
		<UpdateParameters>
			<asp:Parameter Name="EndpointName" Type="String" />
			<asp:Parameter Name="EndpointValue" Type="String" />
			<asp:Parameter Name="Description" Type="String" />
			<asp:Parameter Name="UddiContactName" Type="String" />
			<asp:Parameter Name="UddiEmail" Type="String" />
			<asp:Parameter Name="UddiUserType" Type="String" />
			<asp:Parameter Name="BizTalkApplication" Type="String" />
			<asp:Parameter Name="TargetNamespace" Type="String" />
			<asp:Parameter Name="MessageExchangePattern" Type="String" />
			<asp:Parameter Name="JaxRPCResponse" Type="String" />
			<asp:Parameter Name="ServiceAction" Type="String" />
			<asp:Parameter Name="CacheTimeOut" Type="String" />
			<asp:Parameter Name="RequestAction" Type="String" />
			<asp:Parameter Name="BusinessProvider" Type="String" />
			<asp:Parameter Name="ServiceName" Type="String" />
		</UpdateParameters>
	</asp:ObjectDataSource>
	<asp:ObjectDataSource ID="UddiBindingTypeObjectDataSource" runat="server" SelectMethod="get_UddiBindingTypes" TypeName="ESB.Portal.BindingTypeMapper"></asp:ObjectDataSource>
</asp:Content>
