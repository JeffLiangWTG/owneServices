//---------------------------------------------------------------------
// File:  UDDI.aspx.cs
// 
// Summary: Lists available BizTalk applications, their published endpoints, 
//          and the UDDI registration status of each.
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace Microsoft.Practices.ESB.Portal.Uddi
{
    public partial class UDDI : System.Web.UI.Page
    {
        /// <summary>
        /// Page_Load Event for UDDI.aspx
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                populateBizTalkApplications();
            }
        }

        /// <summary>
        /// Populates all Endpoints associated with a BizTalk Application
        /// </summary>
        /// <param name="btAppName">BizTalk Application Name</param>
        
        private void populateAppEndPoints(string btAppName)
        {

            Endpoints.EndpointDataTable ds = GridView1.DataSource as Endpoints.EndpointDataTable;

            if (ds == null)
            {
                // Apply endpoint type filter
                bool showSendPorts = false;
                bool showRcvLoc = false;
                if (_typeDropDownList.SelectedValue == "Receive Locations")
                {
                    showRcvLoc = true;
                }
                else if (_typeDropDownList.SelectedValue == "Send Ports")
                {
                    showSendPorts = true;
                }
                else
                {
                    showRcvLoc = true;
                    showSendPorts = true;
                }
                // Call Service to return all End Points
                ds = new ServiceProxy().GetEndpointsByApplication(btAppName, showSendPorts, showRcvLoc);
            }
    
            //GridView1.DataSource = ds;
            GridView1.DataBind();
       
 
        }

        /// <summary>
        /// Retrieves a list of all BizTalk Applications and populates the Drop Dwon
        /// </summary>
        /// <param name=""></param>
        private void populateBizTalkApplications()
        {
            try
            {
               BizTalkOperationsService.Operations btService = BizTalkOperationsService.Operations.CreateInstance();

                _applicationDropDownList.DataSource = btService.Applications();
                _applicationDropDownList.DataBind();
            }
            catch
            {
                lblMessage.Visible = true;
                lblMessage.Text = "Unable to Retrieve Applications from BizTalk.  Please contact an Administrator";
            }
        }

        /// <summary>
        /// Called when the Apply Button is Clicked for filters.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void _applyButton_Click(object sender, EventArgs e)
        {
            applyEndpointsViewFilter();
        }

        /// <summary>
        /// Applies a filter on Send Ports or Recieve Locations and Registered or Non-Registered Services.
        /// </summary>
        private void applyEndpointsViewFilter()
        {
            string btApp = _applicationDropDownList.SelectedValue;

            if (!string.IsNullOrEmpty(btApp))
            {
               // lblAppName.Text = _applicationDropDownList.SelectedItem.Text;

                string statusFilter = string.Empty;
                if (_statusDropDownList.SelectedValue == "Registered")
                {
                    statusFilter = "Status='Registered'";
                }
                else if (_statusDropDownList.SelectedValue == "Not Registered")
                {
                    statusFilter = "Status='Not Registered'";
                }
                else if (_statusDropDownList.SelectedValue == "Pending")
                {
                    statusFilter = "Status='Pending'";
                }

                EndpointsDataSource.FilterExpression = statusFilter;

                populateAppEndPoints(btApp);
            }
        }

        /// <summary>
        /// Called when the View button is clicked for a BizTalk Application
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void _viewButton_Click(object sender, EventArgs e)
        {
            applyEndpointsViewFilter();
        
  
        }

        /// <summary>
        /// Called for each row in the GridView when populating the display.
        /// Each column will be populated with the proper data.  If the endpoint name is 
        /// to long, it will be stripped to the first 20 characters and a tooltip will be set.
        /// This is to accommodate Dynamic Ports which are very long.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView item = e.Row.DataItem as DataRowView;

                string id = item.Row["ID"] as string;
                string itemStatus = item.Row["Status"] as string;
                string transporttype = item.Row["TransportType"] as string;
                string endpointname = item.Row["EndpointName"] as string;
                string transportlocation = item.Row["TransportLocation"] as string;
                string strBizTalkApplication = item.Row["BizTalkApplication"] as string;
                string strBizTalkPort = item.Row["EndPointName"] as string;

                string strArg = strBizTalkApplication + "|" + strBizTalkPort;


                // If the endpointname is too long, just show the first 20 and add a tooltip
                if (endpointname.Length > 20 && transporttype == "Dynamic")
                {
                    e.Row.Cells[1].Text = "Dynamic";
                    e.Row.Cells[1].ToolTip = endpointname;
                }

                // If the transportlocation is too long, just show the first 30 and add a tooltip
                if (transportlocation.Length > 30)
                {
                    e.Row.Cells[3].Text = transportlocation.Substring(0, 30).ToString() + "...";
                    e.Row.Cells[3].ToolTip = transportlocation;
                }
                // if SharePoint, just make the text WSS
                if (transporttype == "Windows SharePoint Services")
                {
                    e.Row.Cells[2].Text = "WSS";
                }

                // Set text and command of links to next page in workflow

                LinkButton link = e.Row.Cells[6].Controls[0] as LinkButton;
                LinkButton linkRemove = e.Row.Cells[7].Controls[0] as LinkButton;
                linkRemove.Text = "";

                if (transporttype == "Dynamic")
                {
                    link.Enabled = false;
                    link.Text = "Not Available";
                }
                else
                {
                    switch (itemStatus.ToLower())
                    {
                        //case "dynamic":
                        //    link.Enabled = false;
                        //    link.Text = "Not Available";
                        //    break;
                        case "not registered":
                            link.Text = "Publish";
                            link.CommandName = "Publish";
                            //link.CommandArgument = id;
                            link.CommandArgument = strArg;
                            break;
                        default:
                            link.Text = "View Detail";
                            link.CommandName = "ViewDetail";
                            //link.CommandArgument = id;
                            link.CommandArgument = strArg;


                            // If Registered in UDDI, we need to provide a Remove Link
                            if (itemStatus == "Registered")
                            {
                                linkRemove.Text = "Remove";
                                linkRemove.CommandName = "Remove";
                                //linkRemove.CommandArgument = id;
                                linkRemove.CommandArgument = strArg;
                                linkRemove.Attributes.Add("onclick", "javascript:return confirm('Are you sure you want to remove this entry from UDDI?')");
                            }
                            break;

                    }
                }
            }
        }

        /// <summary>
        /// Called when the view Link is clicked for a row.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            switch (e.CommandName.ToLower())
            {
                case "remove":
                    // if remove is selected, we need to remove the service.
                    //RemoveUDDIEntry(new Guid(e.CommandArgument.ToString()));
                    string strArg = e.CommandArgument.ToString();
                    char[] strSplitChar = { '|' };
                    string[] strSplit = strArg.Split(strSplitChar);
                    string strBizTalkApplication = strSplit[0];
                    string strBizTalkPort = strSplit[1];

                    RemoveUDDIEntry(strBizTalkApplication, strBizTalkPort);
                    GridView1.DataBind();
                    break;
                case "viewdetail":
                    Session["UDDIDetails_aspx_ReturnUrl"] = "~/Uddi/UDDI.aspx";
                    Response.Redirect("~/Uddi/UDDIDetails.aspx?id=" + e.CommandArgument + "&view=0", false);
                    break;
                case "publish":
                    Session["UDDIDetails_aspx_ReturnUrl"] = "~/Uddi/UDDI.aspx";
                    Response.Redirect("~/Uddi/UDDIDetails.aspx?id=" + e.CommandArgument + "&view=1", false);
                    break;
            }
        }

        //protected void RemoveUDDIEntry(Guid ID)
        protected void RemoveUDDIEntry(string strBizTalkApplication, string strBizTalkPort)
        {
            try
            {
                // Get the EndPoint info
                ServiceProxy svc = new ServiceProxy();
                lblMessage.Visible = true;
                if (svc.RemoveUDDIEntry(strBizTalkApplication, strBizTalkPort))
                {
                    lblMessage.Text = "End Point has been removed or placed in a pending status!";
                }
                else
                {
                    lblMessage.Text = "An Error has occurred removing the End Point.  Please contact an Administrator";
                }
            }
            catch(Exception ex)
            {
                lblMessage.Text = "An Error has occurred removing the End Point:  " + ex.Message;
            }
        }
        /// <summary>
        /// EndPoint Selecting Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void EndpointsDataSource_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
        {
            e.InputParameters["getSendPorts"] = (_typeDropDownList.SelectedValue == "Send Ports" || _typeDropDownList.SelectedValue == "All Endpoints");
            e.InputParameters["getRcvLocations"] = (_typeDropDownList.SelectedValue == "Receive Locations" || _typeDropDownList.SelectedValue == "All Endpoints");
        }

        protected string GetCrumbedString(object t, int crumbAt)
        {
            string text = t.ToString();
            if (text.Length > crumbAt)
            {
                return "<span title='" + text + "'>" + PortalHelper.CrumbString(text, crumbAt) + "</span>";
            }
            else
            {
                return text;
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridView gv = new GridView();
            gv.AllowPaging = false;
            gv.DataSource = EndpointsDataSource; 
            gv.DataBind();
            gv.Dispose();

            GridViewExportUtil.ExcelExport(String.Format("Endponts_{0}.xls",  DateTime.Now.ToShortDateString()), gv);
        }

        protected void _viewButton_Click(object sender, ImageClickEventArgs e)
        {

        }
    }
}
