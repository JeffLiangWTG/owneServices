//---------------------------------------------------------------------
// File:  UDDIDetails.aspx.cs
// 
// Summary: Displays the UDDI details of a BizTalk endpoint.
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Net.Mail;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

namespace Microsoft.Practices.ESB.Portal.Uddi
{
    public partial class UDDIDetails : System.Web.UI.Page
    {
        private Endpoints.EndpointRow _endPoint;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.QueryString["readonly"] != null)
            {
                this.FormView1.ChangeMode(FormViewMode.ReadOnly);
            }
            else
            {
                this.FormView1.ChangeMode(FormViewMode.Edit);
            }
            
            if (Request.QueryString["id"] != null) 
            {
                string strArg = Request.QueryString["id"];
             
                // The QueryString will be BizTalkApplication + | + BizTalk Port
                char[] strSplitChar = { '|' };
                string[] strSplit = strArg.Split(strSplitChar);
                string strBizTalkApplication = strSplit[0];
                string strBizTalkPort = strSplit[1];


                // This needs to be modified.  We no longer need to use ID to get the endpoint.
                this.EndPoint = new ServiceProxy().GetEndPointByPortName(strBizTalkApplication, strBizTalkPort);
            }

            if (this.FormView1.CurrentMode == FormViewMode.Edit)
            {
                if (this.EndPoint.ModifiedBy == System.Threading.Thread.CurrentPrincipal.Identity.Name || this.EndPoint.Status == "Pending")
                {
                    // This is the user that requested the endpoint to be published, so let them delete it
                    Button deleteButton = FormView1.FindControl("_deleteButton") as Button;
                    deleteButton.Visible = true;
                }

                //Set Publish/Update button text based on state of the EndPoint
                Button updateButton = FormView1.FindControl("_publishButton") as Button;
                if (this.EndPoint.Status == "Registered" || this.EndPoint.Status == "Pending")
                {
                    updateButton.Text = "Update";
                }
                else
                {
                    updateButton.Text = "Publish";
                }
            }
        }

        protected DataList GetProviderList()
        {
            ///
            /// TODO:
            /// Create a list to populate the provider dropdown list
            /// with values from the UDDI web service
            /// 
            DataList list = new DataList();
            return list;
        }

        protected Endpoints.EndpointRow EndPoint
        {
            get
            {
                return _endPoint;
            }
            set { _endPoint = value; }
        }

        protected void _publishButton_Click(object sender, EventArgs e)
        {
        }

        public Endpoints.EndpointRow GetEndPoint()
        {
            return this.EndPoint;
        }

        public void DeleteEndPoint()
        {
            Endpoints.EndpointRow thisEndPoint = this.EndPoint;
            
            // Call to remove the EndPoint
            AdminDatabaseService admindb = new AdminDatabaseService();
            admindb.DeletePending(new Guid(thisEndPoint.ID));

            redirectToReturnUrl();
        }
        public void UpdateEndPoint(string EndpointName, string EndpointValue, string Description, string UDDIContactName, string UDDIEmail, string UDDIUserType,
            string BizTalkApplication, string TargetNamespace, string MessageExchangePattern, string JaxRPCResponse, string ServiceAction, string CacheTimeOut, string RequestAction,
            string BusinessProvider, string ServiceName)
        {
            try
            {
                Endpoints.EndpointRow thisEndPoint = this.EndPoint;
                thisEndPoint.EndpointName = EndpointName;
                thisEndPoint.Description = Description != null ? Description : string.Empty;
                thisEndPoint.EndpointValue = EndpointValue != null ? EndpointValue : string.Empty;
                thisEndPoint.UDDIContactName = UDDIContactName != null ? UDDIContactName : string.Empty;
                thisEndPoint.UDDIEMail = UDDIEmail != null ? UDDIEmail : string.Empty;
                thisEndPoint.UDDIUserType = UDDIUserType != null ? UDDIUserType : string.Empty;
                //thisEndPoint.Status = Status;
                //thisEndPoint.ModifiedBy = ModifiedBy;
                thisEndPoint.TargetNamespace = TargetNamespace != null ? TargetNamespace : string.Empty;
                thisEndPoint.MessageExchangePattern = MessageExchangePattern != null ? MessageExchangePattern : "One-Way";
                thisEndPoint.JaxRPCResponse = JaxRPCResponse != null ? JaxRPCResponse : "false";
                thisEndPoint.ServiceAction = ServiceAction != null ? ServiceAction : string.Empty;
                thisEndPoint.RequestAction = RequestAction != null ? RequestAction : string.Empty;
                thisEndPoint.CacheTimeOut = CacheTimeOut;
                thisEndPoint.BizTalkApplication = BizTalkApplication;

                DropDownList ddlbBusinesses = (DropDownList)(this.FormView1.FindControl("ddlbBusinesses"));

                if (ddlbBusinesses.SelectedValue == "New")
                {
                    thisEndPoint.BusinessProvider = ((TextBox)this.FormView1.FindControl("businessProviderCustom")).Text;
                }
                else
                {
                    thisEndPoint.BusinessProvider = BusinessProvider;
                }


                thisEndPoint.ServiceName = ServiceName;


                Label categoryDropDownList = FormView1.FindControl("_categoryLabel") as Label;
                thisEndPoint.Category = categoryDropDownList.Text;

                if (new ServiceProxy().PublishEndpoint(thisEndPoint))
                {
                    lblMessage.Visible = true;
                    lblMessage.Text = "The endpoint has been successfully published.";

                }

                // Now notify the Administrator
                _NotifyAdmin(thisEndPoint);

                redirectToReturnUrl();
            }
            catch
            {
                throw;
            }
            
        }
        protected void _NotifyAdmin(Endpoints.EndpointRow endPoint)
        {

            UDDIDataAccess da = new UDDIDataAccess(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString);
            DataTable dt = da.RetrieveAdmin();
            DataRow dr = dt.Rows.Count > 0 ? dt.Rows[0] : null;
            string strNotificationEMail = dr != null ? dr["NotificationEMail"].ToString() : string.Empty;
            string strSMTPServer = dr != null ? dr["SMTPServer"].ToString() : string.Empty;
            Boolean blnNotificationEnabled = dr != null ? (Boolean)dr["NotificationEnabled"] : false;
            Boolean blnAutoPublish = dr != null ? (Boolean)dr["AutoPublish"] : true;
            string strSMTPFrom = dr != null ? dr["SMTPFromEmail"].ToString() : "ESBGuidance@ESBGuidance.com";
            string strSMTPSubject = dr != null ? dr["SMTPSubject"].ToString() : "ESB Guidance";
            string xsltPath = dr != null ? dr["SMTPBody"].ToString() : string.Empty;

            if (blnNotificationEnabled && !string.IsNullOrEmpty(strNotificationEMail) && !blnAutoPublish)
            {
                try
                {
                    if (!string.IsNullOrEmpty(xsltPath))
                    {
                        // first create xml doc for message
                        System.Xml.XmlDocument xmlDoc = EmailHelper.CreateEmailDocument(endPoint);

                        using (MailMessage msg = new MailMessage(strSMTPFrom, strNotificationEMail, strSMTPSubject, EmailHelper.GetHtmlBody(xmlDoc, xsltPath)))
                        {
                            msg.IsBodyHtml = true;
                            SmtpClient client = new SmtpClient(strSMTPServer);
                            client.Send(msg);
                            System.Diagnostics.Trace.WriteLine("Email successfully sent");
                        }

                    }
                    else
                    {
                        using (MailMessage msg = new MailMessage(strSMTPFrom, strNotificationEMail, strSMTPSubject, "A pending registry request is awaiting your approval."))
                        {
                            SmtpClient client = new SmtpClient(strSMTPServer);
                            client.Send(msg);
                            System.Diagnostics.Trace.WriteLine("Email successfully sent - No XSLT");
                        }
                    }
                }
                catch 
                {
                    throw;

                }
            }
        }

        protected void _cancelButton_Click(object sender, EventArgs e)
        {
            redirectToReturnUrl();
        }
        protected void _deleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                DeleteEndPoint();
                redirectToReturnUrl();
            }
            catch 
            {
                throw;

                //lblMessage.Visible = true;
                //lblMessage.Text = "An Error occurred Deleting the End Point: " + ex.Message;
            }            
        }

        protected void FormView1_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
        {
            this.DataBind();
        }

        protected void EndPointDataSource_ObjectCreating(object sender, ObjectDataSourceEventArgs e)
        {
            // The ObjectDataSource control expects a value of the source object type as specified in its Type attribute,
            // not the type of object that will be bound to, which is specified in the DataObjectTypeName attribute.
            e.ObjectInstance = this;
        }

        protected void FormView1_DataBound(object sender, EventArgs e)
        {
            FormView sendingView = sender as FormView;
            Endpoints.EndpointRow thisEndPoint = this.EndPoint;

        }

        private void redirectToReturnUrl()
        {
            string returnUrl = Session["UDDIDetails_aspx_ReturnUrl"] as string;
            if (returnUrl != null) { Response.Redirect(returnUrl, false); }
        }

        protected void UddiBindingTypeObjectDataSource_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
        {

        }

        protected void FormView1_ItemCreated(object sender, EventArgs e)
        {
            if (this.FormView1.CurrentMode == FormViewMode.Edit)
            {
                try
                {
                    FormView sendingView = sender as FormView;
                    DropDownList ddlBusiness = sendingView.FindControl("ddlbBusinesses") as DropDownList;
                    DataTable dt = new ServiceProxy().GetBusinesses();

                    if (this.EndPoint != null)
                    {
                        // Search to see if this entry is in the list
                        ListItem li = new ListItem();
                        li = ddlBusiness.Items.FindByText(this.EndPoint.BusinessProvider);
                        if (null == li)
                        {
                            DataRow row;
                            row = dt.NewRow();
                            row["item"] = this.EndPoint.BusinessProvider;
                            dt.Rows.Add(row);
                        }
                    }

                    ddlBusiness.DataSource = dt;
                    ddlBusiness.DataTextField = "item";
                    ddlBusiness.DataValueField = "item";
                }
                catch
                {
                    throw;

                    //lblMessage.Visible = true;
                    //lblMessage.Text = "Error occurred populating Business Providers.  Please contact an Administrator!";
                }    
            }

        }

        protected void FormView1_PageIndexChanging(object sender, FormViewPageEventArgs e)
        {
        
        }

        protected void FormView1_PreRender(object sender, EventArgs e)
        {
        }

        protected void ddlbBusinesses_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlbBusinesses =  (DropDownList)(this.FormView1.FindControl("ddlbBusinesses"));

            this.FormView1.FindControl("businessProviderCustom").Visible = (ddlbBusinesses.SelectedValue == "New");
        }
    }
}