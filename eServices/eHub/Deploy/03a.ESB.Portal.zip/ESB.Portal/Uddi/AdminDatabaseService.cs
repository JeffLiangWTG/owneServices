//---------------------------------------------------------------------
// File:  AdminDatabaseService.cs
// 
// Summary: Handles all Database Services for ESB Admin 
//     
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------
using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Configuration;

namespace Microsoft.Practices.ESB.Portal.Uddi
{
    public class AdminDatabaseService
    {
        /// <summary>
        /// Gets all Pending Requests from the Database for an Application.
        /// </summary>
        /// <param name="btAppName"></param>
        public Endpoints GetPendingAndNonRegCases(string btAppName)
        {
            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString))
            using (SqlCommand cmd = cn.CreateCommand())
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            {
                cmd.CommandText = "usp_get_pending_requests";
                cmd.CommandType = CommandType.StoredProcedure;

                Endpoints cases = new Endpoints();

                adapter.Fill(cases.Endpoint);

                return cases;
            }
        }
        /// <summary>
        /// Gets a Pending Requests from the Database.
        /// </summary>
        /// <param name="id"></param>
        public Endpoints.EndpointRow GetPendingCaseByPort(string BizTalkApplication, string BizTalkPortName)
        {
            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString))
            using (SqlCommand cmd = cn.CreateCommand())
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            {
                cmd.CommandText = "usp_get_pending_request_by_name";
                cmd.CommandType = CommandType.StoredProcedure;

                DbParameter param;

                param = cmd.Parameters.Add("BizTalkApplication", SqlDbType.VarChar, 255);
                param.Value = BizTalkApplication;

                param = cmd.Parameters.Add("BizTalkPortName", SqlDbType.VarChar, 255);
                param.Value = BizTalkPortName;
                
                Endpoints cases = new Endpoints();

                adapter.Fill(cases.Endpoint);

                if (cases.Endpoint.Count > 0)
                {
                    return cases.Endpoint[0];
                }
                return null;
            }
        }
        /// <summary>
        /// Gets a Pending Requests from the Database.
        /// </summary>
        /// <param name="id"></param>
        public Endpoints.EndpointRow GetPendingCaseById(Guid id)
        {
            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString))
            using (SqlCommand cmd = cn.CreateCommand())
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            {
                cmd.CommandText = "usp_get_pending_request";
                cmd.CommandType = CommandType.StoredProcedure;

                DbParameter param;

                param = cmd.Parameters.Add("ID", SqlDbType.UniqueIdentifier, 0);
                param.Value = id;

                Endpoints cases = new Endpoints();

                adapter.Fill(cases.Endpoint);

                if (cases.Endpoint.Count > 0)
                {
                    return cases.Endpoint[0];
                }
                return null;
            }
        }
        /// <summary>
        /// Updates Pending Requests if a change has been made.
        /// </summary>
        /// <param name="ep"></param>
        public void DeletePending(Guid ID)
        {
            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString))
            using (SqlCommand cmd = cn.CreateCommand())
            {
                cmd.CommandText = "usp_Delete_Request";
                cmd.CommandType = CommandType.StoredProcedure;

                DbParameter param;
                param = cmd.Parameters.Add("ID", SqlDbType.UniqueIdentifier);
                param.Value = ID;

                cn.Open();

                int rowsAffected = cmd.ExecuteNonQuery();

                cn.Close();
            }

        }
        /// <summary>
        /// Updates Pending Requests if a change has been made.
        /// </summary>
        /// <param name="ep"></param>
        public void UpdatePendingCase(Endpoints.EndpointRow ep)
        {
            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString))
            using (SqlCommand cmd = cn.CreateCommand())
            {
                cmd.CommandText = "usp_update_pending_request";
                cmd.CommandType = CommandType.StoredProcedure;

                DbParameter param;

                param = cmd.Parameters.Add("Description", SqlDbType.VarChar, 255);
                param.Value = ep.Description;

                param = cmd.Parameters.Add("EndpointValue", SqlDbType.VarChar, 255);
                param.Value = ep.EndpointValue;

                param = cmd.Parameters.Add("Category", SqlDbType.VarChar, 50);
                param.Value = ep.Category;

                param = cmd.Parameters.Add("BindingType", SqlDbType.VarChar, 50);
                param.Value = ep.BindingType;

                param = cmd.Parameters.Add("TransportType", SqlDbType.VarChar, 50);
                param.Value = ep.TransPortType;

                param = cmd.Parameters.Add("TransportLocation", SqlDbType.VarChar, 255);
                param.Value = ep.TransPortLocation;

                param = cmd.Parameters.Add("UDDIContactName", SqlDbType.VarChar, 50);
                param.Value = ep.UDDIContactName;

                param = cmd.Parameters.Add("UDDIUserType", SqlDbType.VarChar, 20);
                param.Value = ep.UDDIUserType;

                param = cmd.Parameters.Add("UDDIEmail", SqlDbType.VarChar, 50);
                param.Value = ep.UDDIEMail;

                param = cmd.Parameters.Add("BiztalkApplication", SqlDbType.VarChar, 255);
                param.Value = ep.BizTalkApplication;

                param = cmd.Parameters.Add("EndpointName", SqlDbType.VarChar, 255);
                param.Value = ep.EndpointName;

                param = cmd.Parameters.Add("Status", SqlDbType.VarChar, 50);
                param.Value = ep.Status;

                param = cmd.Parameters.Add("ModifiedBy", SqlDbType.VarChar, 50);
                param.Value = System.Threading.Thread.CurrentPrincipal.Identity.Name;

                param = cmd.Parameters.Add("ID", SqlDbType.UniqueIdentifier);
                param.Value = new Guid(ep.ID);

                param = cmd.Parameters.Add("TargetNamespace", SqlDbType.VarChar, 255);
                param.Value = ep.TargetNamespace;

                param = cmd.Parameters.Add("MessageExchangePattern", SqlDbType.VarChar, 20);
                param.Value = ep.MessageExchangePattern;

                param = cmd.Parameters.Add("JaxRPCResponse", SqlDbType.Bit);
                if (ep.JaxRPCResponse.ToLower() == "true")
                    param.Value = true;
                else
                    param.Value = false;

                param = cmd.Parameters.Add("ServiceAction", SqlDbType.VarChar, 75);
                param.Value = ep.ServiceAction;

                param = cmd.Parameters.Add("CacheTimeOut", SqlDbType.Int, 4);
                param.Value = ep.CacheTimeOut;

                param = cmd.Parameters.Add("RequestAction", SqlDbType.VarChar, 50);
                param.Value = ep.RequestAction;

                param = cmd.Parameters.Add("BusinessProvider", SqlDbType.VarChar, 255);
                param.Value = ep.BusinessProvider;

                param = cmd.Parameters.Add("ServiceName", SqlDbType.VarChar, 255);
                param.Value = ep.ServiceName;
                
                cn.Open();
                try
                {
                    int rowsAffected = cmd.ExecuteNonQuery();
                }
                catch (Exception ec)
                {
                    string test = ec.Message;
                }
                cn.Close();
            }
        }
        /// <summary>
        /// Updates Pending Requests Status.
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Status"></param>
        public void UpdatePendingStatus(Guid ID, string Status)
        {
            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString))
            using (SqlCommand cmd = cn.CreateCommand())
            {
                cmd.CommandText = "usp_update_pending_status";
                cmd.CommandType = CommandType.StoredProcedure;

                DbParameter param;

                param = cmd.Parameters.Add("ID", SqlDbType.UniqueIdentifier);
                param.Value = ID;

                param = cmd.Parameters.Add("Status", SqlDbType.VarChar, 50);
                param.Value = Status;

                cn.Open();

                int rowsAffected = cmd.ExecuteNonQuery();

                cn.Close();
            }
        }
        /// <summary>
        /// Updates Pending Requests Status.
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="Status"></param>
        public void UpdatePendingStatusByName(string strBizTalkApplication, string strBizTalkPortName, string strStatus)
        {
            using (SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString))
            using (SqlCommand cmd = cn.CreateCommand())
            {
                cmd.CommandText = "usp_update_pending_status_by_name";
                cmd.CommandType = CommandType.StoredProcedure;

                DbParameter param;

                param = cmd.Parameters.Add("BizTalkApplication", SqlDbType.VarChar, 255);
                param.Value = strBizTalkApplication;

                param = cmd.Parameters.Add("BizTalkPortName", SqlDbType.VarChar, 255);
                param.Value = strBizTalkPortName;

                param = cmd.Parameters.Add("Status", SqlDbType.VarChar, 50);
                param.Value = strStatus;

                cn.Open();

                int rowsAffected = cmd.ExecuteNonQuery();

                cn.Close();
            }
        }
         
        /// <summary>
        /// Replace a parameter value.
        /// </summary>
        /// <param name="param"></param>
        /// <param name="replaceValue"></param>
        private T GetParamValue<T>(DbParameter param, T replaceValue)
        {
            return param.Value != null ? (T)param.Value : replaceValue;
        }
        /// <summary>
        /// Replace a parameter value.
        /// </summary>
        /// <param name="cmd"></param>
        /// <param name="paramName"></param>
        /// <param name="replaceValue"></param>
        private T GetParamValue<T>(DbCommand cmd, string paramName, T replaceValue)
        {
            return GetParamValue<T>(cmd.Parameters[paramName], replaceValue);
        }
    }
}
