using System;

namespace Microsoft.Practices.ESB.Portal.UDDIService
{
    public partial class UDDIService
    {
        /// <summary>
        /// Creates an instance of the UDDI Service with Credentials.
        /// </summary>
        public static UDDIService CreateInstance()
        {
            UDDIService uddiService = new UDDIService();
            uddiService.Credentials = System.Net.CredentialCache.DefaultCredentials;
            return uddiService;
        }
    }
}
