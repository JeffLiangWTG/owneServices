//---------------------------------------------------------------------
// File:  UDDIAdmin.aspx.cs
// 
// Summary: Admin Page for UDDI Entries
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Practices.ESB.Portal;


namespace Microsoft.Practices.ESB.Portal.Uddi
{
    public partial class UDDIAdmin : System.Web.UI.Page
    {
        

        protected void Page_Load(object sender, EventArgs e)
        {
                    
        }

        protected void FormView2_PageIndexChanging(object sender, FormViewPageEventArgs e)
        {

        }

        protected void UpdateButton_Click(object sender, EventArgs e)
        {

        }

        protected void UDDIAdminObjectDataSource_Selecting(object sender, ObjectDataSourceSelectingEventArgs e)
        {

        }
    }
}
