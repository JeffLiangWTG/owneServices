//---------------------------------------------------------------------
// File:  UDDIDataAccess.cs
// 
// Summary: Helper class for access to the administration database.
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace Microsoft.Practices.ESB.Portal.Uddi
{
    public class UDDIDataAccess : BaseDataAccess
    {
        /// <summary>
        /// Default constructor calls the base constructor.
        /// </summary>
        /// <param name="connectionString"></param>
        public UDDIDataAccess(string connectionString)
            : base(connectionString)
        {
        }

        #region Query

        /// <summary>
        /// Retrieves the current Admin Values.
        /// </summary>
        public DataTable RetrieveAdmin()
        {
            SqlParameter[] AdminParams = buildUDDIAdminParams();
            AdminParams[0].Value = 1; // We only have one row in our Admin Table
            DataSet ds = ExecuteProc("usp_get_uddi_admin", AdminParams);
            DataTable dt = ds.Tables[0];

            return dt;
        }
        /// <summary>
        /// Retrieve all Pending Requests
        /// </summary>
        /// <returns></returns>
        public DataTable GetPendingRequests()
        {
            DataSet ds = ExecuteProc("usp_get_pending_requests");
            DataTable dt = ds.Tables[0];

            return dt;
        }
        /// <summary>
        /// Retrieve a Pending Reuqest
        /// </summary>
        /// <param name="guidID"></param>
        /// <returns></returns>
        public DataTable GetPendingRequest(string guidID)
        {
            SqlParameter[] PendingParams = buildUDDIGetPendingRequest();
            PendingParams[0].Value = new Guid(guidID);
            DataSet ds = ExecuteProc("usp_get_pending_request", PendingParams);
            DataTable dt = ds.Tables[0];

            return dt;
        }
        /// <summary>
        /// Deletes a Pending Request from the EndPoint Table
        /// </summary>
        /// <param name="guidID"></param>
        /// <returns></returns>
        public void DeletePendingRequest(string guidID)
        {
            SqlParameter[] PendingParams = buildUDDIDeletePendingParams();
            PendingParams[0].Value = new Guid(guidID);
            ExecuteNonQuery("usp_delete_request", PendingParams);

        }

        #endregion

        #region Parameter

        /// <summary>
        /// Builds the parameters for the retrieve UDDI Method
        /// </summary>
        /// <returns></returns>
        private SqlParameter[] buildUDDIAdminParams()
        {
            SqlParameter[] theParams = new SqlParameter[1];
            theParams[0] = CreateSqlParameter("@ID", SqlDbType.Int, 4, ParameterDirection.Input, false);
            return theParams;
        }

        /// <summary>
        /// Builds the parameters for the UDDI Admin Table
        /// </summary>
        /// <returns></returns>
        private SqlParameter[] buildUDDIAdminUpdateParams()
        {
            SqlParameter[] theParams = new SqlParameter[8];
            theParams[0] = CreateSqlParameter("@uddiserver", SqlDbType.VarChar, 100, ParameterDirection.Input, false);
            theParams[1] = CreateSqlParameter("@smtpserver", SqlDbType.VarChar, 50, ParameterDirection.Input, false);
            theParams[2] = CreateSqlParameter("@notificationemail", SqlDbType.VarChar, 100, ParameterDirection.Input, false);
            theParams[3] = CreateSqlParameter("@notificationenabled", SqlDbType.Bit, 1, ParameterDirection.Input, false);
            theParams[4] = CreateSqlParameter("@autopublish", SqlDbType.Bit, 1, ParameterDirection.Input, false);
            theParams[5] = CreateSqlParameter("@contactname", SqlDbType.VarChar, 50, ParameterDirection.Input, false);
            theParams[6] = CreateSqlParameter("@contactemail", SqlDbType.VarChar, 50, ParameterDirection.Input, false);
            theParams[7] = CreateSqlParameter("@ID", SqlDbType.Int, 4, ParameterDirection.Input, false);
           
       
            return theParams;
        }
        /// <summary>
        /// Builds the parameters Deleting Pending
        /// </summary>
        /// <returns></returns>
        private SqlParameter[] buildUDDIDeletePendingParams()
        {
            SqlParameter[] theParams = new SqlParameter[1];
            theParams[0] = CreateSqlParameter("@ID", SqlDbType.UniqueIdentifier, 32, ParameterDirection.Input, false);
            return theParams;
        }
        /// <summary>
        /// Builds the parameters for Get Pending Request
        /// </summary>
        /// <returns></returns>
        private SqlParameter[] buildUDDIGetPendingRequest()
        {
            SqlParameter[] theParams = new SqlParameter[1];
            theParams[0] = CreateSqlParameter("@ID", SqlDbType.UniqueIdentifier, 32, ParameterDirection.Input, false);
            return theParams;
        }

        #endregion


    }
}

