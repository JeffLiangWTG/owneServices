﻿namespace Microsoft.Practices.ESB.Portal.Uddi
{
}
namespace Microsoft.Practices.ESB.Portal.Uddi
{
}
