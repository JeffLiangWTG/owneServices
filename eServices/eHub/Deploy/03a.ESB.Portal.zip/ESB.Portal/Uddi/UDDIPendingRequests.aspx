<%@ Page Language="C#" AutoEventWireup="true" MasterPageFile="~/Layout.Master" Codebehind="UDDIPendingRequests.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Uddi.UDDIPendingRequests" Title="ESB Management Console - Registry" %>

<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers"
    TagPrefix="cc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<h1 class="iconRegistry">Manage Pending Requests</h1>
	<h2>Pending Requests</h2>

	<asp:Label ID="lblError" runat="server" ForeColor="Red" Text="Label" Visible="False" ></asp:Label><br />
    <asp:Image ID="Image1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
    <asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton>
	<asp:GridView 
		ID="GridView2" 
		border="0" 
		GridLines="Horizontal" 
		runat="server" 
		AutoGenerateColumns="False" 
		Width="100%" 
		OnRowDataBound="GridView2_RowDataBound" 
		OnRowCommand="GridView2_RowCommand" 
		AllowSorting="true" 
		AllowPaging="true" 
		DataSourceID="PendingObjectSource">
		<HeaderStyle CssClass="tableHeader" />
		<RowStyle CssClass="tableRow" />
		<Columns>
			<asp:TemplateField HeaderText="Type" SortExpression="BindingType">
			    <ItemTemplate><%# GetTypeIcon( DataBinder.Eval(Container.DataItem, "BindingType") ) %></ItemTemplate>
		    </asp:TemplateField>			
			<asp:BoundField DataField="BusinessProvider" HeaderText="Provider" SortExpression="BusinessProvider" />
            <asp:BoundField DataField="BiztalkApplication" HeaderText="BizTalk Application" SortExpression="BiztalkApplication" />
			<asp:TemplateField HeaderText="Name" SortExpression="EndpointName">
			    <ItemTemplate><%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "EndpointName"), 30)%></ItemTemplate>
		    </asp:TemplateField>			
		    <asp:TemplateField HeaderText="Service Address" SortExpression="EndpointValue">
			    <ItemTemplate><%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "EndpointValue"), 30)%></ItemTemplate>
		    </asp:TemplateField>
			<asp:BoundField DataField="ModifiedBy" HeaderText="User" SortExpression="ModifiedBy" />
			<asp:BoundField DataField="ModifiedDate" HeaderText="Request Date" SortExpression="ModifiedDate" />
			<asp:BoundField DataField="ID" HeaderText="ID" SortExpression="ID" Visible="False" />
			
			<asp:TemplateField>
			    <ItemTemplate>
			        <asp:ImageButton runat="server"  ImageUrl="~/Images/Icons/16_view.gif" Text="View"  CommandArgument='<%# DataBinder.Eval(Container, "RowIndex") %>' />
			    </ItemTemplate>    
			</asp:TemplateField>
                            
            <asp:TemplateField>
			    <ItemTemplate>
			        <asp:ImageButton runat="server" ImageUrl="~/Images/Icons/16_edit.gif" Text="Edit" CommandArgument='<%# DataBinder.Eval(Container, "RowIndex") %>' />            
			    </ItemTemplate>    
			</asp:TemplateField>
			
			<asp:TemplateField>
			    <ItemTemplate>
			        <asp:ImageButton  runat="server"  ImageUrl="~/Images/Icons/16_approve.gif" Text="Approve"  CommandArgument='<%# DataBinder.Eval(Container, "RowIndex") %>' />
			    </ItemTemplate>    
			</asp:TemplateField>
			
			<asp:TemplateField>
			    <ItemTemplate>
			        <asp:ImageButton runat="server" ImageUrl="~/Images/Icons/16_delete.gif" Text="Delete" CommandArgument='<%# DataBinder.Eval(Container, "RowIndex") %>' />
			    </ItemTemplate>    
			</asp:TemplateField>
            
		</Columns>
		<PagerStyle BackColor="#284775" ForeColor="White" HorizontalAlign="Center" />
		<EmptyDataTemplate>
		    No Pending Registrations Exist.
		</EmptyDataTemplate>
	</asp:GridView>
	
	<br />
	<asp:HyperLink ID="HyperLink1" runat="server" Font-Size="Small" NavigateUrl="~/Uddi/UDDIRequestHistory.aspx" Width="130px">View Request History</asp:HyperLink>
			

	<!--</div>-->
	<asp:ObjectDataSource ID="PendingObjectSource" runat="server" SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.Uddi.UDDIPendingRequestsDbTableAdapters.usp_get_pending_requestsTableAdapter" OldValuesParameterFormatString="original_{0}"></asp:ObjectDataSource>
    <cc1:GridViewSortExtender ID="GridViewSortExtender1" runat="server" AscendingImageUrl="~/Images/asc_order.gif"
        DescendingImageUrl="~/Images/desc_order.gif" ExtendeeID="GridView2">
    </cc1:GridViewSortExtender>
</asp:Content>
