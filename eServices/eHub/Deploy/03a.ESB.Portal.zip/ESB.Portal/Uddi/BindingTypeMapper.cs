//---------------------------------------------------------------------
// File:  BindingTypeMapper.cs
// 
// Summary: Helper class to map BizTalk transport types to valid UDDI binding types.
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Microsoft.Practices.ESB.Portal.Uddi
{
    public class BindingTypeMapper
    {
        /// <summary>
        /// Returns a Binding Type if found, else other.
        /// </summary>
        /// <param name="btTransportType"></param>
        public static string ToUddiBindingType(string btTransportType)
        {
            btTransportType = btTransportType.ToLower();

            foreach (string type in UddiBindingTypes)
            {
                if (btTransportType.ToLower() == type.ToLower()) { return type; }
            }
            return "other";
        }
        
        public static string[] UddiBindingTypes
        {
            get { return _uddiBindingTypes; }
        }

        private static string[] _uddiBindingTypes = new string[]
            {
                "mailto",
                "http",
                "https",
                "ftp",
                "fax",
                "phone",
                "other"
            };
    }
}
