using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Microsoft.Practices.ESB.Portal.Uddi
{
    public partial class UDDIRequestHistory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected string GetCrumbedString(object t, int crumbAt)
        {
            string text = t.ToString();
            if (text.Length > crumbAt)
            {
                return "<span title='" + text + "'>" + PortalHelper.CrumbString(text, crumbAt) + "</span>";
            }
            else
            {
                return text;
            }
        }

        protected string GetTypeIcon(object type)
        {
            string spacer = "<img src='../images/spacer.gif' width='4px'>";
           
            switch (type.ToString().ToLower())
            {
                case "send":
                    return "<img src='../images/icons/16_send.gif' width='16px' alt='Send'>" + spacer + "Send";
                case "receive":
                    return "<img src='../images/icons/16_receive.gif' width='16px' alt='Receive'>" + spacer + "Receive";
                default:
                    return "<img src='../images/spacer.gif' width='16px'>" + spacer + type.ToString();
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridView gv = new GridView();
            gv.AllowPaging = false;
            gv.DataSource = HistoryObjectSource; 
            gv.DataBind();
            gv.Dispose();

            GridViewExportUtil.ExcelExport(String.Format("History_{0}.xls", DateTime.Now.ToShortDateString()), gv);
        }
    }
}
