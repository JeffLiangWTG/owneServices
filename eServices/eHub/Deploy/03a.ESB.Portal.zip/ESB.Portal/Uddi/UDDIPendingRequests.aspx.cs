//---------------------------------------------------------------------
// File:  UDDIPendingRequests.aspx.cs
// 
// Summary: Admin Page for UDDI Pending Registrations
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Practices.ESB.Portal;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

namespace Microsoft.Practices.ESB.Portal.Uddi
{
    public partial class UDDIPendingRequests : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (false == this.Page.IsPostBack)
            {
                GridView2.DataBind();
            }
        }

        protected string GetTypeIcon(object type)
        {
            string spacer = "<img src='../images/spacer.gif' width='4px'>";

            switch (type.ToString().ToLower())
            {
                case "send":
                    return "<img src='../images/icons/16_send.gif' width='16px' alt='Send'>" + spacer +"Send";
                case "receive":
                    return "<img src='../images/icons/16_receive.gif' width='16px' alt='Receive'>" + spacer +"Receive";
                default:
                    return "<img src='../images/spacer.gif' width='16px'>" + spacer + type.ToString();
            }
        }


        /// <summary>
        /// Called when and Administrator has Approved the request.  This will pubish
        /// the EndPoint to UDDI.
        /// </summary>
        /// <param name="ID"></param>
    //private void ApproveRegistration(Guid ID)
    private void ApproveRegistration(string strBizTalkApplication, string strBizTalkPortName)
    {
        // Get the Row from the Database using hte ID
        Endpoints.EndpointRow theEndpoint;

        try
        {
            theEndpoint = new AdminDatabaseService().GetPendingCaseByPort(strBizTalkApplication, strBizTalkPortName);

            if (theEndpoint != null)
            {
                // Call to get the Admin Settings for the UDDI Server
                UDDIDataAccess da = new UDDIDataAccess(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString);
                DataTable dt = da.RetrieveAdmin();
                DataRow dr = dt.Rows.Count > 0 ? dt.Rows[0] : null;

                string strUDDIServer = dr["UDDIServer"].ToString();
                if (string.IsNullOrEmpty(strUDDIServer))
                {

                    // We have a problem and cannot publish this endpoint
                    lblError.Text = "UDDI Server not found.  Plese contact an Administrator.";
                    lblError.Visible = true;
                }
                else
                {
                    lblError.Visible = false;
                    // We now have the record we need, call the UDDI Service
                    UDDIService.UDDIService ESBws = UDDIService.UDDIService.CreateInstance();
                    ESBws.PublishBusinessInfoPortal(
                        strUDDIServer,
                        theEndpoint.BusinessProvider,
                        theEndpoint.ServiceName,
                        theEndpoint.Description,
                        theEndpoint.UDDIContactName,
                        theEndpoint.UDDIEMail,
                        theEndpoint.UDDIUserType,
                        BindingTypeMapper.ToUddiBindingType(theEndpoint.TransPortType),
                        theEndpoint.TransPortType,
                        theEndpoint.EndpointValue,
                        theEndpoint.Category,
                        theEndpoint.TargetNamespace,
                        theEndpoint.MessageExchangePattern,
                        theEndpoint.JaxRPCResponse,
                        theEndpoint.ServiceAction,
                        theEndpoint.CacheTimeOut,
                        theEndpoint.BizTalkApplication,
                        theEndpoint.EndpointName
                        );

                    AdminDatabaseService adminsvc = new AdminDatabaseService();
                    adminsvc.UpdatePendingStatusByName(strBizTalkApplication, strBizTalkPortName, "Approved");
                    lblError.Text = "Request has been Approved and Published to UDDI.";
                    lblError.Visible = true;
                }
                GridView2.DataBind();

            }
        }
        catch 
        {
            // Handle site exceptions
            throw;
   
            //lblError.Text = "Unexpected error.  Plese contact an Administrator.";
            //lblError.Visible = true;
        }  
        
    }

        /// <summary>
        /// Called from the GridView.  Three options are available to the user:
        /// 1. View Details - which sends the user to the uddidetails page
        /// 2. Approve - Calls the approval method
        /// 3. Reject - Removes the pending request
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ViewDetail")
            {
                Session["UDDIDetails_aspx_ReturnUrl"] = "~/Uddi/UDDIPendingRequests.aspx";
                Response.Redirect("~/Uddi/UDDIDetails.aspx?id=" + e.CommandArgument + "&readonly=1", false);
            }
            else if (e.CommandName == "EditDetail")
            {
                Session["UDDIDetails_aspx_ReturnUrl"] = "~/Uddi/UDDIPendingRequests.aspx";
                Response.Redirect("~/Uddi/UDDIDetails.aspx?id=" + e.CommandArgument, false);
            }
            else if (e.CommandName == "ApproveDetail")
            {
                string strArg = e.CommandArgument.ToString();

                // The QueryString will be BizTalkApplication + | + BizTalk Port
                char[] strSplitChar = { '|' };
                string[] strSplit = strArg.Split(strSplitChar);
                string strBizTalkApplication = strSplit[0];
                string strBizTalkPort = strSplit[1];

                ApproveRegistration(strBizTalkApplication, strBizTalkPort);
                lblError.Text = "Entry has been Approved and published to the Registry";
                lblError.Visible = true;
            }
            else if (e.CommandName == "RejectDetail")
            {
                string strArg = e.CommandArgument.ToString();

                // The QueryString will be BizTalkApplication + | + BizTalk Port
                char[] strSplitChar = { '|' };
                string[] strSplit = strArg.Split(strSplitChar);
                string strBizTalkApplication = strSplit[0];
                string strBizTalkPort = strSplit[1];
                AdminDatabaseService adminsvc = new AdminDatabaseService();
                adminsvc.UpdatePendingStatusByName(strBizTalkApplication, strBizTalkPort, "Rejected");
                lblError.Text = "Entry has been Rejected";
                lblError.Visible = true;
                
                
            }
            else if (e.CommandName == "RemoveEntry")
            {
                string strArg = e.CommandArgument.ToString();

                // The QueryString will be BizTalkApplication + | + BizTalk Port
                char[] strSplitChar = { '|' };
                string[] strSplit = strArg.Split(strSplitChar);
                string strBizTalkApplication = strSplit[0];
                string strBizTalkPort = strSplit[1];                
                
                // Remove the entry from UDDI
                ServiceProxy svc = new ServiceProxy();
                bool isEndpointDeleted = svc.deleteUDDIEndpoint(strBizTalkApplication, strBizTalkPort);
                lblError.Text = isEndpointDeleted ? "Entry has been removed from UDDI" : "Could not remove entry from UDDI";
                lblError.Visible = true;                
            }
            else
            {
                //should never get here.
                lblError.Text = "An Error has occurred removing the UDDI Entry";
                lblError.Visible = false;
            }
            GridView2.DataBind();
            
        }
        /// <summary>
        /// Called for each row in the GridView.  Sets the links for Details, Approve and Reject
        /// </summary>
        /// <param name="ID"></param>
        protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
        {           
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView item = e.Row.DataItem as DataRowView;
                string strBizTalkApplication = item.Row["BizTalkApplication"] as string;
                string strBizTalkPort = item.Row["EndPointName"] as string ;
                string strArg = strBizTalkApplication + "|" + strBizTalkPort;
                
                string id = item.Row[0].ToString();
                
                // Set text and command of links to next page in workflow
                ImageButton link = e.Row.Cells[8].Controls[1] as ImageButton;
                link.CommandName = "ViewDetail";
                link.CommandArgument = strArg;

                // Set text and command of links to next page in workflow
                link = e.Row.Cells[9].Controls[1] as ImageButton;
                link.CommandName = "EditDetail";
                link.CommandArgument = strArg;

                ImageButton link1 = e.Row.Cells[10].Controls[1] as ImageButton;

                if (item.Row[19].ToString() == "Delete")
                {
                    link1.ToolTip = "Remove";
                    link1.CommandName = "RemoveEntry";
                    link1.CommandArgument = strArg;
                }
                else
                {
                    link1.ToolTip = "Approve";
                    link1.CommandName = "ApproveDetail";
                    link1.CommandArgument = strArg;
                }


                ImageButton link2 = e.Row.Cells[11].Controls[1] as ImageButton;
                link2.ToolTip = "Reject";
                link2.CommandName = "RejectDetail";
                link2.CommandArgument = strArg;
            }
        }

        public string GetCrumbedString(object t, int crumbAt)
        {
            string text = t.ToString();
            if (text.Length > crumbAt)
            {
                return "<span title='" + text + "'>" + PortalHelper.CrumbString(text, crumbAt) + "</span>";
            }
            else
            {
                return text;
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridView gv = new GridView();
            gv.AllowPaging = false;
            gv.DataSource = PendingObjectSource; 
            gv.DataBind();
            gv.Dispose();

            GridViewExportUtil.ExcelExport(String.Format("Pending_{0}.xls", DateTime.Now.ToShortDateString()), gv);
        }
    } 
}