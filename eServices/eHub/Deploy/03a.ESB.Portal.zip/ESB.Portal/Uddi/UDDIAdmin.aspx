<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="UDDIAdmin.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Uddi.UDDIAdmin" Title="ESB Management Console - Registry"%>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<asp:FormView ID="FormView2" runat="server" DefaultMode="Edit" DataSourceID="UDDIAdminObjectDataSource" Width="100%" OnPageIndexChanging="FormView2_PageIndexChanging">
		<EditItemTemplate>
		
			<h1 class="iconSettings">Registry Settings</h1>

			<div class="formHeader">UDDI Details</div>
			<div class="formBody">
				<div class="formRow">
					<div class="formLabel">UDDI Server:</div>
					<div class="formField">
						<asp:TextBox ID="UDDIServer" CssClass="formFieldInput" Width="350" MaxLength="255" runat="server" Text='<%# Bind("UDDIServer") %>'></asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">Publishing Service Interval:</div>
					<div class="formField">
						<asp:TextBox ID="ServiceInterval" CssClass="formFieldInput" Width="350" MaxLength="255" runat="server" Text='<%# Bind("ServiceInterval") %>'></asp:TextBox>
					 Milliseconds</div>
				</div>
				<div class="formRow">
					<div class="formLabel">Categorization Schema:</div>
					<div class="formField">
					    <asp:TextBox ID="CategorySchema" CssClass="formFieldInput" Width="350" MaxLength="255" runat="server" Text='<%# Bind("CategorySchema") %>'></asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">LDAP Root:</div>
					<div class="formField">
					    <asp:TextBox ID="LdapRoot" CssClass="formFieldInput" Width="350" MaxLength="255" runat="server" Text='<%# Bind("LdapRoot") %>'></asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel"></div>
					<div class="formField">
						<asp:CheckBox ID="AutoPublishCheckBox" runat="server" Checked='<%# Bind("AutoPublish") %>' />Auto Publish
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel"></div>
					<div class="formField">
						<asp:CheckBox ID="Anonymous" runat="server" Checked='<%# Bind("Anonymous") %>' />Anonymous
					</div>
				</div>
			</div>
			
			<div class="formHeader">Email Notification</div>
			<div class="formBody">
				<div class="formRow">
					<div class="formLabel"></div>
					<div class="formField">
						<asp:CheckBox ID="NotificationEnabledCheckBox" runat="server" Checked='<%# Bind("NotificationEnabled") %>' />Notification Enabled
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						SMTP Server:</div>
					<div class="formField">
						<asp:TextBox ID="SMTPServerTextBox" CssClass="formFieldInput" Width="350" MaxLength="50" runat="server" Text='<%# Bind("SMTPServer") %>'></asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Notification E-Mail:</div>
					<div class="formField">
						<asp:TextBox ID="NotificationEmailTextBox" CssClass="formFieldInput" Width="350" MaxLength="50" runat="server" Text='<%# Bind("NotificationEmail") %>'></asp:TextBox><asp:RegularExpressionValidator ID="NotificationEmailTextBoxValidator" runat="server" ErrorMessage="Notification E-Mail must be a valid E-Mail format." Text="*" ControlToValidate="NotificationEmailTextBox" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						E-Mail From Address:</div>
					<div class="formField">
						<asp:TextBox ID="SMTPFromEmail" CssClass="formFieldInput" Width="350" MaxLength="50" runat="server" Text='<%# Bind("SMTPFromEmail") %>'>
						</asp:TextBox><asp:RegularExpressionValidator ID="SMTPFromEMailValidator" runat="server" ErrorMessage="From E-Mail must be a valid E-Mail format." Text="*" ControlToValidate="SMTPFromEmail" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						E-Mail Subject:</div>
					<div class="formField">
						<asp:TextBox ID="SMTPSubject" CssClass="formFieldInput" Width="350" MaxLength="255" runat="server" Text='<%# Bind("SMTPSubject") %>'>
						</asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Email XSLT File Absolute Path:</div>
					<div class="formField">
						<asp:TextBox ID="SMTPBody" CssClass="formFieldInput" Width="350" MaxLength="255" runat="server" Text='<%# Bind("SMTPBody") %>'>
						</asp:TextBox>
					</div>
				</div>
			</div>
			
			<div class="formHeader">Default Settings</div>
			<div class="formBody">
				<div class="formRow">
					<div class="formLabel">
						Contact Name:</div>
					<div class="formField">
						<asp:TextBox ID="ContactnameTextBox" CssClass="formFieldInput" Width="350" MaxLength="50" runat="server" Text='<%# Bind("Contactname") %>'>
						</asp:TextBox>
					</div>
				</div>
				<div class="formRow">
					<div class="formLabel">
						Contact E-Mail:</div>
					<div class="formField">
						<asp:TextBox ID="ContactEmailTextBox" CssClass="formFieldInput" Width="350" MaxLength="50" runat="server" Text='<%# Bind("ContactEmail") %>'>
						</asp:TextBox><asp:RegularExpressionValidator ID="ContactEmailTextBoxValidator" runat="server" ErrorMessage="Contact E-Mail must be a valid E-Mail format." Text="*" ControlToValidate="ContactEmailTextBox" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:RegularExpressionValidator>
					</div>
				</div>
			</div>
			
			<div class="formSubmit">
				<asp:Button ID="UpdateButton" runat="server" CssClass="formButton" CausesValidation="True" CommandName="Update" Text="Update" OnClick="UpdateButton_Click"></asp:Button>
				<asp:Button ID="UpdateCancelButton" runat="server" CssClass="formButton" CausesValidation="False" CommandName="Cancel" Text="Cancel"></asp:Button>
			</div>
				<asp:HiddenField ID="ID" runat="server" Value='<%# Bind("ID") %>' />
		</EditItemTemplate>
	</asp:FormView>
	<asp:ObjectDataSource ID="UDDIAdminObjectDataSource" runat="server" InsertMethod="Insert" OldValuesParameterFormatString="original_{0}" SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.Uddi.UDDIAdminDbTableAdapters.usp_get_uddi_adminTableAdapter" UpdateMethod="Update">
		<UpdateParameters>
			<asp:Parameter Name="smtpserver" Type="String" />
			<asp:Parameter Name="notificationemail" Type="String" />
			<asp:Parameter Name="notificationenabled" Type="Boolean" />
			<asp:Parameter Name="autopublish" Type="Boolean" />
			<asp:Parameter Name="contactname" Type="String" />
			<asp:Parameter Name="contactemail" Type="String" />
			<asp:Parameter Name="ID" Type="Int32" DefaultValue="1" />
			<asp:Parameter Name="SMTPFromEmail" Type="String" />
			<asp:Parameter Name="SMTPSubject" Type="String" />
			<asp:Parameter Name="SMTPBody" Type="String" />
			<asp:Parameter Name="UDDIServer" Type="String" />
			<asp:Parameter Name="Anonymous" Type="Boolean" />
			<asp:Parameter Name="ServiceInterval" Type="Int32" />
			<asp:Parameter Name="CategorySchema" Type="String" />
			<asp:Parameter Name="LdapRoot" Type="String" />
		</UpdateParameters>
		<SelectParameters>
			<asp:FormParameter DefaultValue="1" FormField="ID" Name="ID" Type="Int32" />
		</SelectParameters>
		<InsertParameters>
			<asp:Parameter Name="smtpserver" Type="String" />
			<asp:Parameter Name="notificationemail" Type="String" />
			<asp:Parameter Name="notificationenabled" Type="Boolean" />
			<asp:Parameter Name="autopublish" Type="Boolean" />
			<asp:Parameter Name="contactname" Type="String" />
			<asp:Parameter Name="contactemail" Type="String" />
			<asp:Parameter Name="ID" Type="Int32" DefaultValue="1" />
			<asp:Parameter Name="SMTPFromEmail" Type="String" />
			<asp:Parameter Name="SMTPSubject" Type="String" />
			<asp:Parameter Name="SMTPBody" Type="String" />
			<asp:Parameter Name="UDDIServer" Type="String" />
			<asp:Parameter Name="Anonymous" Type="Boolean" />
			<asp:Parameter Name="ServiceInterval" Type="Int32" />
			<asp:Parameter Name="CategorySchema" Type="String" />
			<asp:Parameter Name="LdapRoot" Type="String" />
		</InsertParameters>
	</asp:ObjectDataSource>
</asp:Content>
