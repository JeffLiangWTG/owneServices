//---------------------------------------------------------------------
// File:  ServiceProxy.cs
// 
// Summary: Proxy class that mediates communication with various application services.
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Practices.ESB.Portal;
using Microsoft.Practices.ESB.Portal.UDDIService;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;

namespace Microsoft.Practices.ESB.Portal.Uddi
{
    public class ServiceProxy
    {
        /// <summary>
        /// Gets all EndPoints for an Application.
        /// </summary>
        /// <param name="applicationName"></param>
        /// <param name="getSendPorts"></param>
        /// <param name="getRcvLocations"></param>      
        public Endpoints.EndpointDataTable GetEndpointsByApplication(string applicationName, bool getSendPorts, bool getRcvLocations)
        {
             Endpoints theEndpoints = getBTEndpoints(applicationName, getSendPorts, getRcvLocations);

             // Now match pending requests with the BizTalk endpoints
             Endpoints pendingEndpoints =
                 new AdminDatabaseService().GetPendingAndNonRegCases(applicationName);

             foreach (Endpoints.EndpointRow pendEp in pendingEndpoints.Endpoint)
             {
                 string filter = string.Format("ID='{0}'", pendEp.ID.ToString());
                 Endpoints.EndpointRow[] rows = theEndpoints.Endpoint.Select(filter) as Endpoints.EndpointRow[];
                 if (rows.Length > 0)
                 {
                     rows[0].Status = "Pending";
                 }
             }
             return theEndpoints.Endpoint;
        }
        /// <summary>
        /// Get an EndPoint by ID from the Database.
        /// </summary>
        /// <param name="strBizTalkApplication">BizTalk Application</param>
        public Endpoints.EndpointRow GetEndPointByPortName(string strBizTalkApplication, string strBizTalkPort)
        {
             Endpoints.EndpointRow theEndpoint;

             // First see if the endpoint is pending in the admin database.
             theEndpoint = new AdminDatabaseService().GetPendingCaseByPort(strBizTalkApplication, strBizTalkPort);

             // If it isn't get it from BizTalk
             if (theEndpoint == null)
             {
                 theEndpoint = this.getBTEndpointByPortName(strBizTalkApplication, strBizTalkPort);
             }
             return theEndpoint;
        }

        /// <summary>
        /// Publish and EndPoint to the database.
        /// </summary>
        /// <param name="ep">EndpointRow</param>
        public Boolean PublishEndpoint(Endpoints.EndpointRow ep)
        {
            // For now, all endpoint publications are persisted, pending approval.
            // In the future, certain users could bypass approval and publish directly to UDDI.

            // Save to the Database
            SaveEndpointPendingApproval(ep);

            // The EndPoint is now saved to the Pending Table.
            // Check to see if Auto Publish is enabled.  If so, then push to UDDI
            if (!AutoPublishEndPoint(ep))
            {
                // Error has occurred, so return 
                return false;
            }
            return true;
        }
        /// <summary>
        /// Checks to see if AutoPublish is enabled.  If so, then publish to UDDI.
        /// </summary>
        /// <param name="ep">EndpointRow</param>
        private Boolean AutoPublishEndPoint(Endpoints.EndpointRow ep)
        {
            try
            {
                // Get the values from the Admin Table to see if AutoPublish is enabled
                UDDIDataAccess da = new UDDIDataAccess(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString);
                DataTable dt = da.RetrieveAdmin();
                DataRow dr = dt.Rows.Count > 0 ? dt.Rows[0] : null;

                string strUDDIServer = dr["UDDIServer"].ToString();
                Boolean blnAutoPublish = (Boolean)dr["AutoPublish"];
                if (blnAutoPublish)
                {
                    // We now have the record we need, call the UDDI Service
                    UDDIService.UDDIService ESBws = UDDIService.UDDIService.CreateInstance();
                    ESBws.PublishBusinessInfoPortal(
                        strUDDIServer,
                        ep.BusinessProvider,
                        ep.ServiceName,
                        ep.Description,
                        ep.UDDIContactName,
                        ep.UDDIEMail,
                        ep.UDDIUserType,
                        BindingTypeMapper.ToUddiBindingType(ep.TransPortType),
                        ep.TransPortType,
                        ep.EndpointValue,
                        ep.Category,
                        ep.TargetNamespace,
                        ep.MessageExchangePattern,
                        ep.JaxRPCResponse,
                        ep.ServiceAction,
                        ep.CacheTimeOut,
                        ep.BizTalkApplication,
                        ep.EndpointName
                        );

                    AdminDatabaseService adminsvc = new AdminDatabaseService();
                    adminsvc.UpdatePendingStatus(new Guid(ep.ID), "AutoApproved");  
                }
                return true;
            }
            catch
            {
                throw;
               // return false;
            }
        }
        /// <summary>
        /// Saves and Endpoint in a Pending Status.
        /// </summary>
        /// <param name="ep">EndpointRow</param>
        private void SaveEndpointPendingApproval(Endpoints.EndpointRow ep)
        {
            ep.Status = "Pending";
            new AdminDatabaseService().UpdatePendingCase(ep);
        }
        /// <summary>
        /// Saves and Endpoint in a Pending Status for a Deletion.
        /// </summary>
        /// <param name="ep">EndpointRow</param>
        public void SaveEndpointDeleteApproval(Endpoints.EndpointRow ep)
        {
            ep.Status = "Pending";
            ep.RequestAction = "Delete";
            new AdminDatabaseService().UpdatePendingCase(ep);
        }
        /// <summary>
        /// Gets a BizTalk EndPoint for a specific ID.
        /// </summary>
        /// <param name="strBizTalkApplication">BizTalk Application Name</param>
        /// <param name="strBizTalkPortName">BizTalk Port Name</param>
        private Endpoints.EndpointRow getBTEndpointByPortName(string strBizTalkApplication, string strBizTalkPortName)
        {
            Endpoints theEndpoints = new Endpoints();            
            BizTalkOperationsService.Operations btService = BizTalkOperationsService.Operations.CreateInstance();
            
            // Get default contact info
            UDDIDataAccess da = new UDDIDataAccess(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString);
            DataTable dt = da.RetrieveAdmin();
            DataRow dr = dt.Rows.Count > 0 ? dt.Rows[0] : null;
            string defaultUddiContactName = dr != null ? dr["ContactName"].ToString() : string.Empty;
            string defaultUddiEmail = dr != null ? dr["ContactEmail"].ToString() : string.Empty;
            string uddiServer = dr != null ? dr["UDDIServer"].ToString() : string.Empty;
            
            BizTalkOperationsService.BTSysStatus status = btService.ApplicationStatus(strBizTalkApplication);
            
            // Loop through until we find an entry that matches our port
            foreach (BizTalkOperationsService.BTSendPort item in status.SendPorts)
            {
                if (item.Name == strBizTalkPortName)
                {
                    // Now get all of the values for the endpoint
                    Endpoints.EndpointRow r = theEndpoints.Endpoint.NewEndpointRow();

                    // This is building a row in the DataTable for display
                    r.BindingType = "Send";
                    r.BizTalkApplication = item.ApplicationName != null ? item.ApplicationName : string.Empty;
                    r.Category = string.Empty;
                    r.Description = string.Empty;
                    r.EndpointName = item.Name;
                    r.EndpointValue = item.Address != null ? item.Address : "Dynamic";
                    r.ID = item.Guid.ToString();
                    r.Status = "Not Registered";
                    r.TransPortLocation = item.Address != null ? item.Address : "Dynamic";
                    r.TransPortType = item.Handler.ProtocolName != null ? item.Handler.ProtocolName : "Dynamic";
                    r.UDDIContactName = defaultUddiContactName;
                    r.UDDIEMail = defaultUddiEmail;
                    r.UDDIUserType = string.Empty;
                    r.MessageExchangePattern = "One-Way";
                    r.TargetNamespace = string.Empty;
                    r.JaxRPCResponse = "False";
                    r.ServiceAction = string.Empty;
                    r.CacheTimeOut = "-1";
                    r.RequestAction = string.Empty;
                    r.ModifiedBy = string.Empty;
                    r.BusinessProvider = item.ApplicationName;
                    r.ServiceName = item.Name;

                    return r;
                }
            }
            
            foreach (BizTalkOperationsService.BTReceiveLocation item in status.ReceiveLocations)
            {
                if (item.Name == strBizTalkPortName)
                {
                    Endpoints.EndpointRow r = theEndpoints.Endpoint.NewEndpointRow();

                    // This is building a row in the DataTable for display
                    r.BindingType = "Receive";
                    r.BizTalkApplication = item.Application != null ? item.Application : string.Empty;
                    r.Category = string.Empty;
                    r.Description = string.Empty;
                    r.EndpointName = item.Name;
                    r.EndpointValue = item.Address != null ? item.Address : "Dynamic";
                    r.ID = item.Guid.ToString();
                    r.Status = "Not Registered";
                    r.TransPortLocation = item.Address != null ? item.Address : "Dynamic";
                    r.TransPortType = item.Handler.ProtocolName != null ? item.Handler.ProtocolName : "Dynamic";
                    r.UDDIContactName = defaultUddiContactName;
                    r.UDDIEMail = defaultUddiEmail;
                    r.UDDIUserType = string.Empty;
                    if (item.TwoWay)
                        r.MessageExchangePattern = "Two-Way";
                    else
                        r.MessageExchangePattern = "One-Way";
                    r.ModifiedBy = string.Empty;
                    r.TargetNamespace = string.Empty;
                    r.JaxRPCResponse = "False";
                    r.ServiceAction = string.Empty;
                    r.CacheTimeOut = "-1";
                    r.RequestAction = string.Empty;
                    r.ModifiedBy = string.Empty;
                    r.BusinessProvider = item.Application;
                    r.ServiceName = item.Name;

                    return r;
                
                }
            }
            return null;
        }

        //}
        /// <summary>
        /// Called to Remove a UDDI EndPoint.  If Auto Publish is on, then
        /// the endpoint will get removed.  If not, the endpoint will be 
        /// put in a pending status.
        /// </summary>
        /// <param name="strBizTalkApplication">BizTalk Application</param>
        /// <param name="strBizTalkPort">BizTalk Port Name</param>
        //protected void RemoveUDDIEntry(Guid ID)
        public Boolean RemoveUDDIEntry(string strBizTalkApplication, string strBizTalkPort)
        {
            try
            {
                Endpoints.EndpointRow endPoint = GetEndPointByPortName(strBizTalkApplication, strBizTalkPort);
                if (endPoint != null)
                {
                    // Get Admin Info
                    UDDIDataAccess da = new UDDIDataAccess(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString);
                    DataTable dt = da.RetrieveAdmin();
                    DataRow dr = dt.Rows.Count > 0 ? dt.Rows[0] : null;

                    string strUDDIServer = dr["UDDIServer"].ToString();
                    Boolean blnAutoPublish = (Boolean)dr["AutoPublish"];
                    if (blnAutoPublish)
                    {
                        // If AutoPublish is on, then we can remove from UDDI
                        //deleteUDDIEndpoint(endPoint.EndpointName);
                        deleteUDDIEndpoint(strBizTalkApplication, strBizTalkPort);
                    }
                    else
                    {
                        // The Request will be put in a pending state
                        SaveEndpointDeleteApproval(endPoint);
                    }
                }
            }
            catch
            {
                throw;
               // return false;
            }
            return true;
        }
        

        /// <summary>
        /// Removes a UDDI Entry from UDDI using Service Name
        /// </summary>
        /// <param name="strBizTalkApplication">BizTalk Application</param>
        /// <param name="strBizTalkPort">BizTalk Port Name</param>
        public Boolean deleteUDDIEndpoint(string strBizTalkApplication, string strBizTalkPort)
        {
            try
            {

                UDDIService.UDDIService uddiService = UDDIService.UDDIService.CreateInstance();

                UDDIDataAccess da = new UDDIDataAccess(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString);
                DataTable dt = da.RetrieveAdmin();
                DataRow dr = dt.Rows.Count > 0 ? dt.Rows[0] : null;

                string strUDDIServer = dr["UDDIServer"].ToString();

                UDDIService.serviceDetail[] svcDetail;

                // Get the Category Key
                tModel tModelCategory = uddiService.GetCategoryByName(strUDDIServer, "microsoft-com:esb:runtimeresolution:biztalkapplication");

                string strCategoryKey = tModelCategory.tModelKey;

                svcDetail = uddiService.GetPortNamesByKeyValue(strUDDIServer, strCategoryKey, "biztalkapplication", strBizTalkApplication);
                string strservicekey = string.Empty;
                // Now find the Service Key for the Port
                for (int x = 0; x < svcDetail.Length; x++)
                {
                    foreach (keyedReference keyRef in svcDetail[x].businessService[0].bindingTemplates[0].categoryBag.Items)
                    {
                        if (keyRef.keyName == "Port Name" && keyRef.keyValue == strBizTalkPort)
                        {
                            // This is the correct entry, so we can now get the Service Key
                            strservicekey = svcDetail[x].businessService[0].serviceKey;
                        }
                    }
                }
                if (string.IsNullOrEmpty(strservicekey))
                {
                    return false;
                }
                else
                {
                    uddiService.DeleteService(strUDDIServer, strservicekey);

                    // Change the Status to Deleted
                    AdminDatabaseService adminsvc = new AdminDatabaseService();
                    adminsvc.UpdatePendingStatusByName(strBizTalkApplication, strBizTalkPort, "Deleted");
                    return true;  
                }
            }
            catch
            {
                throw;
                //return false;
            }
                 
        }

        /// <summary>
        /// Gets all Business Providers from UDDI
        /// The results will contain duplicates, so we have to remove them
        /// </summary>
        public DataTable GetBusinesses()
        {          
            // Call the UDDI Service to return all businesses
            UDDIService.UDDIService svc = UDDIService.UDDIService.CreateInstance();
            UDDIDataAccess da = new UDDIDataAccess(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString);
            DataTable dtAdmin = da.RetrieveAdmin();
            DataRow dr = dtAdmin.Rows.Count > 0 ? dtAdmin.Rows[0] : null;
            string strUDDIServer = dr["UDDIServer"].ToString();

            UDDIService.businessInfo[] binfo = svc.GetMyBusinesses(strUDDIServer); //fix when returns null

            // We now have all Businesses, so lets put them into a datatable
            DataTable dt = CreateItemDataTable();

            if (null == binfo)
            {
                return dt;
            }
            DataRow row;
            string strApp = string.Empty;

            // Load all entries into a DataTable
            for (int intCount = 0; intCount < binfo.Length; intCount++)
            {
                row = dt.NewRow();
                row["item"] = binfo[intCount].name[0].Value;
                dt.Rows.Add(row);
                strApp = binfo[intCount].name[0].Value;
            }
            dt.DefaultView.Sort = "item";
            
            // We have all of items, but we will have dups.  Remove the dups
            DataTable dtnew = CreateItemDataTable();
            string lastvalue = string.Empty;
            row = dtnew.NewRow();
            row["item"] = "New";
            dtnew.Rows.Add(row);

            foreach (DataRow drow in dt.Select(""))
            {
                if (lastvalue != drow["item"] as string)
                {
                    row = dtnew.NewRow();
                    row["item"] = drow["item"];
                    dtnew.Rows.Add(row);
                    lastvalue = drow["item"] as string;
                }
            }
         return dtnew;
        }
        /// <summary>
        /// Creates a DataTable with one Item
        /// </summary>
        private DataTable CreateItemDataTable()
        {
            DataColumn column;
           
            DataTable dt = new DataTable();
            column = new DataColumn();
            column.DataType = Type.GetType("System.String");
            column.ColumnName = "item";
            dt.Columns.Add(column);

            dt.DefaultView.Sort = "item";
            return dt;
        }

        /// <summary>
        /// Gets all EndPoints from BizTalk.
        /// </summary>
        /// <param name="applicationName">BizTalk Application</param>
        /// <param name="getSendPorts">Return Send Ports</param>
        /// <param name="getRcvLocations">Return Receive Locations</param>
        private Endpoints getBTEndpoints(string applicationName, bool getSendPorts, bool getRcvLocations)
        {
            
                Endpoints theEndpoints = new Endpoints();

                BizTalkOperationsService.Operations btService = BizTalkOperationsService.Operations.CreateInstance();

                // Get default contact info
                UDDIDataAccess da = new UDDIDataAccess(ConfigurationManager.ConnectionStrings["AdminDatabaseServer"].ConnectionString);
                DataTable dt = da.RetrieveAdmin();
                DataRow dr = dt.Rows.Count > 0 ? dt.Rows[0] : null;
                string defaultUddiContactName = dr != null ? dr["ContactName"].ToString() : string.Empty;
                string defaultUddiEmail = dr != null ? dr["ContactEmail"].ToString() : string.Empty;
                string uddiServer = dr != null ? dr["UDDIServer"].ToString() : string.Empty;

                BizTalkOperationsService.BTSysStatus status = btService.ApplicationStatus(applicationName);
                if (getSendPorts)
                {
                    // Go through each Send Port and pull the necessary data
                   foreach (BizTalkOperationsService.BTSendPort item in status.SendPorts)
                    {
                        if (applicationName == null || item.ApplicationName == applicationName)
                        {
                            Endpoints.EndpointRow r = theEndpoints.Endpoint.NewEndpointRow();

                            // This is building a row in the DataTable for display
                            r.BindingType = "Send";
                            r.BizTalkApplication = item.ApplicationName != null ? item.ApplicationName : string.Empty;
                            r.Category = string.Empty;
                            r.Description = string.Empty;
                            r.EndpointName = item.Name;
                            r.EndpointValue = item.Address != null ? item.Address : "Dynamic";
                            r.ID = item.Guid.ToString();
                            r.Status = "Not Registered";
                            r.TransPortLocation = item.Address != null ? item.Address : "Dynamic";
                            r.TransPortType = item.Handler.ProtocolName != null ? item.Handler.ProtocolName : "Dynamic";
                            r.UDDIContactName = defaultUddiContactName;
                            r.UDDIEMail = defaultUddiEmail;
                            r.UDDIUserType = string.Empty;
                            r.MessageExchangePattern = "One-Way";
                            r.TargetNamespace = string.Empty;
                            r.JaxRPCResponse = "False";
                            r.ServiceAction = string.Empty;
                            r.CacheTimeOut = "-1";
                            r.RequestAction = string.Empty;
                            r.ModifiedBy = string.Empty;
                            r.BusinessProvider = item.ApplicationName;
                            r.ServiceName = item.Name;

                            theEndpoints.Endpoint.AddEndpointRow(r);
                        }
                    }
                }

                if (getRcvLocations)
                {
                    // Go through each Receive Location and pull the necessary information
                   foreach (BizTalkOperationsService.BTReceiveLocation item in status.ReceiveLocations)
                    {
                        if (applicationName == null || item.Application == applicationName)
                        {
                            Endpoints.EndpointRow r = theEndpoints.Endpoint.NewEndpointRow();

                            // This is building a row in the DataTable for display
                            r.BindingType = "Receive";
                            r.BizTalkApplication = item.Application != null ? item.Application : string.Empty;
                            r.Category = string.Empty;
                            r.Description = string.Empty;
                            r.EndpointName = item.Name;
                            r.EndpointValue = item.Address != null ? item.Address : "Dynamic";
                            r.ID = item.Guid.ToString();
                            r.Status = "Not Registered";
                            r.TransPortLocation = item.Address != null ? item.Address : "Dynamic";
                            r.TransPortType = item.Handler.ProtocolName != null ? item.Handler.ProtocolName : "Dynamic";
                            r.UDDIContactName = defaultUddiContactName;
                            r.UDDIEMail = defaultUddiEmail;
                            r.UDDIUserType = string.Empty;
                            if (item.TwoWay)
                                r.MessageExchangePattern = "Two-Way";
                            else
                                r.MessageExchangePattern = "One-Way";
                            r.ModifiedBy = string.Empty;
                            r.TargetNamespace = string.Empty;
                            r.JaxRPCResponse = "False";
                            r.ServiceAction = string.Empty;
                            r.CacheTimeOut = "-1";
                            r.RequestAction = string.Empty;
                            r.ModifiedBy = string.Empty;
                            r.BusinessProvider = item.Application;
                            r.ServiceName = item.Name;

                            theEndpoints.Endpoint.AddEndpointRow(r);
                        }
                    }
                }
                // We have a list of all BizTalk Send Ports and Receive Locations
                // Now let's see which ones exist in UDDI
                // Call UDDI and return all Services for the BizTalk Appliation
                UDDIService.UDDIService uddiService = UDDIService.UDDIService.CreateInstance();
                serviceDetail[] svcDetail;
                tModel tModelCategory = uddiService.GetCategoryByName(uddiServer, "microsoft-com:esb:runtimeresolution:biztalkapplication");

                string strCategoryKey = tModelCategory.tModelKey;


                if (string.IsNullOrEmpty(uddiServer))
                {
                    svcDetail = uddiService.GetPortNamesByKeyValue(string.Empty, strCategoryKey, "BizTalkApplication", applicationName);
                }
                else
                {
                    svcDetail = uddiService.GetPortNamesByKeyValue(uddiServer, strCategoryKey, "BizTalkApplication", applicationName);
                }

                // Have all UDDI EndPoints for the Application, now see if there is a match in our EndPoints
                //foreach (keyedReference keyRef in busDetail.businessEntity[0].businessServices[0].categoryBag)
                for (int intCount = 0; intCount < svcDetail.Length; intCount++)
                {
                    foreach (keyedReference keyRef in svcDetail[intCount].businessService[0].bindingTemplates[0].categoryBag.Items)
                    {
                        if (keyRef.keyName == "Port Name")
                        {
                            // Check to see if this Port Name matches
                            string filter = string.Format("EndpointName='{0}'", keyRef.keyValue);
                            Endpoints.EndpointRow[] rows = theEndpoints.Endpoint.Select(filter) as Endpoints.EndpointRow[];
                            if (rows.Length > 0)
                            {
                                rows[0].Status = "Registered";
                            }
                        }
                    }
                }

                return theEndpoints;
        }
    }
}
