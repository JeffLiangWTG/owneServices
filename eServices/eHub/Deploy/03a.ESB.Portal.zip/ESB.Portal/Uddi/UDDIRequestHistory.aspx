<%@ Page Language="C#" AutoEventWireup="true" MasterPageFile="~/Layout.Master" CodeBehind="UDDIRequestHistory.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Uddi.UDDIRequestHistory" Title="ESB Management Console - Registry"%>

<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers"
    TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <asp:ObjectDataSource ID="HistoryObjectSource" runat="server" SelectMethod="GetData" 
    TypeName="Microsoft.Practices.ESB.Portal.Uddi.UDDIRequestHistoryDbTableAdapters.usp_get_request_historyTableAdapter" 
    OldValuesParameterFormatString="original_{0}"></asp:ObjectDataSource>    
    <h1 class="iconRegistry">Request History</h1><br /><br />
    <asp:Image ID="Image1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
    <asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton>
    <asp:GridView 
		ID="GridView1" 
		runat="server" 
		AllowPaging="True" 
		AllowSorting="true"
		AutoGenerateColumns="False"
        DataSourceID="HistoryObjectSource" 
        GridLines="None" >
        
		<HeaderStyle CssClass="tableHeader" />
		<RowStyle CssClass="tableRow" />
        <Columns>
		    <asp:TemplateField  HeaderText="Type" SortExpression="BindingType">
			    <ItemTemplate>
				    <%# GetTypeIcon(DataBinder.Eval(Container.DataItem, "BindingTYpe"))%>
			    </ItemTemplate>
		    </asp:TemplateField>            
		    <asp:BoundField DataField="BusinessProvider" HeaderText="Business Provider" SortExpression="BusinessProvider" />
		    <asp:TemplateField  HeaderText="Service Name" SortExpression="ServiceName">
			    <ItemTemplate>
				    <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "ServiceName"), 25)%>
			    </ItemTemplate>
		    </asp:TemplateField>
            <asp:BoundField DataField="BizTalkApplication" HeaderText="BizTalk Application" SortExpression="BiztalkApplication" />
		    <asp:TemplateField  HeaderText="Port Name" SortExpression="EndpointName">
			    <ItemTemplate>
				    <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "EndpointName"), 25)%>
			    </ItemTemplate>
		    </asp:TemplateField>
            <asp:BoundField DataField="Status" HeaderText="Status" SortExpression="Status" />
		    <asp:TemplateField  HeaderText="Modified By" SortExpression="ModifiedBy">
			    <ItemTemplate>
				    <%# GetCrumbedString((Object) (Convert.ToString(DataBinder.Eval(Container.DataItem, "ModifiedBy"))), 20)%>
			    </ItemTemplate>
		    </asp:TemplateField>
		    <asp:TemplateField  HeaderText="Request Date" SortExpression="ModifiedDate">
			    <ItemTemplate>
				    <%# GetCrumbedString(Convert.ToString(DataBinder.Eval(Container.DataItem, "ModifiedDate")), 25)%>
			    </ItemTemplate>
		    </asp:TemplateField>
            <asp:BoundField DataField="ID" Visible="false" HeaderText="ID" SortExpression="ID" />
            <asp:BoundField DataField="Description" Visible="false" HeaderText="Description" SortExpression="Description" />
            <asp:BoundField DataField="EndpointValue" Visible="false" HeaderText="Endpoint Value" SortExpression="EndpointValue" />
            
            <asp:TemplateField  HeaderText="Endpoint Value" SortExpression="EndpointValue">
			    <ItemTemplate>
				    <%# GetCrumbedString((Object)(Convert.ToString(DataBinder.Eval(Container.DataItem, "EndpointValue"))), 20)%>
			    </ItemTemplate>
		    </asp:TemplateField>
            <asp:BoundField DataField="TransportType" visible="false" HeaderText="Transport Type" SortExpression="TransportType" />
            <asp:BoundField DataField="TransportLocation" Visible="false" HeaderText="Transport Location" SortExpression="TransportLocation" />
            <asp:BoundField DataField="UDDIContactName" Visible="false" HeaderText="UDDI Contact Name" SortExpression="UDDIContactName" />
            <asp:BoundField DataField="UDDIEmail" Visible="false" HeaderText="UDDI Email" SortExpression="UDDIEmail" />
            <asp:BoundField DataField="UDDIUserType" Visible="false" HeaderText="UDDI User Type" SortExpression="UDDIUserType" />
            <asp:BoundField DataField="Category" Visible="false" HeaderText="Category" SortExpression="Category" />
            <asp:BoundField DataField="TargetNamespace" HeaderText="Target Namespace" SortExpression="TargetNamespace" />
            <asp:BoundField DataField="MessageExchangePattern" HeaderText="Message ExchangePattern"
                SortExpression="MessageExchangePattern" />
            <asp:CheckBoxField DataField="JaxRPCResponse" Visible="false" HeaderText="JaxRPC Response" SortExpression="JaxRPCResponse" />
            <asp:BoundField DataField="ServiceAction" Visible="false" HeaderText="Service Action" SortExpression="ServiceAction" />
            <asp:BoundField DataField="CacheTimeOut" Visible="false" HeaderText="Cache TimeOut" SortExpression="CacheTimeOut" />
            <asp:BoundField DataField="RequestAction" Visible="false" HeaderText="Request Action" SortExpression="RequestAction" />
            <asp:BoundField DataField="BusinessService" Visible="false" HeaderText="Business Service" SortExpression="BusinessService" />
        </Columns>
        
        <EditRowStyle BackColor="#999999" />
        <SelectedRowStyle BackColor="#E2DED6" Font-Bold="True" ForeColor="#333333" />
        <PagerStyle BackColor="#284775" ForeColor="White" HorizontalAlign="Center" />
        <HeaderStyle BackColor="#5D7B9D" Font-Bold="True" ForeColor="White" />
        <EmptyDataTemplate>No Registration History Exists.</EmptyDataTemplate>
    </asp:GridView>
    <cc1:GridViewSortExtender ID="GridViewSortExtender1" runat="server" AscendingImageUrl="~/Images/asc_order.gif"
        DescendingImageUrl="~/Images/desc_order.gif" ExtendeeID="GridView1">
    </cc1:GridViewSortExtender>

</asp:Content>
