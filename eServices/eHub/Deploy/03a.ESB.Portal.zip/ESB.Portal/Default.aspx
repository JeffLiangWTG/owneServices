<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Default" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
    
    <script type="text/javascript">
      function SetTZO()
        {
        
             var d = new Date();
             var tzo = -1 * d.getTimezoneOffset()/60;
        
            document.location = "Home/Homepage.aspx?tzo="+tzo;
        }
    
    
    </script> 
    
</head>
<body onload="SetTZO();" >
    <form id="form1" runat="server">
    <div>
    
    </div>
    </form>
</body>
</html>
