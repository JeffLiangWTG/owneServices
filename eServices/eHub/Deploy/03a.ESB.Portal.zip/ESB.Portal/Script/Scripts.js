
//---------------------------------------------------------------------
// File:  Script.js
// 
// Summary: This file contains various Javascript functions to perform
//          tasks such as date formatting and querystring manipulation.
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

function formatUTCToLocalShortDate(utcString)
{
	var d = utcToLocalDate(utcString);
    
	return (d.getMonth() + 1) + "/" + d.getDate() + "/" + d.getFullYear() + " " + d.toLocaleTimeString();
}

/// <summary>
/// Converts a UTC datetime string into local time.  Returns a javascript Date object.
/// </summary>
/// <param name="utc">String.  Any standard date format.</param>
function utcToLocalDate(utc)
{
    var utcDate = new Date(utc); 
    var localDate = new Date();    
    var utcMSecs = utcDate.getTime();     
    //1000 milliseconds = 1 second, and 1 minute = 60 seconds, so 60 * 1000 = 60000 ms = 1 hour
    var localOffsetMSecs = localDate.getTimezoneOffset() * 60000;  
    var localMSecs = utcMSecs - localOffsetMSecs;
    var localExceptionDate = new Date(localMSecs);
    return localExceptionDate;
}

/// <summary>
/// Converts a UTC datetime string into local time.  Returns a javascript Date object.
/// </summary>
/// <param name="utc">String.  Any standard date format.</param>
function localToUtcDate(local)
{    
    var localDate = new Date(local);     
    var localMSec = localDate.getTime();
    
    //1000 milliseconds = 1 second, and 1 minute = 60 seconds, so 60 * 1000 = 60000 ms = 1 hour
    var localOffsetMSecs = localDate.getTimezoneOffset() * 60000;  
    var utcMSecs = localMSec + localOffsetMSecs;    
    var utcDate = new Date(utcMSecs);    
    return utcDate;    
}

/// <summary>
/// Takes an hour and minute (24 hour scale) and converts them to local time.
/// </summary>
function convertUtcTimeToLocal(utcHour, utcMinute)
{
   var utcDate = new Date();
   utcDate.setHours(utcHour);
   utcDate.setMinutes(utcMinute);
   var localDate = utcToLocalDate(utcDate);
   var localMeridiem = " AM";
   var localHours = localDate.getHours();
   if(localHours > 12)
   {
      localHours -= 12;
      localMeridiem = " PM";
   }
   var localMinutes = localDate.getMinutes();
   if (localMinutes < 10)
   {
      localMinutes = "0" + localMinutes;
   }
   return localHours + ":" + localMinutes + localMeridiem;
}

/// <summary>
/// Formats the local date in MM/dd/YYYY format.
/// </summary>
function FormatLocalDate(localDate) {
    return (localDate.getMonth() + 1) + "/" + localDate.getDate() + "/" + localDate.getFullYear();
}

/// <summary>
/// Formats a date in MM/dd/YYYY hh:mm format.
/// </summary>
function FormatDateTime(dateTime)
{
   return (dateTime.getMonth() + 1) + "/" + dateTime.getDate() + "/" + dateTime.getFullYear() + " " + dateTime.getHours() + ":" + dateTime.getMinutes();
}

/// <summary>
/// Strips the ESB querystring parameters out of the URL.  Returns a URL that has been cleansed of all ESB parameters.
/// Identifies the ESB parameters by the prefix "esb:".
/// </summary>
/// <param name="mainForm">DHTML form object.  This should be the main form for the page.</param>
function stripESBQueryStringParams(url)
{
    var returnUrl = unescape(url).split("?")[0] + "?";			    	    
    
    if(url.split("?").length > 1)
    {
        var queryStringArray = unescape(url).split("?")[1].split("&");	
        	
        for(var i=0; i < queryStringArray.length; i++) 
        {                     
            //if the param is not for ESB (does not start with 'esb:'
            if(queryStringArray[i].split("=")[0].indexOf("esb:") < 0)
            {  
                returnUrl += queryStringArray[i] + "&";
            }
        }
    }           
    
    //returnUrl = cleanUrlTail(returnUrl);
    
    return returnUrl; 
}

/// <summary>
/// Strips the ESB querystring parameters out of the URL.  Returns a URL that has been cleansed of all ESB parameters.
/// Identifies the ESB parameters by the prefix "esb:".
/// </summary>
/// <param name="mainForm">DHTML form object.  This should be the main form for the page.</param>
function removeQueryStringParam(url, paramName)
{
    var returnUrl = unescape(url).split("?")[0] + "?";			    	    
 
    if(url.split("?").length > 1)
    {
        var queryStringArray = unescape(url).split("?")[1].split("&");	
        	
        for(var i=0; i < queryStringArray.length; i++) 
        {
            //if the param is not for ESB (does not start with 'esb:'
            if(queryStringArray[i].split("=")[0] != paramName)
            {  
                returnUrl += queryStringArray[i] + "&";                
            }
        }
    }
    
    returnUrl = cleanUrlTail(returnUrl);
    
    return returnUrl; 
}

/// <summary>
/// This function removes any trailing '?' or '&' characters from a URL.
/// </summary>
/// <param name="URL">The URL string.</param>
function cleanUrlTail (Url)
{
    var returnUrl = Url;
    
    if(returnUrl.substring(returnUrl.length - 1, returnUrl.length) == "&")
    {
        returnUrl = returnUrl.substring(0, returnUrl.length - 1);
    }
    
    if(returnUrl.substring(returnUrl.length - 1, returnUrl.length) == "?")
    {
        returnUrl = returnUrl.substring(0, returnUrl.length - 1);
    }
    
    return returnUrl;
}