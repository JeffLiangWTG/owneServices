﻿using Microsoft.Practices.ESB.Portal.DataSets.AlertsTableAdapters;
using System.Data;
using System;
using System.Transactions;
using System.Data.SqlClient;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;
namespace Microsoft.Practices.ESB.Portal.DataSets 
{

    partial class Alerts
    {
        //public void FillAlertsAndSubscriptionsForAdmin()
        //{
        //    AlertTableAdapter ata = new AlertTableAdapter();
        //    ata.FillAlerts(this.Alert);

        //    AlertSubscriptionTableAdapter asta = new AlertSubscriptionTableAdapter();
        //    asta.FillAlertSubscriptions(this.AlertSubscription);
        //}

        //public void FillAlertsAndSubscriptionsForSubscriber(string subscriber)
        //{
        //    AlertTableAdapter ata = new AlertTableAdapter();
        //    ata.FillAlerts(this.Alert);

        //    AlertSubscriptionTableAdapter asta = new AlertSubscriptionTableAdapter();
        //    asta.FillAlertSubscriptionsBySubscriber(this.AlertSubscription, subscriber);
        //}

        //public void FillAlertForSubscriber(Guid id, string subscriber)
        //{
        //    AlertTableAdapter ata = new AlertTableAdapter();
        //    ata.Fill(this.Alert, id);

        //    AlertConditionTableAdapter acta = new AlertConditionTableAdapter();
        //    acta.Fill(this.AlertCondition, id);

        //    AlertSubscriptionTableAdapter asta = new AlertSubscriptionTableAdapter();
        //    asta.Fill(this.AlertSubscription, id);
        //}

        public DataView GetAlertSubscriptionsView(List<AlertSubscription> subscriptions)
        {
            DataView dv = new DataView();
            dv.Table = new DataTable("AlertSubscriptions");
            dv.Table.Columns.Add("AlertID", typeof(Guid));
            dv.Table.Columns.Add("AlertSubscriptionID", typeof(Guid));
            dv.Table.Columns.Add("AlertName", typeof(string));
            dv.Table.Columns.Add("Active", typeof(bool));
            dv.Table.Columns.Add("StartUTCHour", typeof(string));
            dv.Table.Columns.Add("StartUTCMinute", typeof(string));
            dv.Table.Columns.Add("EndUTCHour", typeof(string));
            dv.Table.Columns.Add("EndUTCMinute", typeof(string));
            dv.Table.Columns.Add("Subscriber", typeof(string));
            dv.Table.Columns.Add("IsGroup", typeof(bool));
            dv.Table.Columns.Add("UseStartAndEndTime", typeof(bool));

            foreach (AlertSubscription r in subscriptions)
            {
                DataRow newRow = dv.Table.NewRow();
                newRow["AlertSubscriptionID"] = r.AlertSubscriptionID;
                newRow["AlertID"] = r.AlertID;

                IExceptionService client = null;
                Alert alert = null;
                try
                {
                    client = PortalHelper.GetExceptionService();
                    alert = client.GetAlertById(r.AlertID);
                }
                finally
                {
                    if (client != null)
                    {
                        ((IDisposable)client).Dispose();
                    }
                }

                if (alert != null)
                {
                    newRow["AlertName"] = alert.Name;
                }
                else
                {
                    newRow["AlertName"] = string.Empty;
                }

                newRow["Active"] = r.Active;
                newRow["StartUTCHour"] = r.StartUTCHour.Value.ToString("#0");
                newRow["StartUTCMinute"] = r.StartUTCMinute.Value.ToString("00");
                newRow["EndUTCHour"] = r.EndUTCHour.Value.ToString("#0");
                newRow["EndUTCMinute"] = r.EndUTCMinute.Value.ToString("00");

                newRow["Subscriber"] = r.Subscriber;
                newRow["IsGroup"] = r.IsGroup;
                newRow["UseStartAndEndTime"] = r.UseStartAndEndTime;

                dv.Table.Rows.Add(newRow);
            }
            return dv;
        }

        public AlertConditionDataTable GetAlertConditionsDataTable(List<AlertCondition> conditions)
        {
            AlertConditionDataTable table = new AlertConditionDataTable();

            foreach (AlertCondition c in conditions)
            {
                AlertConditionRow newRow = table.NewAlertConditionRow();
                newRow["AlertConditionID"] = c.AlertConditionID;
                newRow["AlertID"] = c.AlertID;
                newRow["LeftSide"] = c.LeftSide;
                newRow["RightSide"] = c.RightSide;
                newRow["Operator"] = c.Operator;

                table.Rows.Add(newRow);
            }

            return table;
        }

        public DataView GetAlertConditionsView(List<AlertCondition> conditions)
        {
            DataView dv = new DataView();
            dv.Table = new DataTable("AlertConditions");
            dv.Table.Columns.Add("AlertID", typeof(Guid));
            dv.Table.Columns.Add("AlertConditionID", typeof(Guid));
            dv.Table.Columns.Add("LeftSide", typeof(string));
            dv.Table.Columns.Add("RightSide", typeof(string));
            dv.Table.Columns.Add("Operator", typeof(string));
            dv.Table.Columns.Add("InsertedDate", typeof(DateTime));

            foreach (AlertCondition c in conditions)
            {
                DataRow newRow = dv.Table.NewRow();
                newRow["AlertConditionID"] = c.AlertConditionID;
                newRow["AlertID"] = c.AlertID;
                newRow["LeftSide"] = c.LeftSide;
                newRow["RightSide"] = c.RightSide;
                newRow["Operator"] = c.Operator;
                newRow["InsertedDate"] = c.InsertedDate;

                dv.Table.Rows.Add(newRow);
            }

            return dv;
        }

        //public void SaveNewAlert()
        //{
        //    AlertTableAdapter ata = new AlertTableAdapter();
        //    AlertConditionTableAdapter acta = new AlertConditionTableAdapter();

        //    using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EsbExceptionDb"].ToString()))
        //    {
        //        ata.Connection = conn;
        //        acta.Connection = conn;
        //        using (TransactionScope trans = new TransactionScope())
        //        {
        //            try
        //            {
        //                conn.Open();
        //                ata.Update(this.Alert);                        
        //                acta.Update(this.AlertCondition);
        //                this.AcceptChanges();
        //                trans.Complete();
        //            }
        //            catch (Exception)
        //            {
        //                this.RejectChanges();
        //                throw;
        //            }

        //        }
        //    }
        //}

        //public void SaveAlertSubscription()
        //{
        //    AlertSubscriptionTableAdapter asta = new AlertSubscriptionTableAdapter();

        //    using(SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["EsbExceptionDb"].ToString())) 
        //    {
        //        asta.Connection = conn;

        //        using(TransactionScope trans = new TransactionScope()) {
        //            try {
        //                conn.Open();                
        //                asta.Update(this.AlertSubscription);                       
        //                this.AcceptChanges();
        //                trans.Complete();
        //            }
        //            catch {
        //                this.RejectChanges();
        //                throw;
        //            }
        //        }
        //    }
        //}



        internal AlertRow GetAlertRow(Alert alert)
        {
            AlertDataTable table = new AlertDataTable();
            AlertRow row = table.NewAlertRow();

            row["AlertID"] = alert.AlertID;
            row["ConditionsString"] = alert.ConditionsString;
            row["InsertedBy"] = alert.InsertedBy;
            row["InsertedDate"] = alert.InsertedDate;
            row["Name"] = alert.Name;

            return row;
        }
    }
}
