﻿namespace Microsoft.Practices.ESB.Portal.DataSets {
    
    
    public partial class Faults {
    }
}
