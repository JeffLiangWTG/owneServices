//---------------------------------------------------------------------
// File: FaultCountOverTimeByAppService.ascx.cs
// 
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using System.Web.UI.DataVisualization.Charting;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;
namespace Microsoft.Practices.ESB.Portal.Charts
{
    public partial class FaultCountOverTimeByAppService : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string application = Request.QueryString["esb:app"];

                if (!string.IsNullOrEmpty(application))
                {
                    DateTime stime = PortalHelper.GetUserStartDate(Context);
                    DateTime etime = DateTime.UtcNow;
                    DateTime barSTime = stime;
                    DateTime barETime = etime;
                    FilterDateRange UserFilterDateRange = PortalHelper.GetUserFilterDateRange(Context);
                    Debug.WriteLine("FaultCountOverTimeByApplication Services: " + UserFilterDateRange.ToString());
                    Debug.WriteLine("Dates: " + stime.ToString() + " = " + etime.ToString());
                    Series applicationSeries;

                    try
                    {
                        IExceptionService client = PortalHelper.GetExceptionService();

                        List<usp_select_Fault_Count_Over_Time_By_Application_ServiceNameResult> results = client.GetFaultCountOverTimeByApplicationServiceName(application, stime, etime);

                        ((IDisposable)client).Dispose();


                        string serviceT = "";
                        int index;
                        applicationSeries = this.Chart1.Series.Add("");
                        this.Chart1.Series.Clear();
                        foreach (var result in results)
                        {
                            if (serviceT != result.ServiceName)
                            {
                                serviceT = result.ServiceName;
                                applicationSeries.Sort(PointSortOrder.Ascending, "X");
                                applicationSeries = this.Chart1.Series.Add(serviceT);
                                applicationSeries.ChartType = SeriesChartType.StackedColumn;
                                applicationSeries.XValueType = ChartValueType.DateTime;
                            }
                            index = applicationSeries.Points.AddXY(PortalHelper.UTC_to_ClientLocalTime(result.DT), result.Total);
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    if (Chart1.Series.Count > 0)
                    {
                        Chart1.ChartAreas["Default"].AxisX.IntervalOffset = 0;
                        switch (UserFilterDateRange)
                        {
                            case FilterDateRange.All:
                                Chart1.DataManipulator.Group("SUM", 1, IntervalType.Years, 0, IntervalType.Years, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Years, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Years;
                                Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "yyyy";
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddYears(1).AddMilliseconds(-1);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Year:
                                Chart1.DataManipulator.Group("SUM", 3, IntervalType.Months, 0, IntervalType.Months, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(3, IntervalType.Months, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 3;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Months;
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddMonths(3).AddMilliseconds(-1);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Quarter:
                                Chart1.DataManipulator.Group("SUM", 1, IntervalType.Months, 0, IntervalType.Months, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Months, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Months;
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddMonths(1).AddMinutes(-1);

                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Month:
                                Chart1.DataManipulator.Group("SUM", 1, IntervalType.Days, 0, IntervalType.Days, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Days, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Days;
                                Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "MMM dd";
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddHours(23.9999);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Week:
                                Chart1.DataManipulator.Group("SUM", 1, IntervalType.Days, 0, IntervalType.Days, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Days, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Days;
                                Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "ddd";
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddHours(23.9999);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Day:
                                Chart1.DataManipulator.Group("SUM", 1, IntervalType.Hours, 0, IntervalType.Hours, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Hours, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Hours;
                                Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "hh:mm tt";
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddMinutes(59.9999);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Hour:
                                Chart1.DataManipulator.Group("SUM", 10, IntervalType.Minutes, 0, IntervalType.Minutes, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(10, IntervalType.Minutes, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 10;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Minutes;
                                Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "hh:mm tt";
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddMinutes(9.999);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                        }

                        foreach (Series s in Chart1.Series)
                        {
                            string link = string.Format("?esb:app={0}&esb:service={1}", application, Server.UrlEncode(s.Name));
                            s.LegendUrl = link;
                        }

                    }
                    //string st = Request.QueryString["esb:startDate"];
                    //string et = Request.QueryString["esb:endDate"];
                    //if (string.IsNullOrEmpty(st))


                    //    ObjectDataSource1.SelectParameters["StartDate"].DefaultValue = stime.ToString();
                    //else
                    //    ObjectDataSource1.SelectParameters["StartDate"].DefaultValue = DateTime.Parse(st).ToString();
                    //if (string.IsNullOrEmpty(et))

                    //    ObjectDataSource1.SelectParameters["EndDate"].DefaultValue = etime.ToString();
                    //else
                    //    ObjectDataSource1.SelectParameters["EndDate"].DefaultValue = DateTime.Parse(et).ToString();
                }

                Faults.DataSource = GetData();
                Faults.DataBind();
            }
        }

        void Faults_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView drv = e.Row.DataItem as DataRowView;

                e.Row.Attributes.Add("onclick", "javascript:document.location='FaultViewer.aspx?esb:FaultID=" + drv["FaultID"].ToString() + "'");
                e.Row.Attributes.Add("class", "GridRow");
                e.Row.Attributes.Add("title", "Click to view fault details");
            }
        }

        public string GetCrumbedString(object t, int crumbAt)
        {
            string text = t.ToString();
            if (text.Length > crumbAt)
            {
                return "<span title='" + text + "'>" + PortalHelper.CrumbString(text, crumbAt) + "</span>";
            }
            else
            {
                return text;
            }
        }

        public string GetSeverity(object severity)
        {
            int sever = int.Parse(severity.ToString());
            return "<img src='../" + PortalHelper.TranslateSeverityImages(sever) + "' style='vertical-align:middle;' /> <span class='" + PortalHelper.TranslateSeverityCssClass(sever) + "'>" + PortalHelper.TranslateSeverityText(sever) + "</span>";
        }

        public string GetDateRange(string value)
        {

            FilterDateRange filterDateRange;

            switch (value)
            {
                case "day":
                    filterDateRange = FilterDateRange.Day;
                    break;
                case "week":
                    filterDateRange = FilterDateRange.Week;
                    break;
                default:
                    filterDateRange = FilterDateRange.Hour;
                    break;
            }

            return PortalHelper.GetDateParamsQueryString(filterDateRange);
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridView gv = new GridView();
            gv.AllowPaging = false;
            gv.DataSource = GetData();
            gv.DataBind();
            gv.Dispose();

            GridViewExportUtil.ExcelExport(String.Format("FaultCountOver_{0}.xls", DateTime.Now.ToShortDateString()), gv);
        }

        protected void Faults_RowDataBound1(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                usp_select_Faults_By_Application_And_ServicesResult drv = e.Row.DataItem as usp_select_Faults_By_Application_And_ServicesResult;

                e.Row.Attributes.Add("onclick", "javascript:document.location='../Faults/FaultViewer.aspx?esb:FaultID=" + drv.FaultID.ToString() + "'");
                e.Row.Attributes.Add("class", "GridRow");
                e.Row.Attributes.Add("title", "Click to view fault details");
            }
        }

		private List<usp_select_Faults_By_Application_And_ServicesResult> GetData()
		{
			DateTime stime = PortalHelper.GetUserStartDate(Context);
			DateTime etime = DateTime.UtcNow;
			string application = Request.QueryString["esb:app"];
			string serviceName = Request.QueryString["esb:service"];
			IExceptionService client = null;

			try
			{
				client = PortalHelper.GetExceptionService();
				return client.GetFaultsByApplicationAndService(application, serviceName, stime, etime);
			}
			finally
			{
				if (client != null) ((IDisposable)client).Dispose();
			}
		}
    }
}
