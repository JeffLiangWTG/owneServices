<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="FaultCountByServices.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Charts.FaultCountByServices" Title="Untitled Page" %>

<%@ Register Src="FaultCountByServicesCtrl.ascx" TagName="FaultCountByServicesCtrl"
    TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <uc1:FaultCountByServicesCtrl ID="FaultCountByServicesCtrl1" runat="server" />
</asp:Content>
