//---------------------------------------------------------------------
// File: FaultCountByErrorType.ascx.cs
// 
// Summary: This chart shows the number of faults per error type in a 
//          pie format.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Web.UI.DataVisualization.Charting;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;
using System.ServiceModel;

namespace Microsoft.Practices.ESB.Portal.Graphs
{
    /// <summary>
    /// Base class for the FaultCountByErrorType control.
    /// </summary>
    public partial class FaultCountByErrorType : System.Web.UI.UserControl
    {

    
        /// <summary>
        /// Loads reportviewer and binds the dataset for the report.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            System.Collections.Generic.List<string> apps = PortalHelper.GetUserApplications(Context);

            string[] appsArry = apps.ToArray();
            string appsString = string.Join(",", appsArry);

            try
            {
                IExceptionService client = PortalHelper.GetExceptionService();

                List<ErrorFault> faults = client.GetFaultCountByErrorType(PortalHelper.GetUserStartDate(Context), DateTime.UtcNow, appsString);

                ((IDisposable)client).Dispose();

                Series series1 = this.Chart1.Series.Add("AA");
                series1.ChartType = SeriesChartType.Pie;
                series1.ChartArea = "Default";
                series1["CollectedThreshold"] = "0";
                series1["CollectedThresholdUsePercent"] = "true";
                series1["CollectedLegendText"] = "Other";
                series1["CollectedSliceExploded"] = "false";
                series1["CollectedColor"] = "Green";
                series1["CollectedToolTip"] = "Other";
                series1["PieDrawingStyle"] = "Concave";
                int index;
                foreach (ErrorFault ef in faults)
                {

                    index = series1.Points.AddY(ef.ErrorCount);
                    string link = string.Format("javascript:parent.redirect('../Reports/FaultCountByErrorTypeApp.aspx?esb:type={0}');", ef.ErrorType);
                    series1.Points[index].LegendText = ef.ErrorType;
                    series1.Points[index].ToolTip = ef.ErrorType;
                    series1.Points[index].LegendUrl = link;
                    series1.Points[index].Url = link;
                    series1["LineTension"] = "2";
                    series1.Points[index].BorderColor = System.Drawing.Color.LightGray;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        } 
    }
}