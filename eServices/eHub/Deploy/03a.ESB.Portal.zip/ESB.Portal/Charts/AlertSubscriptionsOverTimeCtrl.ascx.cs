//---------------------------------------------------------------------
// File: AlertSubscriptionsOverTimeCtrl.ascx.cs
// 
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using System.Web.UI.DataVisualization.Charting;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Practices.ESB.Portal.Charts
{
    public partial class AlertSubscriptionsOverTimeCtrl : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            this.Chart1.Series.Clear();
            DateTime stime = PortalHelper.GetUserStartDate(Context);
            DateTime etime = DateTime.UtcNow;
            FilterDateRange UserFilterDateRange = PortalHelper.GetUserFilterDateRange(Context);
            Debug.WriteLine( "AlertSubscriptionsOverTimeCtrl: " + UserFilterDateRange.ToString());
            Debug.WriteLine("Dates: " + stime.ToString() + " = " + etime.ToString());
            StringBuilder sb = new StringBuilder();
            string appSeries = "";
            Series applicationSeries;
            foreach (string application in PortalHelper.GetUserApplications(this.Context))
            {
                try
                {
                    IExceptionService client = PortalHelper.GetExceptionService();

                    List<usp_select_AlertSubscription_Count_Over_Time_By_ApplicationResult> results = client.GetAlertSubscriptionCountOverTimeByApplication(application, stime, etime);

                    ((IDisposable)client).Dispose();

                    int count = results.Count;

                    Debug.WriteLine("Application:" + application + "  Rows count:" + count.ToString());

                    if (count > 0)
                    {
                        sb.Append(application + ",");
                        applicationSeries = this.Chart1.Series.Add(application);
                        applicationSeries.ChartType = SeriesChartType.StackedColumn;
                        applicationSeries.XValueType = ChartValueType.DateTime;

                        foreach (var result in results)
                        {
                            int index;
                            Debug.WriteLine("X:" + PortalHelper.UTC_to_ClientLocalTime(result.DT).ToString() + "  Y:" + result.Total.ToString());
                            index = applicationSeries.Points.AddXY(PortalHelper.UTC_to_ClientLocalTime(result.DT), result.Total);
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            appSeries = sb.ToString();

            if (appSeries.Length > 1)
            {
                appSeries = appSeries.Substring(0, appSeries.Length - 1);
                switch (UserFilterDateRange)
                {
                    case FilterDateRange.Year:
                    case FilterDateRange.All:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Months, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Months, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Months;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "MMM yy";
                        break;

                    case FilterDateRange.Quarter:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Months, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Months, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Months;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "MMM yy";
                        break;
                    case FilterDateRange.Month:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Days,0,IntervalType.Days , appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Days, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                        Chart1.ChartAreas["Default"].AxisX.IntervalOffset = 0;

                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Days;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "MMM dd";
                        break;
                    case FilterDateRange.Week:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Days, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Days, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Days;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "ddd";
                        break;
                    case FilterDateRange.Day:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Hours, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Hours, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Hours;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "hh:mm tt";
                        break;
                    case FilterDateRange.Hour:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Minutes, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Minutes, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Minutes;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "hh:mm tt";
                        break;
                }
                foreach (Series s in Chart1.Series)
                {
                    string link = string.Format("javascript:parent.redirect('../Reports/AlertSubOverTimeService.aspx?esb:app={0}');", Server.UrlEncode(s.Name));
                    s.Url = link;
                    s.LegendUrl = link;
                }
            }



        }

        //        protected void Page_Load(object sender, EventArgs e)
        //        {
        //            System.Collections.Generic.List<string> userApps = PortalHelper.GetUserApplications(this.Context);

        //            foreach (string application in PortalHelper.GetUserApplications(this.Context))
        //            {
        //                using (DataSets.ReportsAlertSubscriptionsOverTimeTableAdapters.usp_select_Reports_AlertHistoryOverTimeTableAdapter da = new Microsoft.Practices.ESB.Portal.DataSets.ReportsAlertSubscriptionsOverTimeTableAdapters.usp_select_Reports_AlertHistoryOverTimeTableAdapter())
        //                {
        //                    DataSets.ReportsAlertSubscriptionsOverTime.usp_select_Reports_AlertHistoryOverTimeDataTable dt = new Microsoft.Practices.ESB.Portal.DataSets.ReportsAlertSubscriptionsOverTime.usp_select_Reports_AlertHistoryOverTimeDataTable();
        //                    da.Fill(dt, PortalHelper.GetUserStartDate(Context).ToShortDateString(), DateTime.Now.ToShortDateString(), false);
        //                    Dundas.Charting.WebControl.Series applicationSeries;
        //                    if (dt.Rows.Count > 0)
        //                    {
        ////                        Dundas.Charting.WebControl.Series applicationSeries;
        //                        applicationSeries = this.Chart1.Series.Add(application);
        //                        applicationSeries.Type = Dundas.Charting.WebControl.SeriesChartType.Line;

        //                        switch (PortalHelper.GetUserFilterDateRange(Context))
        //                        {
        //                            case FilterDateRange.Hour:
        //                                applicationSeries.XValueType = Dundas.Charting.WebControl.ChartValueTypes.DateTime;

        //                                break;
        //                            case FilterDateRange.Day:
        //                                applicationSeries.XValueType = Dundas.Charting.WebControl.ChartValueTypes.Time;
        //                                break;
        //                            case FilterDateRange.Week:
        //                                applicationSeries.XValueType = Dundas.Charting.WebControl.ChartValueTypes.DateTime;
        //                                break;
        //                            case FilterDateRange.Month:
        //                                applicationSeries.XValueType = Dundas.Charting.WebControl.ChartValueTypes.DateTime;
        //                                break;
        //                            case FilterDateRange.Quarter:
        //                                applicationSeries.XValueType = Dundas.Charting.WebControl.ChartValueTypes.DateTime;
        //                                break;
        //                            case FilterDateRange.Year:
        //                                applicationSeries.XValueType = Dundas.Charting.WebControl.ChartValueTypes.DateTime;
        //                                break;
        //                            case FilterDateRange.All:
        //                                applicationSeries.XValueType = Dundas.Charting.WebControl.ChartValueTypes.DateTime;
        //                                break;

        //                        }

        //                        int index = applicationSeries.Points.AddXY(PortalHelper.GetUserStartDate(Context), 0);

        //                        foreach (DataRow dr in dt.Rows)
        //                        {


        //                            applicationSeries = this.Chart1.Series[application];

        ////                            DateTime dateTime = new DateTime();

        //                            DateTime dateTime=       DateTime.Parse(dr["AlertDate"].ToString()); 

        //                            //switch (PortalHelper.GetUserFilterDateRange(Context))
        //                            //{
        //                            //    case FilterDateRange.Hour:
        //                            //        dateTime = new DateTime((int)dr["Year"], (int)dr["Month"], (int)dr["Day"], (int)dr["Hour"], (int)dr["Minute"], 0);

        //                            //        break;
        //                            //    case FilterDateRange.Day:
        //                            //        dateTime = new DateTime((int)dr["Year"], (int)dr["Month"], (int)dr["Day"], (int)dr["Hour"], 0, 0);
        //                            //        break;
        //                            //    case FilterDateRange.Week:
        //                            //        dateTime = new DateTime((int)dr["Year"], (int)dr["Month"], (int)dr["Day"]);
        //                            //        break;
        //                            //    case FilterDateRange.Month:
        //                            //        dateTime = new DateTime((int)dr["Year"], (int)dr["Month"], 1);
        //                            //        break;
        //                            //    case FilterDateRange.Quarter:

        //                            //        dateTime = new DateTime((int)dr["Year"], (int)dr["Month"], 1);
        //                            //        break;
        //                            //    case FilterDateRange.Year:
        //                            //        dateTime = new DateTime((int)dr["Year"], (int)dr["Month"], 1);
        //                            //        break;
        //                            //    case FilterDateRange.All:
        //                            //        dateTime = new DateTime((int)dr["Year"], (int)dr["Month"], 1);
        //                            //        break;

        //                            //}

        //                            index = applicationSeries.Points.AddXY(dateTime, (int)dr[1]);
        //                            string link = string.Format("javascript:parent.redirect('../Faults/Faults.aspx?esb:app={0}');", Server.UrlEncode(application));

        //                            applicationSeries.Points[index].LegendText = application;
        //                            applicationSeries.Points[index].LabelHref = link;
        //                            applicationSeries.Points[index].LegendHref = link;
        //                            applicationSeries.Points[index].Href = link;
        //                            applicationSeries.Points[index].ToolTip = application;
        //                        }
        //                    }
        //                }
        //            }
        // }
    }
}