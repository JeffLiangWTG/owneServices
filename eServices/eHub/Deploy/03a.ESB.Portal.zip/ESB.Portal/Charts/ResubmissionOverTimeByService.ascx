<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="ResubmissionOverTimeByService.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Charts.ResubmissionOverTimeByService" %>
<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers"
    TagPrefix="cc1" %>

<script language="javascript" src="../Script/Scripts.js"></script>
<script language="javascript">

		function redirect(url)
		{
			document.location = url;
		}
	</script>


<center>
<DCWC:Chart ID="Chart1" runat="server" BackColor="#DEE6F0" BackGradientEndColor="White"
	ImageType="Jpeg" BackGradientType="TopBottom" BorderLineStyle="Solid" BorderLineColor="64, 0, 0, 0"
	BorderLineWidth="4" Palette="Excel"
	Width="707px">
	
	<Legends>
        <DCWC:Legend Name="Default">
        </DCWC:Legend>

		<DCWC:Legend  BackColor="White" BorderColor="26, 59, 105" Font="Trebuchet MS, 8.25pt"
			Name="Pastel" ShadowOffset="2">
		</DCWC:Legend>
	</Legends>
	<BorderSkin  BackColor="PeachPuff"  BackSecondaryColor="DodgerBlue" SkinStyle="Emboss">
	</BorderSkin>
	<ChartAreas>
		<DCWC:ChartArea Name="Default" BorderColor="DimGray"  BorderDashStyle="Solid" BackColor="255, 254, 251">
	<AxisX >
				<MinorGrid LineColor="Silver" />
				<MajorTickMark TickMarkStyle="none" />
				<MajorGrid Enabled="False" LineColor="Silver" />
			</AxisX>
			<Area3DStyle LightStyle="Realistic" />
			<AxisY>
				<MinorGrid LineColor="Silver" />
				<MajorGrid LineColor="Silver" />
			</AxisY>
			<AxisX2>
				<MinorGrid LineColor="Silver" />
				<MajorGrid LineColor="Silver" />
			</AxisX2>
			<AxisY2>
				<MinorGrid LineColor="Silver" />
				<MajorGrid LineColor="Silver" />
			</AxisY2>
		</DCWC:ChartArea>
	</ChartAreas>
	<Titles>
		<DCWC:Title Font="Trebuchet MS, 12pt, style=Bold" Name="Title1" Text="Resubmissions Over Time">
		</DCWC:Title>
	</Titles>
</DCWC:Chart>
</center>
<br />
<br />
<%--<asp:ObjectDataSource id="AuditLogDataSource" runat="server" TypeName="Microsoft.Practices.ESB.Portal.DataSets.ReportsResubmissionsOverTimeByAppTableAdapters.usp_select_Reports_ResubmissionsByServiceTableAdapter" SelectMethod="GetData" OldValuesParameterFormatString="original_{0}"><SelectParameters>
<asp:QueryStringParameter Type="String" Name="Application" QueryStringField="esb:app"></asp:QueryStringParameter>
<asp:QueryStringParameter Type="String" DefaultValue="" Name="ServiceName" QueryStringField="esb:service"></asp:QueryStringParameter>
<asp:Parameter Type="DateTime" DefaultValue="" Name="StartDate"></asp:Parameter>
<asp:Parameter Type="DateTime" Name="EndDate"></asp:Parameter>
<asp:Parameter Type="Boolean" DefaultValue="false" Name="Debug"></asp:Parameter>
</SelectParameters>
</asp:ObjectDataSource>--%>
&nbsp;
<asp:Image ID="Image1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
<asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton><br />
<asp:GridView id="GridView1" Width="100%" runat="server" PageSize="25" BorderWidth="0px" CssClass="FaultViewer" AutoGenerateColumns="False" AllowSorting="True" AllowPaging="True" OnRowDataBound="GridView1_RowDataBound" OnSelectedIndexChanged="GridView1_SelectedIndexChanged"><Columns>
<asp:BoundField DataField="ActionName" SortExpression="ActionName" HeaderText="Action"></asp:BoundField>
<asp:TemplateField SortExpression="MessageID" HeaderText="MessageID"><ItemTemplate>
            <%# (string)DataBinder.Eval(Container.DataItem, "ActionName") == "SuccessfulResubmit" ? "<a href='../Faults/MessageViewer.aspx?esb:MessageID=" + DataBinder.Eval(Container.DataItem, "MessageID") + "&esb:ActionName=SuccessfulResubmit'>" + DataBinder.Eval(Container.DataItem, "MessageID") + "</a>" : DataBinder.Eval(Container.DataItem, "MessageID")%>
         
</ItemTemplate>
</asp:TemplateField>
<asp:TemplateField SortExpression="ResubmitCode" HeaderText="Result"><ItemTemplate>
               <%#DataBinder.Eval(Container.DataItem, "ResubmitCode") + " - " + DataBinder.Eval(Container.DataItem, "ResubmitMessage") %>
            
</ItemTemplate>
</asp:TemplateField>
<asp:TemplateField SortExpression="AuditDate" HeaderText="Date">
<ItemStyle HorizontalAlign="Left"></ItemStyle>
<ItemTemplate>
<%# Microsoft.Practices.ESB.Portal.PortalHelper.UTC_to_ClientLocalTime(DataBinder.Eval(Container.DataItem, "AuditDate")).ToString()%>
            
</ItemTemplate>
</asp:TemplateField>
<asp:BoundField DataField="AuditUserName" SortExpression="AuditUserName" HeaderText="User Name"></asp:BoundField>
</Columns>

<RowStyle CssClass="tableRow"></RowStyle>

<HeaderStyle CssClass="tableHeader"></HeaderStyle>
</asp:GridView>
<cc1:GridViewSortExtender ID="GridViewSortExtender1" runat="server" AscendingImageUrl="~/Images/asc_order.gif"
    DescendingImageUrl="~/Images/desc_order.gif" ExtendeeID="GridView1">
</cc1:GridViewSortExtender>
