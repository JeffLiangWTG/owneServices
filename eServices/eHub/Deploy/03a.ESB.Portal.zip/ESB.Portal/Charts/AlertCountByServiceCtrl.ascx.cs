//---------------------------------------------------------------------
// File: AlertCountByServiceCtrl.ascx.cs
// 
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.UI.DataVisualization.Charting;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal.Charts
{
    public partial class AlertCountByServiceCtrl : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string application = Request.QueryString["esb:app"];
            if (!string.IsNullOrEmpty(application))
            {
                DateTime stime = PortalHelper.GetUserStartDate(Context);
                DateTime etime = DateTime.UtcNow;
                try
                {
                    IExceptionService client = PortalHelper.GetExceptionService();

                    List<usp_select_AlertHistoryReportByServiceResult> results = client.GetAlertHistoryReportByService(application, stime, etime);

                    ((IDisposable)client).Dispose();


                    foreach (usp_select_AlertHistoryReportByServiceResult result in results)
                    {

                        Series s = Chart1.Series.Add(result.ServiceName);
                        s.BackGradientStyle = GradientStyle.TopBottom;
                        s.BorderColor = System.Drawing.Color.LightGray;
                        s["DrawingStyle"] = "Cylinder";
                        int index = s.Points.AddY(result.Total);
                        s.Points[index].LegendText = result.ServiceName;

                        s.Points[index].LegendUrl = "javascript:redirect('?esb:app=" + Server.UrlEncode(application) + "&esb:service=" + result.ServiceName + "');";
                        s.Points[index].Url = "javascript:redirect('?esb:app=" + Server.UrlEncode(application) + "&esb:service=" + result.ServiceName + "');";
                        s.Points[index].ToolTip = application;

                    }

					//ObjectDataSource1.SelectParameters["BeginDate"].DefaultValue = stime.ToString();
					//ObjectDataSource1.SelectParameters["EndDate"].DefaultValue = etime.ToString();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        void Faults_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView drv = e.Row.DataItem as DataRowView;

                e.Row.Attributes.Add("onclick", "javascript:document.location='FaultViewer.aspx?esb:FaultID=" + drv["FaultID"].ToString() + "'");
                e.Row.Attributes.Add("class", "GridRow");
                e.Row.Attributes.Add("title", "Click to view fault details");
            }
        }

        public string GetCrumbedString(object t, int crumbAt)
        {
            string text = t.ToString();
            if (text.Length > crumbAt)
            {
                return "<span title='" + text + "'>" + PortalHelper.CrumbString(text, crumbAt) + "</span>";
            }
            else
            {
                return text;
            }
        }

        public string GetSeverity(object severity)
        {
            int sever = int.Parse(severity.ToString());
            return "<img src='../" + PortalHelper.TranslateSeverityImages(sever) + "' style='vertical-align:middle;' /> <span class='" + PortalHelper.TranslateSeverityCssClass(sever) + "'>" + PortalHelper.TranslateSeverityText(sever) + "</span>";
        }

        public string GetDateRange(string value)
        {

            FilterDateRange filterDateRange;

            switch (value)
            {
                case "day":
                    filterDateRange = FilterDateRange.Day;
                    break;
                case "week":
                    filterDateRange = FilterDateRange.Week;
                    break;
                default:
                    filterDateRange = FilterDateRange.Hour;
                    break;
            }

            return PortalHelper.GetDateParamsQueryString(filterDateRange);
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridView gv = new GridView();
            gv.AllowPaging = false;
			gv.DataSource = GetData();
            gv.DataBind();
            gv.Dispose();

            GridViewExportUtil.ExcelExport(String.Format("FaultCount_{0}.xls", DateTime.Now.ToShortDateString()), gv);
        }

		private List<usp_select_Faults_By_Application_And_ServicesResult> GetData()
		{
			DateTime stime = PortalHelper.GetUserStartDate(Context);
			DateTime etime = DateTime.UtcNow;
			string application = Request.QueryString["esb:app"];
			string serviceName = Request.QueryString["esb:service"];
			IExceptionService client = null;

			try
			{
				client = PortalHelper.GetExceptionService();
				return client.GetFaultsByApplicationAndService(application, serviceName, stime, etime);
			}
			finally
			{
				if (client != null) ((IDisposable)client).Dispose();
			}
		}

        protected void Faults_RowDataBound1(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView drv = e.Row.DataItem as DataRowView;

                e.Row.Attributes.Add("onclick", "javascript:document.location='../Faults/FaultViewer.aspx?esb:FaultID=" + drv["FaultID"].ToString() + "'");
                e.Row.Attributes.Add("class", "GridRow");
                e.Row.Attributes.Add("title", "Click to view fault details");
            }
        }
    }
}