<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="AlertCountByServiceCtrl.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Charts.AlertCountByServiceCtrl" %>
<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers"
    TagPrefix="cc1" %>
<%@ Register Src="../Lists/AlertListSample.ascx" TagName="AlertListSample" TagPrefix="uc1" %>

	<script language="javascript">

		function redirect(url)
		{
			document.location = url;
		}
	</script>
<!-- No HTML UI -->
<center>


<DCWC:Chart ID="Chart1" runat="server" BackColor="#DEE6F0" BackSecondaryColor="White"
	ImageType="Jpeg" BackGradientStyle="TopBottom" BorderlineDashStyle="Solid" BorderLineColor="64, 0, 0, 0"
	BorderLineWidth="4" Palette="Excel"
	Width="954px">
	
	<Legends>
		<DCWC:Legend Name="Default">
		</DCWC:Legend>
		<DCWC:Legend  BackColor="White" BorderColor="26, 59, 105" Font="Trebuchet MS, 8.25pt"
			Name="Pastel" ShadowOffset="2">
		</DCWC:Legend>
	</Legends>
	<BorderSkin BackColor="PeachPuff" BackSecondaryColor="DodgerBlue" SkinStyle="Emboss">
	</BorderSkin>
	<ChartAreas>
		<DCWC:ChartArea Name="Default" BorderColor="DimGray" BorderDashStyle="Solid" BackColor="255, 254, 251">
			<AxisY LineColor="DimGray" LabelAutoFitStyle="None">
				<LabelStyle Font="Trebuchet MS, 8.25pt" Format="#"></LabelStyle>
				<MajorGrid LineDashStyle="Dot" LineColor="DimGray"></MajorGrid>
			</AxisY>
			<AxisX Enabled="False" />
			<Area3DStyle Enable3D="True" />
		</DCWC:ChartArea>
	</ChartAreas>
	<Titles>
		<DCWC:Title Font="Trebuchet MS, 12pt, style=Bold" Name="Title1" Text="Alert Count By Services">
		</DCWC:Title>
	</Titles>
</DCWC:Chart>
</center> 

&nbsp;<br />
<br />
<%--<asp:ObjectDataSource ID="ObjectDataSource1" runat="server" OldValuesParameterFormatString="original_{0}"
    SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.AlertsSentByApplicationTableAdapters.usp_select_AlertHistoryReportByServiceFaultTableAdapter">
    <SelectParameters>
        <asp:QueryStringParameter Name="ApplicationName" QueryStringField="esb:app" Type="String" />
        <asp:QueryStringParameter Name="ServiceName" QueryStringField="esb:service" Type="String" />
        <asp:Parameter Name="BeginDate" Type="DateTime" />
        <asp:Parameter Name="EndDate" Type="DateTime" />
    </SelectParameters>
</asp:ObjectDataSource>--%>
<asp:Image ID="Image1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
<asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton><br />

<asp:GridView ID="Faults" runat="server" AllowPaging="True" AllowSorting="True" AutoGenerateColumns="False"
    BorderWidth="0px" DataKeyNames="FaultID" 
    PageSize="25" Width="100%" OnRowDataBound="Faults_RowDataBound1">
    <HeaderStyle CssClass="tableHeader" />
    <RowStyle CssClass="tableRow" />
    <Columns>
        <asp:TemplateField HeaderText="Severity" SortExpression="FaultSeverity">
            <ItemTemplate>
                <%# GetSeverity(DataBinder.Eval(Container.DataItem, "FaultSeverity"))  %>
            </ItemTemplate>
            <ItemStyle Wrap="False" />
        </asp:TemplateField>
        <asp:TemplateField HeaderText="Date" SortExpression="DateTime">
            <ItemTemplate>
                <%# Microsoft.Practices.ESB.Portal.PortalHelper.UTC_to_ClientLocalTime(DataBinder.Eval(Container.DataItem, "DateTime")).ToString() %>
            </ItemTemplate>
            <HeaderStyle HorizontalAlign="Center" />
            <ItemStyle Wrap="False" />
        </asp:TemplateField>
        <asp:BoundField DataField="FaultCode" HeaderText="Code" SortExpression="FaultCode" />
        <asp:BoundField DataField="FailureCategory" HeaderText="Category" SortExpression="FailureCategory" />
        <asp:BoundField DataField="Application" HeaderText="Application" SortExpression="Application" />
        <asp:TemplateField HeaderText="Error Type" SortExpression="ErrorType">
            <ItemTemplate>
                <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "ErrorType"), 25)%>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:TemplateField HeaderText="Scope" SortExpression="Scope">
            <ItemTemplate>
                <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "Scope"), 18)%>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:TemplateField HeaderText="Service Name" SortExpression="ServiceName">
            <ItemTemplate>
                <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "ServiceName"), 25)%>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:BoundField DataField="FaultGenerator" HeaderText="Fault Generator" SortExpression="FaultGenerator" />
        <asp:BoundField DataField="MachineName" HeaderText="Machine Name" SortExpression="MachineName" />
    </Columns>
</asp:GridView>


<cc1:GridViewSortExtender ID="GridViewSortExtender2" runat="server" ExtendeeID="Faults" AscendingImageUrl="~/Images/asc_order.gif"
    DescendingImageUrl="~/Images/desc_order.gif">
</cc1:GridViewSortExtender>
