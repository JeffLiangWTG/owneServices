<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ResubmissionsOverTimeByApp.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Charts.ResubmissionsOverTimeByApp1" %>
<%@ Register Src="~/Charts/ResubmissionsOverTimeByAppCtrl.ascx" TagName="Resubmissions" TagPrefix="uc1" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
</head>
<body>
    <form id="form1" runat="server">
    <div>
		<uc1:Resubmissions ID="Resubmissions1" runat="server" />
    </div>
    </form>
</body>
</html>
