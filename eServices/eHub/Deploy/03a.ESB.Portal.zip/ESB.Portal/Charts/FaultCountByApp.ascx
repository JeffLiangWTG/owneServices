<%@ Control Language="C#" AutoEventWireup="true" Codebehind="FaultCountByApp.ascx.cs"
	Inherits="Microsoft.Practices.ESB.Portal.FaultCountByApp" %>


<!-- No HTML UI -->

<DCWC:Chart ID="Chart1" runat="server" BackColor="#DEE6F0" BackGradientEndColor="White"
	ImageType="Jpeg" BackGradientType="TopBottom" BorderLineStyle="Solid" BorderLineColor="64, 0, 0, 0"
	BorderLineWidth="4" Palette="Excel"
	Width="390px">
	
	<Legends>
		<DCWC:Legend Name="Default">
		</DCWC:Legend>
		<DCWC:Legend  BackColor="White" BorderColor="26, 59, 105" Font="Trebuchet MS, 8.25pt"
			Name="Pastel" ShadowOffset="2">
		</DCWC:Legend>
	</Legends>
	<BorderSkin  BackColor="PeachPuff" BackSecondaryColor="DodgerBlue" SkinStyle="Emboss">
	</BorderSkin>
	<ChartAreas>
		<DCWC:ChartArea Name="Default" BorderColor="DimGray" BorderDashStyle="Solid" BackColor="255, 254, 251">
			<AxisY LineColor="DimGray" LabelAutoFitStyle="None">
				<LabelStyle Font="Trebuchet MS, 8.25pt" Format="#"></LabelStyle>
				<MajorGrid LineDashStyle="Dot" LineColor="DimGray"></MajorGrid>
			</AxisY>
			<AxisX Enabled="False" />
			<Area3DStyle Enable3D="True" />
		</DCWC:ChartArea>
	</ChartAreas>
	<Titles>
		<DCWC:Title Font="Trebuchet MS, 12pt, style=Bold" Name="Title1" Text="Fault Count By Application">
		</DCWC:Title>
	</Titles>
	<Series>
	</Series>
</DCWC:Chart>
