//---------------------------------------------------------------------
// File: FaultCountByErrorTypeApp.ascx.cs
// 
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.UI.DataVisualization.Charting;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;
namespace Microsoft.Practices.ESB.Portal.Charts
{
    public partial class FaultCountByErrorTypeApp : System.Web.UI.UserControl
    {
        private List<usp_select_Faults_By_Application_And_ErrorTypeResult> GetData()
        {
            DateTime stime = PortalHelper.GetUserStartDate(Context);
            DateTime etime = DateTime.UtcNow;
            string application = Request.QueryString["esb:app"];
            string errorType = Request.QueryString["esb:errorType"];
			IExceptionService client = null;

            try
            {
                client = PortalHelper.GetExceptionService();
                return client.GetFaultsByApplicationAndErrorType(application, errorType, stime, etime);
            }
			finally
			{
				if (client != null) ((IDisposable)client).Dispose();
			}
		}

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string ErrorType = Request.QueryString["esb:type"];
                System.Collections.Generic.List<string> apps = PortalHelper.GetUserApplications(Context);

                string[] appsArry = apps.ToArray();

                string appsString = string.Join(",", appsArry);

                try
                {
                    IExceptionService client = PortalHelper.GetExceptionService();

                    List<ErrorFault> results = client.GetFaultCountByErrorTypeByApplication(ErrorType, appsString, PortalHelper.GetUserStartDate(Context), DateTime.UtcNow);

                    ((IDisposable)client).Dispose();

                    Series series1 = this.Chart1.Series.Add("AA");
                    series1.ChartType = SeriesChartType.Pie;
                    series1.ChartArea = "Default";
                    series1["CollectedThreshold"] = "0";
                    series1["CollectedThresholdUsePercent"] = "true";
                    series1["CollectedLegendText"] = "Other";
                    series1["CollectedSliceExploded"] = "false";
                    series1["CollectedColor"] = "Green";
                    series1["CollectedToolTip"] = "Other";
                    series1["PieDrawingStyle"] = "Concave";
                    int index;
                    foreach (var result in results)
                    {
                        index = series1.Points.AddY(result.ErrorCount);
                        string link = string.Format("javascript:parent.redirect('../Reports/FaultCountByErrorTypeApp.aspx?esb:type={0}&esb:app={1}');", ErrorType, result.Application);
                        series1.Points[index].LegendText = result.Application;
                        series1.Points[index].ToolTip = result.Application;
                        series1.Points[index].LegendUrl = link;
                        series1.Points[index].Url = link;
                        series1["LineTension"] = "2";
                        series1.Points[index].BorderColor = System.Drawing.Color.LightGray;
                    }

                    //ObjectDataSource1.SelectParameters["StartDate"].DefaultValue = PortalHelper.GetUserStartDate(Context).ToString();
                    //ObjectDataSource1.SelectParameters["EndDate"].DefaultValue = DateTime.UtcNow.ToString();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                Faults.DataSource = GetData();
                Faults.DataBind();
            }
        }

        void Faults_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView drv = e.Row.DataItem as DataRowView;

                e.Row.Attributes.Add("onclick", "javascript:document.location='FaultViewer.aspx?esb:FaultID=" + drv["FaultID"].ToString() + "'");
                e.Row.Attributes.Add("class", "GridRow");
                e.Row.Attributes.Add("title", "Click to view fault details");
            }
        }

        public string GetCrumbedString(object t, int crumbAt)
        {
            string text = t.ToString();
            if (text.Length > crumbAt)
            {
                return "<span title='" + text + "'>" + PortalHelper.CrumbString(text, crumbAt) + "</span>";
            }
            else
            {
                return text;
            }
        }

        public string GetSeverity(object severity)
        {
            int sever = int.Parse(severity.ToString());
            return "<img src='../" + PortalHelper.TranslateSeverityImages(sever) + "' style='vertical-align:middle;' /> <span class='" + PortalHelper.TranslateSeverityCssClass(sever) + "'>" + PortalHelper.TranslateSeverityText(sever) + "</span>";
        }

        public string GetDateRange(string value)
        {

            FilterDateRange filterDateRange;

            switch (value)
            {
                case "day":
                    filterDateRange = FilterDateRange.Day;
                    break;
                case "week":
                    filterDateRange = FilterDateRange.Week;
                    break;
                default:
                    filterDateRange = FilterDateRange.Hour;
                    break;
            }

            return PortalHelper.GetDateParamsQueryString(filterDateRange);
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridView gv = new GridView();
            gv.AllowPaging = false;
            gv.DataSource = GetData(); 
            gv.DataBind();
            gv.Dispose();

            GridViewExportUtil.ExcelExport(String.Format("FaultCount_{0}.xls", DateTime.Now.ToShortDateString()), gv);
        }

        protected void Faults_RowDataBound1(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView drv = e.Row.DataItem as DataRowView;

                e.Row.Attributes.Add("onclick", "javascript:document.location='../Faults/FaultViewer.aspx?esb:FaultID=" + drv["FaultID"].ToString() + "'");
                e.Row.Attributes.Add("class", "GridRow");
                e.Row.Attributes.Add("title", "Click to view fault details");
            }
        }
    }
}