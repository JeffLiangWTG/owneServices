//---------------------------------------------------------------------
// File: ResubmissionOverTimeByService.ascx.cs
// 
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using System.Web.UI.DataVisualization.Charting;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Practices.ESB.Portal.Charts
{
    public partial class ResubmissionOverTimeByService : System.Web.UI.UserControl
    {
        private List<usp_select_Reports_ResubmissionsByServiceResult> GetData()
        {
            DateTime stime = PortalHelper.GetUserStartDate(Context);
            DateTime etime = DateTime.UtcNow;
            string application = Request.QueryString["esb:app"];
            string serviceName = Request.QueryString["esb:service"];
			IExceptionService client = null;

            try
            {
                client = PortalHelper.GetExceptionService();
                return client.GetReportsResubmissionsByService(application, serviceName, stime, etime);
            }
			finally
			{
				if (client != null) ((IDisposable)client).Dispose();
			}
		}

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string application = Request.QueryString["esb:app"];

                if (!string.IsNullOrEmpty(application))
                {
                    DateTime stime = PortalHelper.GetUserStartDate(Context);
                    DateTime etime = DateTime.UtcNow;
                    DateTime barSTime = stime;
                    DateTime barETime = etime;
                    FilterDateRange UserFilterDateRange = PortalHelper.GetUserFilterDateRange(Context);
                    Debug.WriteLine("ResubmissionOverTimeByService: " + UserFilterDateRange.ToString());
                    Debug.WriteLine("Dates: " + stime.ToString() + " = " + etime.ToString());
                    Series applicationSeries;

                    try
                    {
                        IExceptionService client = PortalHelper.GetExceptionService();

                        List<usp_select_Resubmission_Count_Over_Time_By_Application_ServiceNameResult> results = client.GetResubmissionCountOverTimeByApplicationServiceName(application, stime, etime);

                        ((IDisposable)client).Dispose();

                        string serviceT = "";
                        int index;
                        applicationSeries = this.Chart1.Series.Add("");
                        this.Chart1.Series.Clear();
                        foreach (var result in results)
                        {
                            if (serviceT != (string.IsNullOrEmpty(result.ServiceName) ? "Null" : result.ServiceName))
                            {
                                serviceT = (string.IsNullOrEmpty(result.ServiceName) ? "Null" : result.ServiceName);
                                applicationSeries.Sort(PointSortOrder.Ascending, "X");
                                applicationSeries = this.Chart1.Series.Add(serviceT);
                                applicationSeries.ChartType = SeriesChartType.StackedColumn;
                                applicationSeries.XValueType = ChartValueType.DateTime;
                            }
                            index = applicationSeries.Points.AddXY(PortalHelper.UTC_to_ClientLocalTime(result.DT), result.Total);
                        }

                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    if (Chart1.Series.Count > 0)
                    {
                        Chart1.ChartAreas["Default"].AxisX.IntervalOffset = 0;
                        switch (UserFilterDateRange)
                        {
                            case FilterDateRange.All:
                                Chart1.DataManipulator.Group("SUM", 1, IntervalType.Years, 0, IntervalType.Years, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Years, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Years;
                                Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "yyyy";
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddYears(1).AddMilliseconds(-1);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Year:
                                Chart1.DataManipulator.Group("SUM", 3, IntervalType.Months, 0, IntervalType.Months, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(3, IntervalType.Months, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 3;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Months;
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddMonths(3).AddMilliseconds(-1);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Quarter:
                                Chart1.DataManipulator.Group("SUM", 1, IntervalType.Months, 0, IntervalType.Months, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Months, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Months;
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddMonths(1).AddMinutes(-1);

                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Month:
                                Chart1.DataManipulator.Group("SUM", 1, IntervalType.Days, 0, IntervalType.Days, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Days, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Days;
                                Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "MMM dd";
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddHours(23.9999);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Week:
                                Chart1.DataManipulator.Group("SUM", 1, IntervalType.Days, 0, IntervalType.Days, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Days, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Days;
                                Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "ddd";
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddHours(23.9999);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Day:
                                Chart1.DataManipulator.Group("SUM", 1, IntervalType.Hours, 0, IntervalType.Hours, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Hours, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Hours;
                                Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "hh:mm tt";
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddMinutes(59.9999);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                            case FilterDateRange.Hour:
                                Chart1.DataManipulator.Group("SUM", 10, IntervalType.Minutes, 0, IntervalType.Minutes, "*");
                                Chart1.DataManipulator.InsertEmptyPoints(10, IntervalType.Minutes, "*");
                                Chart1.ChartAreas["Default"].AxisX.Interval = 10;
                                Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Minutes;
                                Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "hh:mm tt";
                                foreach (Series s in Chart1.Series)
                                {
                                    foreach (DataPoint p in s.Points)
                                    {
                                        barSTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                                        barETime = barSTime.AddMinutes(9.999);
                                        string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, Server.UrlEncode(s.Name), barSTime.ToString(), barETime.ToString());
                                        p.Url = link2;
                                    }
                                }
                                break;
                        }

                        foreach (Series s in Chart1.Series)
                        {
                            string link = string.Format("?esb:app={0}&esb:service={1}", application, Server.UrlEncode(s.Name));
                            s.LegendUrl = link;
                        }

                    }

                    //string st = Request.QueryString["esb:startDate"];
                    //string et = Request.QueryString["esb:endDate"];
                    //if (string.IsNullOrEmpty(st))


                    //    AuditLogDataSource.SelectParameters["StartDate"].DefaultValue = stime.ToString();
                    //else
                    //    AuditLogDataSource.SelectParameters["StartDate"].DefaultValue = DateTime.Parse(st).ToString();
                    //if (string.IsNullOrEmpty(et))

                    //    AuditLogDataSource.SelectParameters["EndDate"].DefaultValue = etime.ToString();
                    //else
                    //    AuditLogDataSource.SelectParameters["EndDate"].DefaultValue = DateTime.Parse(et).ToString();
                }

                GridView1.DataSource = GetData();
                GridView1.DataBind();
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            GridView gv = new GridView();
            gv.AllowPaging = false;
            gv.DataSource = GetData();
            gv.DataBind();
            gv.Dispose();

            GridViewExportUtil.ExcelExport(String.Format("Resubmission_{0}.xls", DateTime.Now.ToShortDateString()), gv);
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                usp_select_Reports_ResubmissionsByServiceResult drv = e.Row.DataItem as usp_select_Reports_ResubmissionsByServiceResult;

                e.Row.Attributes.Add("onclick", "javascript:document.location='../Faults/FaultViewer.aspx?esb:FaultID=" + drv.FaultID.ToString() + "'");
                e.Row.Attributes.Add("class", "GridRow");
                e.Row.Attributes.Add("title", "Click to view fault details");
            }
        }
    }
}