<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="AlertSubscriptionsOverTimeCtrl.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Charts.AlertSubscriptionsOverTimeCtrl" %>


<!-- No HTML UI -->

<DCWC:Chart ID="Chart1" runat="server" BackColor="#DEE6F0" BackSecondaryColor="White"
	ImageType="Jpeg" BackGradientStyle="TopBottom" BorderlineDashStyle="Solid" BorderLineColor="64, 0, 0, 0"
	BorderLineWidth="4" Palette="Excel"
	Width="390px">
	
	<Legends>
		<DCWC:Legend Name="Default">
		</DCWC:Legend>
		<DCWC:Legend  BackColor="White" BorderColor="26, 59, 105" Font="Trebuchet MS, 8.25pt"
			Name="Pastel" ShadowOffset="2">
		</DCWC:Legend>
	</Legends>
	<BorderSkin BackColor="PeachPuff" BackSecondaryColor="DodgerBlue" SkinStyle="Emboss">
	</BorderSkin>
	<ChartAreas>
		<DCWC:ChartArea Name="Default" BorderColor="DimGray" BorderDashStyle="Solid" BackColor="255, 254, 251">
				<AxisX>
				<MinorGrid LineColor="Silver" />
				<MajorTickMark LineDashStyle="NotSet" />
				<MajorGrid Enabled="False" LineColor="Silver" />
			</AxisX>
			<Area3DStyle LightStyle="Realistic" />
			<AxisY>
				<MinorGrid LineColor="Silver" />
				<MajorGrid LineColor="Silver" />
			</AxisY>
			<AxisX2>
				<MinorGrid LineColor="Silver" />
				<MajorGrid LineColor="Silver" />
			</AxisX2>
			<AxisY2>
				<MinorGrid LineColor="Silver" />
				<MajorGrid LineColor="Silver" />
			</AxisY2>
		</DCWC:ChartArea>
	</ChartAreas>
	<Titles>
		<DCWC:Title Font="Trebuchet MS, 12pt, style=Bold" Name="Title1" Text="Alert Subscriptions Over Time">
		</DCWC:Title>
	</Titles>
	<Series>
	</Series>
</DCWC:Chart>