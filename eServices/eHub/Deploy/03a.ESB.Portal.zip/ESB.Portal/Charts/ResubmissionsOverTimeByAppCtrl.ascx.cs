//---------------------------------------------------------------------
// File: ResubmissionsOverTimeByAppCtrl.ascx.cs
// 
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using System.Web.UI.DataVisualization.Charting;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.Practices.ESB.Portal.Charts
{
    public partial class ResubmissionsOverTimeByAppCtrl : System.Web.UI.UserControl
    {


        protected void Page_Load(object sender, EventArgs e)
        {
            this.Chart1.Series.Clear();
            DateTime stime = PortalHelper.GetUserStartDate(Context);
            DateTime etime = DateTime.UtcNow;
            FilterDateRange UserFilterDateRange = PortalHelper.GetUserFilterDateRange(Context);
            Debug.WriteLine("ResubmissionOverTimeByApplication: " + UserFilterDateRange.ToString());
            Debug.WriteLine("Dates: " + stime.ToString() + " = " + etime.ToString());

            StringBuilder sb = new StringBuilder();
            Series applicationSeries;
            foreach (string application in PortalHelper.GetUserApplications(this.Context))
            {
                try
                {
                    IExceptionService client = PortalHelper.GetExceptionService();

                    List<usp_select_Resubmission_Count_Over_Time_By_ApplicationResult> results = client.GetResubmissionCountOverTimeByApplication(application, stime, etime);

                    ((IDisposable)client).Dispose();

                    Debug.WriteLine("Application:" + application + "  Rows count:" + results.Count.ToString());

                    if (results.Count > 0)
                    {
                        sb.Append(application + ",");
                        applicationSeries = this.Chart1.Series.Add(application);
                        applicationSeries.ChartType = SeriesChartType.StackedColumn;
                        applicationSeries.XValueType = ChartValueType.DateTime;

                        foreach (var result in results)
                        {
                            int index;
                            Debug.WriteLine("X:" + PortalHelper.UTC_to_ClientLocalTime(result.DT).ToString() + "  Y:" + result.Total.ToString());
                            index = applicationSeries.Points.AddXY(PortalHelper.UTC_to_ClientLocalTime(result.DT), result.Total);
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            string appSeries = sb.ToString();
            if (appSeries.Length > 1)
            {
                appSeries = appSeries.Substring(0, appSeries.Length - 1);
                switch (UserFilterDateRange)
                {
                    case FilterDateRange.Year:
                    case FilterDateRange.All:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Months, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Months, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Months;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "MMM yy";
                        break;

                    case FilterDateRange.Quarter:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Months, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Months, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Months;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "MMM yy";
                        break;
                    case FilterDateRange.Month:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Days, 0, IntervalType.Days, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Days, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                        Chart1.ChartAreas["Default"].AxisX.IntervalOffset = 0;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Days;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "MMM dd";
                        break;
                    case FilterDateRange.Week:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Days, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Days, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Days;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "ddd";
                        break;
                    case FilterDateRange.Day:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Hours, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Hours, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Hours;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "hh:mm tt";
                        break;
                    case FilterDateRange.Hour:
                        Chart1.DataManipulator.Group("SUM", 1, IntervalType.Minutes, appSeries);
                        Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Minutes, appSeries);
                        Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                        Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Minutes;
                        Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "hh:mm tt";
                        break;
                }

                foreach (Series s in Chart1.Series)
                {
                    string link = string.Format("javascript:parent.redirect('../Reports/ResubmissionOverTimeByService.aspx?esb:app={0}');", Server.UrlEncode(s.Name));
                    s.Url = link;
                    s.LegendUrl = link;
                }
            }
        }
    }
}