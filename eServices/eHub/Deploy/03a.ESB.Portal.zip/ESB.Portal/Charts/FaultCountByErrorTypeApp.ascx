<%@ Control Language="C#" AutoEventWireup="true" CodeBehind="FaultCountByErrorTypeApp.ascx.cs" Inherits="Microsoft.Practices.ESB.Portal.Charts.FaultCountByErrorTypeApp" %>
<%@ Register Assembly="Microsoft.Practices.ESB.Portal" Namespace="Microsoft.Practices.ESB.Portal.GuiHelpers"
    TagPrefix="cc1" %>

<script language="javascript" type="text/javascript">

		function redirect(url)
		{
			document.location = url;
		}
</script>
<center>
<DCWC:Chart ID="Chart1" runat="server" BackColor="#DEE6F0" BackSecondaryColor="White"
	ImageType="jpeg" BackGradientStyle="TopBottom" BorderlineDashStyle="Solid" BorderLineColor="64, 0, 0, 0"
	BorderLineWidth="4" Palette="Excel"
	Width="817px" Height="423px">
	<Legends>
		<DCWC:Legend  BackColor="White" BorderColor="26, 59, 105" Font="Trebuchet MS, 8.25pt" Name="Default" ShadowOffset="2">
		</DCWC:Legend>
	</Legends>
	<BorderSkin BackColor="PeachPuff" BackSecondaryColor="DodgerBlue" SkinStyle="Emboss">
	</BorderSkin>
	<ChartAreas>
		<DCWC:ChartArea Name="Default" BorderColor="DimGray" BorderDashStyle="Solid" BackColor="255, 254, 251">
			<Area3DStyle LightStyle="Realistic"  PointDepth="59" PointGapDepth="18" />
		</DCWC:ChartArea>
	</ChartAreas>
	<Titles>
		<DCWC:Title Font="Trebuchet MS, 12pt, style=Bold" Name="Title1" Text="Fault Count By Error Type"></DCWC:Title>
	</Titles>
	<Series>
		<DCWC:Series BorderColor="64, 64, 64" ChartType="Pie" Font="Tahoma, 8.25pt" Name="Default" ShadowOffset="5">
		</DCWC:Series>
	</Series>
</DCWC:Chart>
</center>
&nbsp;&nbsp;<br />
<br />

<%--<asp:ObjectDataSource ID="ObjectDataSource1" runat="server" OldValuesParameterFormatString="original_{0}"
    SelectMethod="GetData" TypeName="Microsoft.Practices.ESB.Portal.DataSets.FaultCountByErrorTypeTableAdapters.usp_select_Faults_By_Application_And_ErrorTypeTableAdapter">
    <SelectParameters>
        <asp:QueryStringParameter Name="Application" QueryStringField="esb:app" Type="String" />
        <asp:QueryStringParameter Name="ErrorType" QueryStringField="esb:type" Type="String" />
        <asp:Parameter Name="StartDate" Type="DateTime" />
        <asp:Parameter Name="EndDate" Type="DateTime" />
    </SelectParameters>
</asp:ObjectDataSource>
--%>&nbsp;&nbsp;<br />
&nbsp;
<asp:Image ID="Image1" runat="server" ImageUrl="~/Images/Icons/16_excel.gif" />
<asp:LinkButton ID="LinkButton1" runat="server" OnClick="LinkButton1_Click">Export to Excel</asp:LinkButton><br />

<asp:GridView ID="Faults" runat="server" AllowPaging="True" AllowSorting="True" AutoGenerateColumns="False"
    BorderWidth="0px" PageSize="25" Width="100%" OnRowDataBound=Faults_RowDataBound1>
    <Columns>
        <asp:TemplateField HeaderText="Severity" SortExpression="FaultSeverity">
            <ItemStyle Wrap="False" />
            <ItemTemplate>
                <%# GetSeverity(DataBinder.Eval(Container.DataItem, "FaultSeverity"))  %>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:TemplateField HeaderText="Date" SortExpression="DateTime">
            <ItemStyle Wrap="False" />
            <HeaderStyle HorizontalAlign="Center" />
            <ItemTemplate>
                <%# Microsoft.Practices.ESB.Portal.PortalHelper.UTC_to_ClientLocalTime(DataBinder.Eval(Container.DataItem, "DateTime")).ToString()%>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:BoundField DataField="FaultCode" HeaderText="Code" SortExpression="FaultCode" />
        <asp:BoundField DataField="FailureCategory" HeaderText="Category" SortExpression="FailureCategory" />
        <asp:BoundField DataField="Application" HeaderText="Application" SortExpression="Application" />
        <asp:TemplateField HeaderText="Error Type" SortExpression="ErrorType">
            <ItemTemplate>
                <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "ErrorType"), 25)%>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:TemplateField HeaderText="Scope" SortExpression="Scope">
            <ItemTemplate>
                <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "Scope"), 18)%>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:TemplateField HeaderText="Service Name" SortExpression="ServiceName">
            <ItemTemplate>
                <%# GetCrumbedString(DataBinder.Eval(Container.DataItem, "ServiceName"), 25)%>
            </ItemTemplate>
        </asp:TemplateField>
        <asp:BoundField DataField="FaultGenerator" HeaderText="Fault Generator" SortExpression="FaultGenerator" />
        <asp:BoundField DataField="MachineName" HeaderText="Machine Name" SortExpression="MachineName" />
    </Columns>
    <RowStyle CssClass="tableRow" />
    <HeaderStyle CssClass="tableHeader" />
</asp:GridView>
<cc1:GridViewSortExtender ID="GridViewSortExtender1" runat="server" AscendingImageUrl="~/Images/asc_order.gif"
    DescendingImageUrl="~/Images/desc_order.gif" ExtendeeID="Faults">
</cc1:GridViewSortExtender>
