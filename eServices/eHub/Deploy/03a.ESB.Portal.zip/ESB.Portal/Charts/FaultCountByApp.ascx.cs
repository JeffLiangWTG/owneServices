//---------------------------------------------------------------------
// File: FaultCountByApp.ascx.cs
// 
// Summary: This class is the base class for the FaultCountByApp.ascx
//          user control.  It is responsible for querying the fault
//          database for the fault count for each application, then
//          rendering a chart with the fault count data.  It uses
//          the SQL Server Reporting Services ReportViewer control in 
//          local report mode.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------


using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.ComponentModel;
using System.Web.UI.DataVisualization.Charting;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal
{
    public partial class FaultCountByApp : System.Web.UI.UserControl
    {
        /// <summary>
        /// Loads reportviewer and binds the dataset for the report.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            System.Collections.Generic.List<string> userApps = PortalHelper.GetUserApplications(this.Context);

            DateTime stime = PortalHelper.GetUserStartDate(Context);
            DateTime etime = DateTime.UtcNow;


            foreach (string application in PortalHelper.GetUserApplications(this.Context))
            {
                try
                {
                    IExceptionService client = PortalHelper.GetExceptionService();

                    List<ErrorFault> results = client.GetFaultCountByApplication(application, stime, etime);

                    ((IDisposable)client).Dispose();

                    System.Diagnostics.Debug.WriteLine("Data Point for usp_select_Fault_Count_By_Application(" + application + ")" + results.Count);
                    System.Diagnostics.Debug.WriteLine("(" + stime.ToString() + "," + etime.ToString() + ")");

                    foreach (var result in results)
                    {
                        Series s = Chart1.Series.Add(application);
                        s.BackGradientStyle = GradientStyle.TopBottom;
                        s.BorderColor = System.Drawing.Color.LightGray;
                        s["DrawingStyle"] = "Cylinder";
                        int index = s.Points.AddY(result.ErrorCount);
                        s.Points[index].LegendText = application;
                        s.Points[index].LegendUrl = "javascript:parent.redirect('../Reports/FaultCountByService.aspx?esb:app=" + Server.UrlEncode(application) + "');";
                        s.Points[index].Url = "javascript:parent.redirect('../Reports/FaultCountByService.aspx?esb:app=" + Server.UrlEncode(application) + "');";
                        s.Points[index].ToolTip = application;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
}