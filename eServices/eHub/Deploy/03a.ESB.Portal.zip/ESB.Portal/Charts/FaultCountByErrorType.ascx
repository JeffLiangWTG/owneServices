<%@ Control Language="C#" AutoEventWireup="true" Codebehind="FaultCountByErrorType.ascx.cs"
	Inherits="Microsoft.Practices.ESB.Portal.Graphs.FaultCountByErrorType" %>

<DCWC:Chart ID="Chart1" runat="server" BackColor="#DEE6F0"  BackSecondaryColor="White"
	ImageType="jpeg"  BackGradientStyle="TopBottom"  BorderLineDashStyle="Solid" BorderLineColor="64, 0, 0, 0"
	BorderLineWidth="4" Palette="Excel"
	Width="390px">
	<Legends>
		<DCWC:Legend BackColor="White" BorderColor="26, 59, 105" Font="Trebuchet MS, 8.25pt" Name="Default" ShadowOffset="2">
		</DCWC:Legend>
	</Legends>
	<BorderSkin  SkinStyle="Emboss">
	</BorderSkin>
	<ChartAreas>
		<DCWC:ChartArea Name="Default" BorderColor="DimGray"  BorderDashStyle="Solid" BackColor="255, 254, 251">
			<Area3DStyle LightStyle="Realistic"  />
		</DCWC:ChartArea>
	</ChartAreas>
	<Titles>
		<DCWC:Title Font="Trebuchet MS, 12pt, style=Bold" Name="Title1" Text="Fault Count By Error Type"></DCWC:Title>
	</Titles>
	<Series>
		<DCWC:Series BorderColor="64, 64, 64" ChartType="Pie"  Font="Tahoma, 8.25pt" Name="Default" ShadowOffset="5">
		</DCWC:Series>
	</Series>
</DCWC:Chart>
