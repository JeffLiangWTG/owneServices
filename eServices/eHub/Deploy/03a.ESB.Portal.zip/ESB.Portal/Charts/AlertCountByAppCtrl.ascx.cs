//---------------------------------------------------------------------
// File: AlertCountByAppCtrl.ascx.cs
// 
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI.DataVisualization.Charting;
using System.ComponentModel;
using ESB.Exceptions.Service.Implementation;
using System.Collections.Generic;

namespace Microsoft.Practices.ESB.Portal.Charts
{
    public partial class AlertCountByAppCtrl : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            System.Collections.Generic.List<string> userApps = PortalHelper.GetUserApplications(this.Context);

            foreach (string application in PortalHelper.GetUserApplications(this.Context))
            {
                try
                {
                    IExceptionService client = PortalHelper.GetExceptionService();

                    List<usp_select_AlertHistoryReportByApplicationResult> results = client.GetAlertHistoryReportByApplication(application, PortalHelper.GetUserStartDate(Context), DateTime.UtcNow);

                    ((IDisposable)client).Dispose();

                    foreach (usp_select_AlertHistoryReportByApplicationResult result in results)
                    {
                        if (result.Alerts > 0)
                        {
                            Series s = Chart1.Series.Add(application);
                            s.BackGradientStyle = GradientStyle.TopBottom;
                            s.BorderColor = System.Drawing.Color.LightGray;
                            s["DrawingStyle"] = "Cylinder";
                            int index = s.Points.AddY(result.Alerts);
                            s.Points[index].LegendText = application;
                            s.Points[index].LegendUrl = "javascript:parent.redirect('../Reports/AlertCountByService.aspx?esb:app=" + Server.UrlEncode(application) + "');";
                            s.Points[index].Url = "javascript:parent.redirect('../Reports/AlertCountByService.aspx?esb:app=" + Server.UrlEncode(application) + "');";
                            s.Points[index].ToolTip = application;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
}
