<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" Codebehind="Reports.aspx.cs"
	Inherits="Microsoft.Practices.ESB.Portal.Reports.Reports" %>

<%@ Register Src="../Lists/MySetting.ascx" TagName="MySetting" TagPrefix="uc1" %>

<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
	<div>
		<h1 class="iconReport">Reports</h1>
        <uc1:MySetting ID="MySetting1" runat="server" />
		<br />
        
		
		<span style="font-family: Trebuchet MS; font-size: 12px;
					margin-left: 10px;">
          
		</span> 
		<div style="clear: both; height: 320px; width: 100%;">
			<div style="float: left; width: 400px;">
				<iframe src="../Charts/FaultCountByApp.aspx" frameborder="0" width="400" height="340"></iframe>
			</div>
			<div style="float: left; width: 400px;">
				<iframe src="../Charts/FaultCountByErrorType.aspx" frameborder="0" width="400" height="340"></iframe>
			</div>
			<div style="float: left; width: 400px;">
				<iframe src="../Charts/FaultCountOverTimeByApp.aspx" frameborder="0" width="400" height="340"></iframe>
			</div>
		</div>
	</div>
	<div>
		<div style="clear: both; height: 320px; width: 100%;">
			<div style="float: left; width: 400px;">
				<iframe src="../Charts/AlertCountByApp.aspx" frameborder="0" width="400" height="340"></iframe>
			</div>
			<div style="float: left; width: 400px;">
				<iframe src="../Charts/ResubmissionsOverTimeByApp.aspx" frameborder="0" width="400" height="340"></iframe>
			</div>
			<div style="float: left; width: 400px;">
				<iframe src="../Charts/AlertSubscriptionsOverTime.aspx" frameborder="0" width="400" height="340"></iframe>
			</div>
		</div>
	</div>
</asp:Content>


