<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="FaultCountOverTimeByAppService.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Reports.FaultCountOverTimeByAppService" Title="Untitled Page" %>

<%@ Register Src="../Charts/FaultCountOverTimeByAppService.ascx" TagName="FaultCountOverTimeByAppService"
    TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    
    <h1 class="iconReport"> <asp:Label ID="Label1" runat="server" Text=""></asp:Label></h1>
    <br />
    <br />
    <uc1:FaultCountOverTimeByAppService ID="FaultCountOverTimeByAppService1" runat="server" />
</asp:Content>
