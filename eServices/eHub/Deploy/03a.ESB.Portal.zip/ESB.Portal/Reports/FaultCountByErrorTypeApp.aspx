<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="FaultCountByErrorTypeApp.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Reports.FaultCountByErrorTypeApp" Title="Untitled Page" %>

<%@ Register Src="../Charts/FaultCountByErrorTypeApp.ascx" TagName="FaultCountByErrorTypeApp"
    TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
 <h1 class="iconReport"> <asp:Label ID="Label1" runat="server" Text=""></asp:Label></h1>
<br />
<br />
    <uc1:FaultCountByErrorTypeApp id="FaultCountByErrorTypeApp1" runat="server">
    </uc1:FaultCountByErrorTypeApp>
</asp:Content>
