<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="AlertCountByService.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Reports.AlertCountByService" Title="Untitled Page" %>


<%@ Register Src="../Charts/AlertCountByServiceCtrl.ascx" TagName="AlertCountByServiceCtrl" TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    
   

   <h1 class="iconReport"> <asp:Label ID="Label1" runat="server" Text=""></asp:Label></h1>
<br />
<br />
    
    <uc1:AlertCountByServiceCtrl ID="AlertCountByServiceCtrl1" runat="server" />


</asp:Content>
