<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="AlertSubOverTimeService.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Reports.AlertSubOverTimeService" Title="Untitled Page" %>

<%@ Register Src="../Charts/AlertSubscriptionsOverTimeService.ascx" TagName="AlertSubscriptionsOverTimeService"
    TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

 <h1 class="iconReport"> <asp:Label ID="Label1" runat="server" Text=""></asp:Label></h1>
<br />
<br />
    <uc1:AlertSubscriptionsOverTimeService ID="AlertSubscriptionsOverTimeService1" runat="server" />
</asp:Content>
