<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="FaultCountByService.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Reports.FaultCountByService" Title="Untitled Page" %>

<%@ Register Src="../Charts/FaultCountByServicesCtrl.ascx" TagName="FaultCountByServicesCtrl"
    TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">

   <h1 class="iconReport"> <asp:Label ID="Label1" runat="server" Text=""></asp:Label></h1>
<br />
<br />
    <uc1:FaultCountByServicesCtrl ID="FaultCountByServicesCtrl1" runat="server" />

</asp:Content>
