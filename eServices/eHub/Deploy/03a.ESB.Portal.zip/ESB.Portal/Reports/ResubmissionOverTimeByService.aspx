<%@ Page Language="C#" MasterPageFile="~/Layout.Master" AutoEventWireup="true" CodeBehind="ResubmissionOverTimeByService.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.Reports.ResubmissionOverTimeByService" Title="Untitled Page" %>

<%@ Register Src="../Charts/ResubmissionOverTimeByService.ascx" TagName="ResubmissionOverTimeByService"
    TagPrefix="uc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
<h1 class="iconReport"> <asp:Label ID="Label1" runat="server" Text=""></asp:Label></h1>
    <br />
    <br />
    <uc1:ResubmissionOverTimeByService ID="ResubmissionOverTimeByService1" runat="server" />
</asp:Content>
