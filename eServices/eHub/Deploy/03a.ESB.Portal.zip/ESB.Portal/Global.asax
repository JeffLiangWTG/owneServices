<%@ Application Codebehind="Global.asax.cs" Inherits="Microsoft.Practices.ESB.Portal.Global" Language="C#" %>
