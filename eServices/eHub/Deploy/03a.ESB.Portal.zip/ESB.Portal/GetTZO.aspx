<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="GetTZO.aspx.cs" Inherits="Microsoft.Practices.ESB.Portal.GetTZO" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" >
<head runat="server">
    <title>Untitled Page</title>
    <script type="text/javascript">
        function getQueryVariable(variable) 
        { 
            var query = window.location.search.substring(1);  
            var vars = query.split("&");  
            for (var i=0;i<vars.length;i++) 
            {    
                var pair = vars[i].split("=");    
                if (pair[0] == variable) 
                {      
                    return pair[1];    
                }  
            } 
        }
     function SetTZO()
        {
        
             var d = new Date();
             var tzo = -1 * d.getTimezoneOffset()/60;
             var url = getQueryVariable("url");
             if (!url || url=="")
             {
                document.location="default.aspx";
             }else
             
             {

                var urldecode =decodeURIComponent(url);


                        
             if (urldecode.indexOf("\?") > 0)
             {
               //  document.write(urldecode+ "&tzo="+tzo);                            
                document.location = urldecode + "&tzo="+tzo;
             }else 
               {
                // document.write(urldecode+ "?tzo="+tzo);                            
               document.location = urldecode + "?tzo="+tzo;
               }
        }
    }
    
    </script> 
    
    
    
</head>
<body onload="SetTZO()">
    <form id="form1" runat="server">
    <div>
    
    </div>
    </form>
</body>
</html>
