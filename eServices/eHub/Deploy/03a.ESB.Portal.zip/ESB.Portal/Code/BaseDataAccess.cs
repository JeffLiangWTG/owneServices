//---------------------------------------------------------------------
// File:  BaseDataAccess.cs
// 
// Summary: Data access helper base class
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------
using System;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Configuration;
namespace Microsoft.Practices.ESB.Portal
{
    /// <summary>
    /// Provides data access to Microsoft SQL Server.
    /// </summary>
    public class BaseDataAccess
    {
        string connectionString;

        /// <summary>
        /// Constructor takes the connectionString and creates and opens the connection.
        /// </summary>
        /// <param name="connectString">The connection string to connect to the database.</param>
        public BaseDataAccess(string connectionString)
        {
            this.connectionString = connectionString;
        }

        /// <summary>
        /// Retrieves the connection string from the app configuration file and uses it to open the connection.
        /// </summary>
        public BaseDataAccess()
        {
            connectionString = ConfigurationManager.ConnectionStrings["EsbExceptionDb"].ConnectionString;            
        }

        #region Query Methods        

        /// <summary>
        /// Calls a stored procedure and returns its results.
        /// </summary>
        /// <param name="procName">The name of the stored procedure.</param>
        /// <param name="theParams">The parameters for the stored procedure.</param>
        /// <returns>A dataset containing the results of the stored procedure.</returns>
        protected DataSet ExecuteProc(string procName, SqlParameter[] theParams)
        {            
            DataSet theData = new DataSet();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter theAdapter = new SqlDataAdapter(getProcCommand(procName, theParams, connection)))
                {
                    theAdapter.Fill(theData);
                }
            }            

            return theData;
        }
        /// <summary>
        /// Calls a stored procedure and returns its results.
        /// </summary>
        /// <param name="procName">The name of the stored procedure.</param>
        /// <param name="theParams">The parameters for the stored procedure.</param>
        /// <returns></returns>
        protected DataSet ExecuteProc(string procName)
        {            
            DataSet theData = new DataSet();

            using(SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlDataAdapter theAdapter = new SqlDataAdapter(getProcCommand(procName, connection)))
                {
                    theAdapter.Fill(theData);
                }
            }             
            
            return theData;
        }

        /// <summary>
        /// Executes an insert, update, or delete stored procedure.
        /// </summary>
        /// <param name="procName"></param>
        /// <param name="theParams"></param>
        protected void ExecuteNonQuery(string procName, SqlParameter[] theParams)
        {
            using(SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand theCommand = getProcCommand(procName, theParams, connection))
                {
                    theCommand.ExecuteNonQuery();
                }                    
            }
        }

        /// <summary>
        /// Creates and returns an SqlCommand with the given name and parameters.
        /// </summary>
        /// <param name="procName">The text for the command.</param>
        /// <param name="theParams">The parameters for the command.</param>
        /// <returns></returns>
        private SqlCommand getProcCommand(string procName, SqlParameter[] theParams, SqlConnection connection)
        {
            SqlCommand theCommand = new SqlCommand(procName, connection);
            theCommand.CommandType = CommandType.StoredProcedure;
            AddParameters(theCommand, theParams);

            return theCommand;
        }
        private SqlCommand getProcCommand(string procName, SqlConnection connection)
        {
            SqlCommand theCommand = new SqlCommand(procName, connection);
            theCommand.CommandType = CommandType.StoredProcedure;


            return theCommand;
        }

        /// <summary>
        /// Adds each of the parameters in the give parameter in the array to theCommand.
        /// </summary>
        /// <param name="theCommand">A given SqlCommand.</param>
        /// <param name="theParams">The parameters you wish to add to theCommand.</param>
        private void AddParameters(SqlCommand theCommand, SqlParameter[] theParams)
        {
            foreach (SqlParameter aParam in theParams)
            {
                theCommand.Parameters.Add(aParam);
            }
        }
        #endregion

        #region Parameter Methods

        /// <summary>
        /// Creates and returns an SqlParameter.
        /// </summary>
        /// <param name="paramName">Parameter name.</param>
        /// <param name="theType">Parameter type.</param>
        /// <param name="theSize">Parameter size.</param>
        /// <param name="theDirection">Parameter direction.</param>
        /// <param name="isNullable">Is the parameter nullable.</param>
        /// <returns>A null valued SqlParameter with the given characteristics.</returns>
        protected SqlParameter CreateSqlParameter(string paramName, SqlDbType theType, int theSize, ParameterDirection theDirection, bool isNullable)
        {
            SqlParameter theParameter = new SqlParameter(paramName, theType, theSize);
            theParameter.Direction = theDirection;
            theParameter.IsNullable = isNullable;
            theParameter.Value = null;

            return theParameter;
        }

        /// <summary>
        /// Gets a copy of the given parameter set.  This is needed because parameters can
        /// be used only once.
        /// </summary>
        /// <param name="originalParams"></param>
        /// <returns></returns>
        protected static SqlParameter[] CloneParameterSet(SqlParameter[] originalParams)
        {
            SqlParameter[] clonedParameterSet = new SqlParameter[originalParams.Length];

            for (int i = 0, j = originalParams.Length; i < j; i++)
            {
                clonedParameterSet[i] = (SqlParameter)((ICloneable)originalParams[i]).Clone();
            }

            return clonedParameterSet;
        }

        #endregion

    }
}
