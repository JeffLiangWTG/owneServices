//---------------------------------------------------------------------
// File: Formatter.cs
// 
// Summary: 2 generic functions for serializing and deserializing
//          objects from and to ToBase64String.  Called by 
//          ExceptionMgmt class
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------


using System;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Collections;
using System.Runtime.Serialization.Formatters.Binary;
using System.Reflection;
using System.Xml.Serialization;
using System.Xml;


namespace Microsoft.Practices.ESB.Portal
{
    /// <summary>
    /// Formatter class to convert to/from a Base64-encoded string. Used to serialize the context properties of each payload message
    /// </summary>
    [Serializable]
    public sealed class Formatter
    {
        #region Constants
        internal const string SOURCE = "Microsoft.Practices.ESB.ExceptionHandling:Formmatter";
        internal const string ERROR_SOURCE_FORMAT = "Class: {0} Method: {1}";
        #endregion
       
        /// <summary>
        /// Base64 encode the passed parameter
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="anyThing"></param>
        /// <returns></returns>
        public static String SerializeObject<T>(T anyThing)
        {
            // Argument exception
            if (null == anyThing)
                throw new ArgumentNullException("anyThing");

            MemoryStream memoryStream = new MemoryStream();
            BinaryFormatter bf = new BinaryFormatter();
            byte[] buffer = null;

            try
            {

                bf.Serialize(memoryStream, anyThing);
                memoryStream.Position = 0;
                buffer = memoryStream.GetBuffer();
                return Convert.ToBase64String(buffer);
            }            
            finally
            {
                if (null != memoryStream)
                {
                    memoryStream.Close();
                    memoryStream.Dispose();
                    memoryStream = null;
                }
                if (null != bf) { bf = null; }
                if (null != buffer) { buffer = null; }
            }
        }

        /// <summary>
        /// Convert the Base64-encoded string into a .NET type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="content"></param>
        /// <returns></returns>
        public static T DeserializeObject<T>(String content)
        {
            // Argument Exception
            if (null == content)
                throw new ArgumentNullException("content");

            byte[] buffer = null;
            MemoryStream memoryStream = null;
            BinaryFormatter bf = new BinaryFormatter();
            try
            {
                buffer = Convert.FromBase64String(content);
                memoryStream = new MemoryStream(buffer);
                memoryStream.Position = 0;
                return (T)bf.Deserialize(memoryStream);
            }            
            finally
            {
                if (null != memoryStream)
                {
                    memoryStream.Close();
                    memoryStream.Dispose();
                    memoryStream = null;
                }
                if (null != bf) { bf = null; }
                if (null != buffer) { buffer = null; }
            }
        }

    }
}
