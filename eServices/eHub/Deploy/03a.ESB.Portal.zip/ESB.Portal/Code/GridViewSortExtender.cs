//---------------------------------------------------------------------
// File: GridViewSortExtender.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Web.UI.Design;
using System.Drawing.Design;

namespace Microsoft.Practices.ESB.Portal.GuiHelpers
{
    /// <summary>
    /// The GridViewSortExtender is used to add a sort indicator to a <see cref="GridView"/>.
    /// The sort indicator is an image that is shown in the sort column and displays the sort direction.
    /// </summary>
    [Designer(typeof(GridViewSortExtenderDesigner))]
    public class GridViewSortExtender : Control
    {
        /// <summary>
        /// Image that is displayed when SortDirection is ascending.
        /// </summary>
        [DefaultValue("")]
        [Editor(typeof(ImageUrlEditor), typeof(UITypeEditor))]
        [Description("Image that is displayed when SortDirection is ascending.")]
        public string AscendingImageUrl
        {
            get { return this.ViewState["AscendingImageUrl"] != null ? (string)this.ViewState["AscendingImageUrl"] : ""; }
            set { this.ViewState["AscendingImageUrl"] = value; }
        }

        /// <summary>
        /// Image that is displayed when SortDirection is descending.
        /// </summary>
        [DefaultValue("")]
        [Editor(typeof(ImageUrlEditor), typeof(UITypeEditor))]
        [Description("Image that is displayed when SortDirection is descending.")]
        public string DescendingImageUrl
        {
            get { return this.ViewState["DescendingImageUrl"] != null ? (string)this.ViewState["DescendingImageUrl"] : ""; }
            set { this.ViewState["DescendingImageUrl"] = value; }
        }

        /// <summary>
        /// The GridView that is extended.
        /// </summary>
        [DefaultValue("")]
        [IDReferenceProperty(typeof(GridView))]
        [TypeConverter(typeof(GridViewIDConverter))]
        [Description("The GridView that is extended.")]
        public string ExtendeeID
        {
            get { return this.ViewState["Extendee"] != null ? (string)this.ViewState["Extendee"] : ""; }
            set { this.ViewState["Extendee"] = value; }
        }

        /// <summary>
        /// Adds an event handler to the DataBound event of the extended GridView.
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPreRender(EventArgs e)
        {
            base.OnInit(e);

            GridView extendee = this.NamingContainer.FindControl(this.ExtendeeID) as GridView;
            if (extendee != null && extendee.AllowSorting && extendee.HeaderRow != null && !String.IsNullOrEmpty(extendee.SortExpression))
            {
                int field = GetSortField(extendee);
                if (field >= 0)
                {
                    Image img = new Image();
                    img.ImageUrl = extendee.SortDirection == SortDirection.Ascending ? this.AscendingImageUrl : this.DescendingImageUrl;
                    img.ImageAlign = ImageAlign.TextTop;

                    extendee.HeaderRow.Cells[field].Controls.Add(img);
                }
            }
        }

        /// <summary>
        /// Returns the index of the sort-column.
        /// </summary>
        /// <param name="extendee"></param>
        /// <returns></returns>
        private int GetSortField(GridView extendee)
        {
            int i = 0;
            foreach (DataControlField field in extendee.Columns)
            {
                if (field.SortExpression == extendee.SortExpression)
                {
                    return i;
                }
                i++;
            }
            return -1;
        }
    }

    /// <summary>
    /// Designer for <see cref="GridViewSortExtender"/>.
    /// </summary>
    public class GridViewSortExtenderDesigner : ControlDesigner
    {
        public override string GetDesignTimeHtml()
        {
            return "<div style=\"background-color: #C8C8C8; border: groove 2 Gray;\"><b>GridViewSortExtender</b> - " + this.Component.Site.Name + "</div>";
        }
    }

    public class GridViewIDConverter : ControlIDConverter
    {
        // Methods
        protected override bool FilterControl(Control control)
        {
            return control is GridView;
        }
    }

}

