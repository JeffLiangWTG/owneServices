//---------------------------------------------------------------------
// File:  MessageResubmitter.cs
// 
// Summary: Helper class for resubmitting messages to BizTalk receive
//          locations.
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Xml;

namespace Microsoft.Practices.ESB.Portal
{

   /// <summary>
   /// This is a helper class responsible for resubmitting messages into the ESB
   /// </summary>
   [Serializable]
   public static class MessageResubmitter
   {
      /// <summary>
      /// Submits an XML message to the WCF OnRamp.  The URL of the WCF OnRamp is defined in the
      /// portal web.config.  Context properties are not resubmitted, they are expected to be
      /// applied by the receiving pipeline.
      /// </summary>
      /// <param name="doc">The XML document to submit.</param>
      /// <returns>True if the submission was successful, false if the submission failed.</returns>
      public static bool ResubmitWCF(XmlDocument doc)
      {
         try
         {
            ProcessRequestClient onRamp = new ProcessRequestClient();
            onRamp.SubmitRequest(null, doc.OuterXml);
            return true;
         }
         catch (Exception)
         {
            return false;
         }
      }

       /// <summary>
       /// Submits an XML message to the SOAP OnRamp.  The URL of the SOAP OnRamp is defined in the
       /// portal web.config.  Context properties are not resubmitted, they are expected to be
       /// applied by the receiving pipeline.
       /// </summary>
       /// <param name="doc">The XML Document to resubmit.</param>
       /// <returns>True if the resubmission was successful, false if the resubmission failed.</returns>
       public static bool ResubmitSOAP(XmlDocument doc)
       {
           try
           {
               ProcessItinerary.Process onRamp = new ProcessItinerary.Process();
               onRamp.SubmitRequest((XmlNode)doc);
               return true;
           }
           catch (Exception)
           {
               return false;
           }
       }

      /// <summary>
      /// Submits an XML or flat file message to a BizTalk HTTP receive location.  This method
      /// submits the message body, and not the context properties.  The receive pipeline should
      /// apply the needed context properties.
      /// </summary>
      /// <param name="resubmitRequest">An HttpWebRequest object configured to submit to the receive location.</param>
      /// <param name="messageStream">A Stream containing the message body.</param>
      /// <returns>An HttpStatusCode indicating the success or failure of the resubmission.</returns>
      public static HttpStatusCode ResubmitHTTP (HttpWebRequest resubmitRequest, Stream messageStream)
      {
         HttpStatusCode returnCode = HttpStatusCode.InternalServerError;
         HttpWebResponse response;

         using (StreamReader sr = new StreamReader(messageStream, Encoding.ASCII))
         {
            StreamWriter sw = new StreamWriter(resubmitRequest.GetRequestStream());

            sw.WriteLine(sr.ReadToEnd());
            sw.Flush();
            sw.Close();

            try
            {
                response = resubmitRequest.GetResponse() as HttpWebResponse;

                return response.StatusCode;
            }
            catch 
            {
               return returnCode;
            }
         }
      }
   }
}
