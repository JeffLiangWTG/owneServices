//=================================================================
//  File:		AutoActivateControl.cs
//
//  Namespace:	Dundas.Utilities
//
//	Classes:	AutoActivateControl
//
//  Purpose:	To auto activate web controls.
//
//===================================================================
// Dundas Chart Control .Net
// Copyright � Dundas Software 2001-2006, all rights reserved
//===================================================================

using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.UI;

namespace Dundas.Utilities
{
    /// <summary>
    /// AutoActivateControl is used to avoid the activation required for Flash (activex object) files.
    /// </summary>
    public class AutoActivateControl
    {
        /// <summary>
        /// Used to store the control.
        /// </summary>
        private Control myControl;

        /// <summary>
        /// Initializes a new instance of the <see cref="T:AutoActivateControl"/> class.
        /// </summary>
        /// <param name="control">The control.</param>
        public AutoActivateControl(Control control)
        {
            //Store the control in a private variable.
            myControl = control;

            //Attach to the Pre-Render event.
            myControl.PreRender += new EventHandler(control_PreRender);
        }

        /// <summary>
        /// Handles the PreRender event of the control control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="T:System.EventArgs"/> instance containing the event data.</param>
        void control_PreRender(object sender, EventArgs e)
        {
            //Create a memory stream and a stream writer to handle it.
            System.IO.MemoryStream memoryStream = new System.IO.MemoryStream();
            System.IO.StreamWriter streamWriter = new System.IO.StreamWriter(memoryStream);

            //Create a html writer.
            HtmlTextWriter htmlTextWriter = new HtmlTextWriter(streamWriter);

            //Render the control into the memory stream via the html writer.
            myControl.RenderControl(htmlTextWriter);
            myControl.Visible = false;

            //Flush the writer into the stream.
            htmlTextWriter.Flush();

            //Create a reader for the stream.
            System.IO.StreamReader streamReader = new System.IO.StreamReader(memoryStream);
            memoryStream.Position = 0;

            //Try with the embed name, but if that fails generate a unique name.
            string filename = "embed.js";
            try
            {
                streamWriter = new System.IO.StreamWriter(myControl.Page.Server.MapPath(".") + "\\" + filename);
            }
            catch
            {
                System.Random raGen = new Random();
                filename = "embed" + raGen.Next(1000).ToString() + ".js";

                streamWriter = new System.IO.StreamWriter(myControl.Page.Server.MapPath(".") + "\\" + filename);
            }
            
            //Create the new JavaScript function that writes out this object.
            streamWriter.Write("document.write('" + streamReader.ReadToEnd().Replace("\n", "").Replace("\r", "") + "')");
            streamWriter.Close();

            //Add the javascript line to the page to load this javascript file.
#if VS2003
                        myControl.Page.RegisterClientScriptBlock("autoActivateJavascript",
                "<script src=\"" + myControl.Page.ResolveUrl("~/" + filename) + "\"></script>");
#else
            myControl.Page.ClientScript.RegisterClientScriptBlock(typeof(string),
                "autoActivateJavascript",
                "<script src=\"" + myControl.Page.ResolveUrl("~/" + filename) + "\"></script>",
                false);
#endif
        }
    }
}
