using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Xml;
using Microsoft.Practices.ESB.Portal.eHubResubmitService;

namespace Microsoft.Practices.ESB.Portal
{

   /// <summary>
   /// This is a helper class responsible for resubmitting messages into eHub
   /// </summary>
   [Serializable]
   public static class eHubResubmitter
   {
        /// <summary>
        /// Submits the message ID to the eHub resubmission web service.  The URL of the WCF OnRamp is defined in the
        /// portal web.config.  Context properties are not resubmitted, they are expected to be
        /// applied by the receiving pipeline.
        /// </summary>
        /// <param name="messageID">The document ID to submit for replay.</param>
        /// <returns>True if the submission was successful, false if the submission failed.</returns>
        public static bool Resubmit(string messageID)
        {
            ResubmitClient submitClient = new ResubmitClient();
            try
            {
                ResubmitRequest request = new ResubmitRequest();
                request.MessageID = messageID;
                submitClient.Send(request);
                return true;
            }
            catch (Exception ex)
            {
                string error = ex.ToString();
                return false;
            }
            finally
            {
                if (submitClient != null)
                {
                    ((IDisposable)submitClient).Dispose();
                }
            }
        }
   }
}
