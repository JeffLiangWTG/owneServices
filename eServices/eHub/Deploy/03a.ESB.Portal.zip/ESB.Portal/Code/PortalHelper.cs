//---------------------------------------------------------------------
// File: PortalHelper.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.SessionState; 
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.Practices.ESB.Portal;
using Microsoft.Practices.ESB.Portal.DataSets;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Collections;
using System.DirectoryServices;
using ESB.Exceptions.Service.Implementation;
using System.ServiceModel;
using System.Reflection;

namespace Microsoft.Practices.ESB.Portal
{
    public class PortalHelper
    {
        public static DataTable GetDataTable<T>(T items) where T : IEnumerable
        {
            DataTable table = new DataTable();
            bool createHeader = true;

            foreach (var t in items)
            {
                PropertyInfo[] properties = t.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

                if (createHeader)
                {
                    foreach (var p in properties)
                    {
                        Type columnType = p.PropertyType;
                        if (p.PropertyType.IsGenericType && p.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                        {
                            columnType = p.PropertyType.GetGenericArguments()[0];
                        }

                        table.Columns.Add(p.Name, columnType);
                    }
                }

                createHeader = false;
                DataRow row = table.NewRow();
                foreach (var p in properties)
                {
                    if (p.CanRead)
                    {
                        row[p.Name] = p.GetValue(t, null);
                    }

                }
                table.Rows.Add(row);
            }

            return table;
        }

        public static string EndPointIcon(string endpointName)
        {
            string spacer = "<img src='../images/spacer.gif' width='2px'>";
            switch (endpointName.ToLower())
            {
                case "send":
                    return "<img src='../images/icons/16_send.gif'>" + spacer;
                case "receive":
                    return "<img src='../images/icons/16_receive.gif'>" + spacer;
                default:
                    return "<img src='../images/spacer.gif' width='16px' height='16px'>" + spacer;
            }
        }

        public static bool IsUserInGroup(string pstrDomain, string pstrUser, string pstrGroup)
        {
            try
            {
                DirectoryEntry objADEntry = new DirectoryEntry("WinNT://" + pstrDomain + ",domain");
                DirectoryEntry objUser = objADEntry.Children.Find(pstrUser, "user");
                DirectoryEntry objGroup = objADEntry.Children.Find(pstrGroup, "group");
                return (bool)objGroup.Invoke("IsMember", new object[] { objUser.Path.ToString() });
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static string ShowLocalDateTime(object utcDate)
        {
            return ShowLocalDateTime((DateTime)utcDate);
        }

        public static string ShowLocalDateTime(DateTime utcDate)
        {
            return "<script language=\"javascript\">document.write(formatUTCToLocalShortDate('" + utcDate.ToLongDateString() + " " + utcDate.ToLongTimeString() + "'))</script>";
        }

        public static string TranslateSeverityText(int severity)
        {
            switch (severity)
            {
                case 0:
                    return "Information";
                case 1:
                    return "Warning";
                case 2:
                    return "Error";
                case 3:
                    return "Severe";
                case 4:
                    return "Critical";
                default:
                    return string.Empty;
            }
        }

        public static string TranslateSeverityCssClass(int severity)
        {
            switch (severity)
            {
                case 0:
                    return "SeverityInformation";
                case 1:
                    return "SeverityWarning";
                case 2:
                    return "SeverityError";
                case 3:
                    return "SeveritySevere";
                case 4:
                    return "SeverityCritical";
                default:
                    return string.Empty;
            }
        }

        public static string TranslateSeverityImages(int severity)
        {
            switch (severity)
            {
                case 0:
                    return "Images/SeverityInformation.gif";
                case 1:
                    return "Images/SeverityWarning.gif";
                case 2:
                    return "Images/SeverityError.gif";
                case 3:
                    return "Images/SeveritySevere.gif";
                case 4:
                    return "Images/SeverityCritical.gif";
                default:
                    return string.Empty;
            }
        }

        public static System.Collections.Generic.List<BizTalkOperationsService.BTApplication> GetAllApplications()
        {
            BizTalkOperationsService.Operations queryService = BizTalkOperationsService.Operations.CreateInstance();
            BizTalkOperationsService.BTApplication[] applications = queryService.Applications();

            System.Collections.SortedList sl = new System.Collections.SortedList();

            foreach (BizTalkOperationsService.BTApplication app in applications)
            {
                sl.Add(app.Name, app);
            }

            System.Collections.Generic.List<BizTalkOperationsService.BTApplication> sortedApplications = new System.Collections.Generic.List<Microsoft.Practices.ESB.Portal.BizTalkOperationsService.BTApplication>();

            foreach (BizTalkOperationsService.BTApplication app in sl.Values)
            {
                sortedApplications.Add(app);
            }

            return sortedApplications;
        }

        public static List<string> GetServiceNames()
        {
            BizTalkOperationsService.Operations queryService = BizTalkOperationsService.Operations.CreateInstance();
            BizTalkOperationsService.BTSysStatus systemStatus = queryService.SystemStatus();

            List<string> serviceNames = new List<string>();
            foreach (BizTalkOperationsService.BTOrchestration orchestration in systemStatus.Orchestrations)
            {
                serviceNames.Add(orchestration.Name);
            }

            foreach (BizTalkOperationsService.BTSendPort sendPort in systemStatus.SendPorts)
            {
                serviceNames.Add(sendPort.Name);
            }

            foreach (BizTalkOperationsService.BTReceiveLocation receiveLocation in systemStatus.ReceiveLocations)
            {
                serviceNames.Add(receiveLocation.Name);
            }

            return serviceNames;
        }

        public static string CrumbString(string str, int crumbAt)
        {
            if (str.Length > crumbAt)
            {
                return str.Substring(0, crumbAt) + "...";
            }
            else
            {
                return str;
            }
        }

        public static FilterDateRange GetUserFilterDateRange(HttpContext context)
        {
            if (context.Session["UserFilterDateRange"] != null)
            {
                return (FilterDateRange)Enum.Parse(typeof(FilterDateRange), context.Session["UserFilterDateRange"].ToString(), true);
            }

            return FilterDateRange.Hour;
        }

		public static void SetUserFilterDateRange(HttpContext context, string value)
		{
			context.Session["UserFilterDateRange"] = value;
		}

        public static System.Collections.Generic.List<string> GetUserApplications(HttpContext context)
        {
            System.Collections.Generic.List<string> list = new System.Collections.Generic.List<string>();

            if (context.Session["DefaultApplications"] != null)
            {
                foreach (string app in context.Session["DefaultApplications"].ToString().Split(",".ToCharArray()))
                {
                    list.Add(app);
                }
            }

            return list;
        }

        public static void SaveUserSetting(HttpContext context, string settingName, string settingValue)
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();
                client.SaveUserSettings(new UserSetting() { SettingValue = settingValue, SettingName = settingName, UserName = context.User.Identity.Name });
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }

        public static void LoadUserSettingsToSession(HttpContext context)
        {
            IExceptionService client = null;
            try
            {
                client = PortalHelper.GetExceptionService();
				List<UserSetting> settings = client.GetUserSettings(context.User.Identity.Name);

                context.Session.Clear();

                foreach (UserSetting u in settings)
                {
                    context.Session.Add(u.SettingName, u.SettingValue);
                }
            }
            finally
            {
                if (client != null)
                {
                    ((IDisposable)client).Dispose();
                }
            }
        }

        public static DateTime GetUserStartDate(HttpContext context)
        {
            return GetStartDate(GetUserFilterDateRange(context));
        }

        public static IExceptionService GetExceptionService()
        {
            ChannelFactory<IExceptionService> factory = new ChannelFactory<IExceptionService>("ExceptionService");
			factory.Credentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
			return factory.CreateChannel();
        }

        public static DateTime GetStartDate(FilterDateRange filterDateRange)
        {
            switch (filterDateRange)
            {
                case FilterDateRange.Day:
                    return DateTime.UtcNow.AddDays(-1);
                case FilterDateRange.Week:
                    return DateTime.UtcNow.AddDays(-7);
                case FilterDateRange.Month:
                    return DateTime.UtcNow.AddMonths(-1);
                case FilterDateRange.Quarter:

                    return FirstDayOfMonth(DateTime.UtcNow.AddMonths(-3));
                case FilterDateRange.Year:
                    return FirstDayOfMonth(DateTime.UtcNow.AddMonths(-12));
                case FilterDateRange.All:
                    return FirstDayOfMonth(DateTime.UtcNow.AddYears(-10));
                default:
                    return DateTime.UtcNow.AddHours(-1);
            }
        }
		
		public static DateTime FirstDayOfMonth(DateTime date)
        {
            return new DateTime(date.Year, date.Month, 1);
        }

        public static DateTime ClientLocalTime_to_UTC(DateTime LocalTime)
        {
            if (HttpContext.Current.Session["tzo"] != null)
            {
                int TZO = (int)HttpContext.Current.Session["tzo"];
                DateTime dt = new DateTime(LocalTime.Year, LocalTime.Month, LocalTime.Day, LocalTime.Hour, LocalTime.Minute, LocalTime.Millisecond, LocalTime.Second, DateTimeKind.Utc);
                return dt.AddHours(TZO * -1);
            }
            else
            {
                return LocalTime.ToUniversalTime();
            }
        }

        public static DateTime UTC_to_ClientLocalTime(object UTC)
        {
            return UTC_to_ClientLocalTime((DateTime)UTC);
        }
        public static DateTime UTC_to_ClientLocalTime(DateTime UTC)
        {
            if (HttpContext.Current.Session["tzo"] != null)
            {
                int TZO = (int)HttpContext.Current.Session["tzo"];
                DateTime dt = new DateTime(UTC.Year, UTC.Month, UTC.Day, UTC.Hour, UTC.Minute, UTC.Second, UTC.Millisecond, DateTimeKind.Local);
                return dt.AddHours(TZO);
            }
            else
            {
                return UTC.ToLocalTime();
            }
        }
        public static string GetDateParamsQueryString(FilterDateRange filterDateRange)
        {
            DateTime startDate = GetStartDate(filterDateRange);
            return "esb:startDate=" + System.Web.HttpUtility.UrlEncode(startDate.ToUniversalTime().ToString()) + "&esb:endDate=" + System.Web.HttpUtility.UrlEncode(DateTime.UtcNow.ToString());
        }
    }
}

public enum FilterDateRange
{
    Hour,
    Day,
    Week,
    Month,
    Quarter,
    Year,
    All
}