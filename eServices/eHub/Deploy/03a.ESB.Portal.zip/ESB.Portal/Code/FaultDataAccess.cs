//---------------------------------------------------------------------
// File: ExcelExport.cs
//   Summary: Wraps the functionality to access a SQL Server database.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------


using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace Microsoft.Practices.ESB.Portal
{
	public class FaultDataAccess : BaseDataAccess
	{
        /// <summary>
        /// Default constructor calls the base constructor.
        /// </summary>
        public FaultDataAccess()
            : base()
        {
        }


		/// <summary>
		/// Constructor calls the base constructor.
		/// </summary>
		/// <param name="connectionString"></param>
        public FaultDataAccess(string connectionString) : base(connectionString)
		{
		}

		#region Query

		/// <summary>
		/// Initiates the financials loading process.
		/// </summary>
		public void LoadFinancials(int periodKey)
		{
			SqlParameter[] theParams = buildLoadFinancialsParams();
			theParams[0].Value = periodKey;
			ExecuteNonQuery("usp_LoadFinancials", theParams);
		}

		/// <summary>
		/// Initiates the financials approval process.
		/// </summary>
		public void ApproveFinancials(int periodKey)
		{
			SqlParameter[] theParams = buildApproveFinancialsParams();
			theParams[0].Value = periodKey;
			ExecuteNonQuery("usp_ApproveFinancials", theParams);
		}

		/// <summary>
		/// Retrieves the load periods for the current year, and the last period from the previous year.
		/// </summary>
		public DataTable SelectDimLoadPeriod()
		{
			DataSet theData;
			DataTable theTable;
			theData = ExecuteProc("usp_SelectDimLoadPeriod", new SqlParameter[0]);
			theTable = theData.Tables[0];

			return theTable;
		}

		#endregion

		#region Parameter
 
		/// <summary>
		/// Builds the parameters for the LoadFinancials method
		/// </summary>
		/// <returns></returns>
		private SqlParameter[] buildLoadFinancialsParams()
		{
			SqlParameter[] theParams = new SqlParameter[1];
			theParams[0] = CreateSqlParameter("@PeriodKey", SqlDbType.Int, 4, ParameterDirection.Input, false);
			return theParams;
		}

		/// <summary>
		/// Builds the parameters for the LoadFinancials method
		/// </summary>
		/// <returns></returns>
		private SqlParameter[] buildApproveFinancialsParams()
		{
			SqlParameter[] theParams = new SqlParameter[1];
			theParams[0] = CreateSqlParameter("@PeriodKey", SqlDbType.Int, 4, ParameterDirection.Input, false);
			return theParams;
		}

		#endregion

        /// <summary>
        /// Retrieves a message body from the database.
        /// </summary>
        /// <param name="MessageID">The MessageID of the message which should be retrieved.</param>
        /// <returns>A SqlDataReader containing the message body.  The message body is stored in a varbinary(max) field named 'MessageData'.</returns>
        public DataTable SelectMessageBody(string MessageID)
        {
            SqlParameter[] theParams = new SqlParameter[1];
            theParams[0] = CreateSqlParameter("@MessageID", SqlDbType.VarChar, 50, ParameterDirection.Input, false);
            theParams[0].Value = MessageID;
            DataTable messageTable = ExecuteProc("dbo.usp_select_MessageBody", theParams).Tables[0];
            return messageTable;
        }

        /// <summary>
        /// Retrieves a message body from the database.
        /// </summary>
        /// <param name="MessageID">The MessageID of the message which should be retrieved.</param>
        /// <returns>A SqlDataReader containing the message body.  The message body is stored in a varbinary(max) field named 'MessageData'.</returns>
        public DataTable SelectFaultCountByApp()
        {

            DataTable faultTable = ExecuteProc("dbo.usp_select_Fault_Count_by_Application").Tables[0];
            return faultTable;
        }



	}
}
