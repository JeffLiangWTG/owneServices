//---------------------------------------------------------------------
// File:  BizTalkOperationsService.cs
// 
// Summary: Helper class for calling the BizTalk Query Web Service.
//
//
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------
using System;

namespace Microsoft.Practices.ESB.Portal.BizTalkOperationsService
{
    public partial class Operations
    {
        /// <summary>
        /// Creates an instance of the BizTalk Query Service with Credentials.
        /// </summary>
        public static Operations CreateInstance()
        {
            BizTalkOperationsService.Operations btService = new BizTalkOperationsService.Operations();            
            btService.Credentials = System.Net.CredentialCache.DefaultCredentials;
            return btService;
        }
    }
}