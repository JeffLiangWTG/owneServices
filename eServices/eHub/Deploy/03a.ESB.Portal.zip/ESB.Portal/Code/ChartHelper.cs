//---------------------------------------------------------------------
// File: ChartHelper.cs
// 
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Dundas.Charting.WebControl;
using System.Web.Util;
using System.Web.UI.DataVisualization.Charting;
namespace Microsoft.Practices.ESB.Portal
{
    public class ChartHelper
    {
        public static bool SetupServiceChart(ref Chart Chart1,  FilterDateRange UserFilterDateRange, string application)
        {

            switch (UserFilterDateRange)
            {
                case FilterDateRange.Year:
                case FilterDateRange.All:
                    Chart1.DataManipulator.Group("SUM", 1, IntervalType.Months, "*");
                    Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Months, "*");
                    Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                    Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Months;
                    Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "MMM yyyy";
                    break;
                case FilterDateRange.Quarter:
                    Chart1.DataManipulator.Group("SUM", 1, IntervalType.Months, "*");
                    Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Months, "*");
                    Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                    Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Months;
                    break;
                case FilterDateRange.Month:
                    Chart1.DataManipulator.Group("SUM", 1, IntervalType.Days, "*");
                    Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Days, "*");
                    Chart1.ChartAreas["Default"].AxisX.Interval = 2;
                    Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Days;
                    Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "MMM dd";
                    break;
                case FilterDateRange.Week:
                    Chart1.DataManipulator.Group("SUM", 1, IntervalType.Days, "*");
                    Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Days, "*");
                    Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                    Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Days;
                    Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "ddd";
                    break;
                case FilterDateRange.Day:
                    Chart1.DataManipulator.Group("SUM", 1, IntervalType.Hours, "*");
                    // Chart1.DataManipulator.InsertEmptyPoints(1, IntervalType.Minutes , "*");
                    Chart1.ChartAreas["Default"].AxisX.Interval = 1;
                    Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Hours;
                    Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "hh:mm tt";
                    break;
                case FilterDateRange.Hour:
                    Chart1.DataManipulator.Group("SUM", 10, IntervalType.Minutes, 0, IntervalType.Minutes, "*");
                    Chart1.DataManipulator.InsertEmptyPoints(10, IntervalType.Minutes, "*");
                    Chart1.ChartAreas["Default"].AxisX.Interval = 10;
                    Chart1.ChartAreas["Default"].AxisX.IntervalOffset = 0;
                    Chart1.ChartAreas["Default"].AxisX.IntervalType = DateTimeIntervalType.Minutes;
                    Chart1.ChartAreas["Default"].AxisX.LabelStyle.Format = "hh:mm tt";

                    foreach (Series s in Chart1.Series)
                    {
                        foreach (DataPoint p in s.Points)
                        {
                            DateTime bTime = PortalHelper.ClientLocalTime_to_UTC(DateTime.FromOADate(p.XValue));
                            DateTime eTime = bTime.AddMinutes(9.999);

                            System.Diagnostics.Trace.WriteLine("p:" + bTime.ToString());
                            string link2 = string.Format("?esb:app={0}&esb:service={1}&esb:startDate={2}&esb:endDate={3}", application, HttpUtility.UrlEncode(s.Name), bTime.ToString(), eTime.ToString());
                            p.Url = link2;
                        }
                    }
                    break;
            }

            return true;
        }
    }
}
