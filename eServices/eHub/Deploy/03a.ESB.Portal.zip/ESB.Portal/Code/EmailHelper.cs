//---------------------------------------------------------------------
// File: EmailHelper.cs
// 
// Summary: Transforms an uddi pending reg into a notification email body.
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------

using System;
using System.IO;
using System.Text;
using System.Xml.Xsl;
using Microsoft.Practices.ESB.Portal.Uddi;

namespace Microsoft.Practices.ESB.Portal
{
    internal static class EmailHelper
    {
        private static System.Xml.XPath.XPathDocument XPathDoc; 

        /// <summary>
        /// Transforms email body using xslt provided.
        /// </summary>
        /// <param name="xml">Email body as xml.</param>
        /// <returns>The transformed email body.</returns>
        public static string GetHtmlBody(System.Xml.XmlDocument xmlDoc, string xsltPath)
        {

            if (XPathDoc == null)
            {
                // Transform xml using xslt
                XPathDoc = new System.Xml.XPath.XPathDocument(new System.Xml.XmlTextReader(xsltPath));
            }

            // Create transform
            XslCompiledTransform compTransform = new XslCompiledTransform();
            compTransform.Load(XPathDoc.CreateNavigator(), null, null);

            // Write to a stream
            using (MemoryStream memory = new MemoryStream())
            {
               compTransform.Transform(xmlDoc.CreateNavigator(), null, memory);
               return UTF8BytesToString(memory.ToArray());
            }
        }

        /// <summary>
        /// Build an Email document with all the details the user has input in the form
        /// </summary>
        /// <returns>XML Document</returns>
        public static System.Xml.XmlDocument CreateEmailDocument(Endpoints.EndpointRow endPoint)
        {
            // We create an xmlDocument with a root node of "Root"
            System.Xml.XmlDocument xmlDoc = new System.Xml.XmlDocument();
            System.Xml.XmlNode xmlnode;
            xmlnode = xmlDoc.CreateElement("Root");
            xmlDoc.AppendChild(xmlnode);

            // read in the data and create the body of our doc
            SetEmailDocument(xmlDoc, endPoint);

            return xmlDoc;
        }

        /// <summary>
        /// <summary>
        /// Creates the elements of the XML files to merge with XSL
        /// </summary>
        /// <param name="xmlDoc"></param>
        /// <param name="endPoint">end point info</param>
        private static void SetEmailDocument(System.Xml.XmlDocument xmlDoc, Endpoints.EndpointRow endPoint)
        {
            // Append the Endpoint Info to XMl Document
            System.Xml.XmlNode xmlnode;

            //EndPoint Name
            xmlnode = xmlDoc.CreateElement("EndpointName");
            xmlnode.InnerText = endPoint.EndpointName.ToString();
            xmlDoc.DocumentElement.AppendChild(xmlnode);

            //EndPoint Description
            xmlnode = xmlDoc.CreateElement("Description");
            xmlnode.InnerText = endPoint.Description;
            xmlDoc.DocumentElement.AppendChild(xmlnode);

            //EndPoint Value
            xmlnode = xmlDoc.CreateElement("EndpointValue");
            xmlnode.InnerText = endPoint.EndpointValue;
            xmlDoc.DocumentElement.AppendChild(xmlnode);

            //UDDIContactName
            xmlnode = xmlDoc.CreateElement("UDDIContactName");
            xmlnode.InnerText = endPoint.UDDIContactName;
            xmlDoc.DocumentElement.AppendChild(xmlnode);

            //EndPoint UDDIEMail
            xmlnode = xmlDoc.CreateElement("UDDIEMail");
            xmlnode.InnerText = endPoint.UDDIEMail;
            xmlDoc.DocumentElement.AppendChild(xmlnode);

            //BizTalkApplication
            xmlnode = xmlDoc.CreateElement("BizTalkApplication");
            xmlnode.InnerText = endPoint.BizTalkApplication;
            xmlDoc.DocumentElement.AppendChild(xmlnode);

            //BusinessProvider
            xmlnode = xmlDoc.CreateElement("BusinessProvider");
            xmlnode.InnerText = endPoint.BusinessProvider;
            xmlDoc.DocumentElement.AppendChild(xmlnode);

            //ServiceName
            xmlnode = xmlDoc.CreateElement("ServiceName");
            xmlnode.InnerText = endPoint.ServiceName;
            xmlDoc.DocumentElement.AppendChild(xmlnode);
        }

        /// <summary>
        /// Convert unicoded values of a byte array to string.
        /// </summary>
        /// <param name="bytes">Unicode Byte[] to be converted</param>
        /// <returns><c>string</c> Value converted</returns>
        private static string UTF8BytesToString(Byte[] bytes)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            return encoding.GetString(bytes);
        }
    }
}
