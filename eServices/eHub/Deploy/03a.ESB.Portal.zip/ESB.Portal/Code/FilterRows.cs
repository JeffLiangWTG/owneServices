//---------------------------------------------------------------------
// File: FilterRows.cs
//   
//          
//---------------------------------------------------------------------
// This file is part of the Microsoft ESB Guidance for BizTalk
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 R2 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//----------------------------------------------------------------------
using System;
using System.Data;
using System.Web.Security;
using System.Collections;


namespace Microsoft.Practices.ESB.Portal
{
    public class FilterRows : IEnumerable
    {
        DataView dataView;
        private int rowsToShow;
    
        public int Count
        {
           get {            
                if (dataView.Count >= rowsToShow)
                    return rowsToShow;
                else
                    return dataView.Count;
                }
        }
        public FilterRows(DataView dataView, int rowsToShow)
        {
            this.rowsToShow = rowsToShow;
            this.dataView = dataView;
        }

        public IEnumerator GetEnumerator()
        {
            return new PageOfData(this.dataView.GetEnumerator(), this.rowsToShow);
        }


        internal class PageOfData : IEnumerator
        {
            private IEnumerator e;
            private int cnt = 0;
            private int rowsToShow;

            internal PageOfData(IEnumerator e, int rowsToShow)
            {
                this.rowsToShow = rowsToShow;
                this.e = e;
            }

            public object Current
            {
                get { return e.Current; }
            }

            public bool MoveNext()
            {
                // If we've hit out limit return false
                if (cnt >= rowsToShow)
                    return false;

                // Track the current row
                cnt++;

                return e.MoveNext();
            }

            public void Reset()
            {
                e.Reset();
                cnt = 0;
            }
        }
    }
}



