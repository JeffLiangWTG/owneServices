﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel;
using ESB.Exceptions.Service.Implementation;

namespace ESB.Exceptions.Service.Tests
{
    class Program
    {
        static void Main(string[] args)
        {
            //InsertAlertSucceeded();
            //GetAlertByIdSucceeded();
            //GetAlertHistoryByNameSucceeded();
            //GetAlertHistorySucceeded();
            //GetAlertSubscriptionByIdSucceeded();
            //UpdateAlertSubscriptionSucceeded();
        }

        private static void InsertAlertSucceeded()
        {
            ChannelFactory<IExceptionService> factory = new ChannelFactory<IExceptionService>("ExceptionService");
            IExceptionService client = factory.CreateChannel();

            Alert alert = new Alert() { AlertID = Guid.NewGuid(), ConditionsString = "", InsertedBy = "Nico", InsertedDate = DateTime.UtcNow, Name = "TestAlert" };

            client.InsertAlert(alert);

            ((IDisposable)client).Dispose();
        }

        private static void GetAlertHistoryByNameSucceeded()
        {
            ChannelFactory<IExceptionService> factory = new ChannelFactory<IExceptionService>("ExceptionService");
            IExceptionService client = factory.CreateChannel();

            List<AlertHistory> results = client.GetAlertHistoryByName("esb");

            bool hasFaults = results.Count > 0;

            ((IDisposable)client).Dispose();
        }

        private static void GetAlertByIdSucceeded()
        {
            ChannelFactory<IExceptionService> factory = new ChannelFactory<IExceptionService>("ExceptionService");
            IExceptionService client = factory.CreateChannel();

            Guid id = new Guid("5e5c9ed0-2d9a-4430-b09b-e0fe283f3fe3");
            Alert alert = client.GetAlertById(id);

            ((IDisposable)client).Dispose();

            if (alert != null)
            {
                //List<AlertCondition> x = alert.AlertConditions;
                int a = 1;
                //string ae = alert.ConditionsString;
            }
        }

        private static void GetAlertHistorySucceeded()
        {
            ChannelFactory<IExceptionService> factory = new ChannelFactory<IExceptionService>("ExceptionService");
            IExceptionService client = factory.CreateChannel();

            List<usp_select_AlertHistoryResult> results = client.GetAlertHistory(5);

            bool hasFaults = results.Count > 0;

            ((IDisposable)client).Dispose();
        }

        private static void GetAlertSubscriptionByIdSucceeded()
        {
            ChannelFactory<IExceptionService> factory = new ChannelFactory<IExceptionService>("ExceptionService");
            IExceptionService client = factory.CreateChannel();

            AlertSubscription results = client.GetAlertSubscriptionById(new Guid("e7b12deb-ad2c-45f6-99a2-d375ea5d2e83"));

            ((IDisposable)client).Dispose();
        }

        private static void GetFaultsCountByErrorTypeSucceeded()
        {
            ChannelFactory<IExceptionService> factory = new ChannelFactory<IExceptionService>("ExceptionService");
            IExceptionService client = factory.CreateChannel();

            List<ErrorFault> results = client.GetFaultCountByErrorType(DateTime.UtcNow.AddYears(-1), DateTime.UtcNow, "GlobalBank.ESB");

            bool hasFaults = results.Count > 0;

            ((IDisposable)client).Dispose();
        }

        private static void UpdateAlertSubscriptionSucceeded()
        {
            ChannelFactory<IExceptionService> factory = new ChannelFactory<IExceptionService>("ExceptionService");
            IExceptionService client = factory.CreateChannel();

            AlertSubscription x = client.GetAlertSubscriptionById(new Guid("e7b12deb-ad2c-45f6-99a2-d375ea5d2e83"));

            x.CustomEmail = "tu hermana";

            client.UpdateAlertSubscription(x);
            ((IDisposable)client).Dispose();
        }
    }
}
