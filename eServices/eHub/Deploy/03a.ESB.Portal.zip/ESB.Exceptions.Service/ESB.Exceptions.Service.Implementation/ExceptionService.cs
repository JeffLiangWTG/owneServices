﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.Linq;
using System.Configuration;
//using Microsoft.Practices.EnterpriseLibrary.Data.Configuration;
using System.Threading;

namespace ESB.Exceptions.Service.Implementation
{
    public class ExceptionService : IExceptionService
    {
        private ExceptionDataContext dataContextInstance;

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<ErrorFault> GetFaultCountByErrorTypeByApplication(string errorType, string applicationName, DateTime beginDate, DateTime endDate)
        {
            string[] applications = new string[0];

            if (!string.IsNullOrEmpty(applicationName))
            {
                applications = applicationName.Split(new char[1] { ',' });
            }

            var dataContext = GetDataContext();

            var result = from f in dataContext.Faults
                         where applications.Contains(f.Application) && f.ErrorType == errorType &&
                         f.InsertedDate >= beginDate && f.InsertedDate <= endDate
                         group f by new { f.Application, f.ErrorType } into g
                         select new ErrorFault() { ErrorCount = g.Count(), ErrorType = g.Key.ErrorType, Application = g.Key.Application };

            return result.ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<ErrorFault> GetFaultCountByApplication(string applicationName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();

            var result = from aggregatedFault in dataContext.vw_AggregatedFaults
                         where aggregatedFault.Application == (string.IsNullOrEmpty(applicationName) ? aggregatedFault.Application : applicationName) &&
                         aggregatedFault.TrueDateTime >= beginDate && aggregatedFault.TrueDateTime <= endDate
                         group aggregatedFault by aggregatedFault.Application into g
                         select new ErrorFault() { Application = g.Key, ErrorCount = g.Sum(aggregatedFault => aggregatedFault.FaultCount).HasValue ? g.Sum(aggregatedFault => aggregatedFault.FaultCount).Value : 0 };

            return result.ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_AlertSubscription_Count_Over_Time_By_ApplicationResult> GetAlertSubscriptionCountOverTimeByApplication(string applicationName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetAlertSubscriptionCountOverTimeByApplication(applicationName, beginDate, endDate, false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_AlertSubscription_Count_Over_Time_By_Application_ServiceNameResult> GetAlertSubscriptionCountOverTimeByApplicationServiceName(string applicationName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetAlertSubscriptionCountOverTimeByApplicationServiceName(applicationName, beginDate, endDate, false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_AlertStatisticsResult> GetAlertStatistics()
        {
            var dataContext = GetDataContext();
            return dataContext.GetAlertStatistics().ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_AlertsResult> GetAlerts()
        {
            var dataContext = GetDataContext();
            return dataContext.GetAlerts().ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_AlertHistoryResult> GetAlertHistory(int rowNumber)
        {
            var dataContext = GetDataContext();
            return dataContext.GetAlertHistory(rowNumber).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_AlertHistoryReportByServiceResult> GetAlertHistoryReportByService(string applicationName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetAlertHistoryReportByService(applicationName, beginDate, endDate).ToList();
        }

        [OperationBehavior(Impersonation=ImpersonationOption.Required)]
        public List<usp_select_AlertHistoryReportByServiceFaultResult> GetAlertHistoryReportByServiceFault(string applicationName, string serviceName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetAlertHistoryReportByServiceFault(applicationName, serviceName, beginDate, endDate).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_AlertHistoryReportByApplicationResult> GetAlertHistoryReportByApplication(string applicationName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetAlertHistoryReportByApplication(applicationName, beginDate, endDate).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_AlertHistoryReportByApplication_Over_TimeResult> GetAlertHistoryReportByApplicationOverTime(string applicationName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetAlertHistoryReportByApplicationOverTime(applicationName, beginDate, endDate).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<ErrorFault> GetFaultCountByErrorType(DateTime startDate, DateTime endDate, string application)
        {
            var dataContext = GetDataContext();
            string[] applications = new string[0];

            if (!string.IsNullOrEmpty(application))
            {
                applications = application.Split(new char[1] { ',' });
            }

            var result = from f in dataContext.Faults
                         where applications.Contains(f.Application) &&
                         f.InsertedDate >= startDate && f.InsertedDate <= endDate
                         group f by f.ErrorType into g
                         select new ErrorFault() { ErrorCount = g.Count(), ErrorType = g.Key };

            return result.ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<Fault> GetFaults(Guid faultID, string application, DateTime startDate, DateTime endDate, string faultCode, string failureCategory, string errorType, int maxFaultSeverity)
        {
            var dataContext = GetDataContext();

            DateTime? initDate = null;
            if (startDate.CompareTo(DateTime.MinValue) > 0)
            {
                initDate = startDate;
            }

            DateTime? finishDate = null;
            if (endDate.CompareTo(DateTime.MinValue) > 0)
            {
                finishDate = endDate;
            }
            
            var result = from f in dataContext.Faults
                         where (f.DateTime >= initDate && f.DateTime <= finishDate) &&
                         f.FaultID == (faultID != Guid.Empty ? faultID : f.FaultID) &&
                         f.Application == (!string.IsNullOrEmpty(application) ? application : f.Application) &&
                         f.FaultCode == (!string.IsNullOrEmpty(faultCode) ? faultCode : f.FaultCode) &&
                         f.FailureCategory == (!string.IsNullOrEmpty(failureCategory) ? failureCategory : f.FailureCategory) &&
                         f.ErrorType == (!string.IsNullOrEmpty(errorType) ? errorType : f.ErrorType) &&
                         (f.FaultSeverity >= 0 && f.FaultSeverity <= maxFaultSeverity)
                         select f;

            return result.ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public Fault GetFault(Guid faultID)
        {
            try
            {
                var dataContext = GetDataContext();
                return dataContext.Faults.Single(f => f.FaultID == faultID);
            }
            catch (InvalidOperationException)
            {
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_MessagesResult> GetMessages(string faultID, string messageID)
        {
            var dataContext = GetDataContext();
            return dataContext.GetMessages(faultID, messageID, false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<AlertHistory> GetAlertHistoryByName(string alertName)
        {
            var dataContext = GetDataContext();
            var result = from a in dataContext.AlertHistories
                         where a.AlertName == alertName
                         orderby a.AlertName
                         select a;

            return result.ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_ContextPropertiesResult> GetContextProperties(Guid messageID)
        {
            var dataContext = GetDataContext();
            return dataContext.GetContextProperties(messageID.ToString(), false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<AlertSubscription> GetAlertSubscriptionsByAlertId(Guid alertId)
        {
            var dataContext = GetDataContext();
            var alerts = from a in dataContext.AlertSubscriptions
                         where a.AlertID == alertId
                         select a;

            return alerts.ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<AlertSubscription> GetAlertSubscriptionsBySubscriber(string subscriber)
        {
            var dataContext = GetDataContext();
            var alerts = from a in dataContext.AlertSubscriptions
                         where a.Subscriber == subscriber
                         select a;

            return alerts.ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public Alert GetAlertById(Guid alertId)
        {
            try
            {
                var dataContext = GetDataContext();
                return dataContext.Alerts.Single(a => a.AlertID == alertId);
            }
            catch (InvalidOperationException)
            {
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void DeleteAlertById(Guid alertId)
        {
            var dataContext = GetDataContext();
            Alert deleteAlert = null;

            try
            {
                deleteAlert = dataContext.Alerts.Single(a => a.AlertID == alertId);
            }
            catch (InvalidOperationException)
            {
                throw new ArgumentException(string.Format(Thread.CurrentThread.CurrentCulture, "The alert {0} doesn't exist.", alertId));
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (deleteAlert == null)
            {
                throw new ArgumentException("alertId");
            }

            dataContext.Alerts.DeleteOnSubmit(deleteAlert);

            bool allSaved = false;

            while (!allSaved)
            {
                try
                {
                    dataContext.SubmitChanges(ConflictMode.ContinueOnConflict);
                    allSaved = true;
                }
                catch (ChangeConflictException)
                {
                    foreach (var cc in dataContext.ChangeConflicts)
                    {
                        cc.Resolve(RefreshMode.KeepCurrentValues);
                    }
                }
            }
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void InsertAlert(Alert alert)
        {
            var dataContext = GetDataContext();
            if (alert == null)
            {
                throw new ArgumentException("alert");
            }

            dataContext.Alerts.InsertOnSubmit(alert);
            dataContext.SubmitChanges();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void InsertAlertCondition(AlertCondition alertCondition)
        {
            var dataContext = GetDataContext();
            if (alertCondition == null)
            {
                throw new ArgumentException("alertCondition");
            }

            dataContext.AlertConditions.InsertOnSubmit(alertCondition);
            dataContext.SubmitChanges();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void DeleteAlertConditionById(Guid alertConditionId)
        {
            var dataContext = GetDataContext();
            AlertCondition deleteAlertCondition = null;

            try
            {
                deleteAlertCondition = dataContext.AlertConditions.Single(a => a.AlertConditionID == alertConditionId);
            }
            catch (InvalidOperationException)
            {
                throw new ArgumentException(string.Format(Thread.CurrentThread.CurrentCulture, "The alert condition {0} doesn't exist.", alertConditionId));
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (deleteAlertCondition == null)
            {
                throw new ArgumentException("alertConditionId");
            }

            dataContext.AlertConditions.DeleteOnSubmit(deleteAlertCondition);

            bool allSaved = false;

            while (!allSaved)
            {
                try
                {
                    dataContext.SubmitChanges(ConflictMode.ContinueOnConflict);
                    allSaved = true;
                }
                catch (ChangeConflictException)
                {
                    foreach (var cc in dataContext.ChangeConflicts)
                    {
                        cc.Resolve(RefreshMode.KeepCurrentValues);
                    }
                }
            }
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public AlertSubscription GetAlertSubscriptionById(Guid alertSubscriptionId)
        {
            try
            {
                var dataContext = GetDataContext();
                return dataContext.AlertSubscriptions.Single(a => a.AlertSubscriptionID == alertSubscriptionId);
            }
            catch (InvalidOperationException)
            {
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void InsertAlertSubscription(AlertSubscription alertSubscription)
        {
            if (alertSubscription == null)
            {
                throw new ArgumentException("alertSubscription");
            }
            var dataContext = GetDataContext();
            dataContext.AlertSubscriptions.InsertOnSubmit(alertSubscription);
            dataContext.SubmitChanges();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void DeleteAlertSubscriptionById(Guid alertSubscriptionId)
        {
            var dataContext = GetDataContext();
            AlertSubscription deleteAlertSubscription = null;
            try
            {
                deleteAlertSubscription = dataContext.AlertSubscriptions.Single(a => a.AlertSubscriptionID == alertSubscriptionId);
            }
            catch (InvalidOperationException)
            {
                throw new ArgumentException(string.Format(Thread.CurrentThread.CurrentCulture, "The alert subscription {0} doesn't exist.", alertSubscriptionId));
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (deleteAlertSubscription == null)
            {
                throw new ArgumentException("alertSubscriptionId");
            }

            dataContext.AlertSubscriptions.DeleteOnSubmit(deleteAlertSubscription);

            bool allSaved = false;

            while (!allSaved)
            {
                try
                {
                    dataContext.SubmitChanges(ConflictMode.ContinueOnConflict);
                    allSaved = true;
                }
                catch (ChangeConflictException)
                {
                    foreach (var cc in dataContext.ChangeConflicts)
                    {
                        cc.Resolve(RefreshMode.KeepCurrentValues);
                    }
                }
            }
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<AlertCondition> GetAlertConditionsByAlertId(Guid alertId)
        {
            var dataContext = GetDataContext();
            var result = from ac in dataContext.AlertConditions
                         where ac.AlertID == alertId
                         select ac;

            return result.ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void UpdateAlertSubscription(AlertSubscription alertSubscription)
        {
            if (alertSubscription == null)
            {
                throw new ArgumentException("alertSubscription");
            }

            var dataContext = GetDataContext();
            dataContext.AlertSubscriptions.Attach(alertSubscription, true);

            bool allSaved = false;

            while (!allSaved)
            {
                try
                {
                    dataContext.SubmitChanges(ConflictMode.ContinueOnConflict);
                    allSaved = true;
                }
                catch (ChangeConflictException)
                {
                    foreach (var cc in dataContext.ChangeConflicts)
                    {
                        cc.Resolve(RefreshMode.KeepCurrentValues);
                    }
                }
            }
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void UpdateAlert(Alert alert)
        {
            if (alert == null)
            {
                throw new ArgumentException("alert");
            }
            var dataContext = GetDataContext();
            dataContext.Alerts.Attach(alert, true);

            bool allSaved = false;

            while (!allSaved)
            {
                try
                {
                    dataContext.SubmitChanges(ConflictMode.ContinueOnConflict);
                    allSaved = true;
                }
                catch (ChangeConflictException)
                {
                    foreach (var cc in dataContext.ChangeConflicts)
                    {
                        cc.Resolve(RefreshMode.KeepCurrentValues);
                    }
                }
            }
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void UpdateAlertCondition(AlertCondition alertCondition)
        {
            if (alertCondition == null)
            {
                throw new ArgumentException("alertCondition");
            }
            var dataContext = GetDataContext();
            dataContext.AlertConditions.Attach(alertCondition, true);

            bool allSaved = false;

            while (!allSaved)
            {
                try
                {
                    dataContext.SubmitChanges(ConflictMode.ContinueOnConflict);
                    allSaved = true;
                }
                catch (ChangeConflictException)
                {
                    foreach (var cc in dataContext.ChangeConflicts)
                    {
                        cc.Resolve(RefreshMode.KeepCurrentValues);
                    }
                }
            }
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void InsertAuditLog(AuditLog auditLog)
        {
            var dataContext = GetDataContext();
            dataContext.InsertAuditLog(auditLog.ActionName, auditLog.MessageID, auditLog.MessageData, auditLog.ResubmitURL,
                auditLog.ResubmitCode, auditLog.ResubmitMessage, auditLog.AuditUserName, false);
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void InsertMessage(string messageID, bool resubmitAttemped, bool resubmitSuccessful)
        {
            var dataContext = GetDataContext();
            dataContext.InsertMessage(messageID, resubmitAttemped, resubmitSuccessful, false);
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_AuditLogResult> GetAuditLog(string actionName, string messageId, string faultId, string auditUserName, DateTime startDate, DateTime endDate, string application)
        {
            DateTime? initDate = null;
            if (startDate.CompareTo(DateTime.MinValue) > 0)
            {
                initDate = startDate;
            }

            DateTime? finishDate = null;
            if (endDate.CompareTo(DateTime.MinValue) > 0)
            {
                finishDate = endDate;
            }
            var dataContext = GetDataContext();
            return dataContext.GetAuditLog(actionName, messageId, faultId, auditUserName, initDate, finishDate, application, false).ToList();
        }

        #region IExceptionService Members

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void InsertConfiguration(List<ConfigurationItem> configuration)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException("configuration");
            }
            var dataContext = GetDataContext();
            dataContext.ConfigurationItems.AttachAll(configuration, true);
            dataContext.SubmitChanges();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public ConfigurationItem GetConfigurationByName(string name)
        {
            try
            {
                var dataContext = GetDataContext();
                return dataContext.ConfigurationItems.Single(c => c.Name == name);
            }
            catch (InvalidOperationException)
            {
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public Dictionary<string, ConfigurationItem> GetConfiguration()
        {
            var dataContext = GetDataContext();
            return dataContext.ConfigurationItems.ToDictionary(c => c.Name);
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Fault_Count_By_Application_GroupByServicesResult> GetFaultCountByApplicationGroupByServices(string applicationName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetFaultCountByApplicationGroupByServices(applicationName, beginDate, endDate).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Fault_Count_Over_Time_By_ErrorTypeResult> GetFaultCountOverTimeByErrorType(string errorType, DateTime beginDate, DateTime endDate, string applicationName)
        {
            var dataContext = GetDataContext();
            return dataContext.GetFaultCountOverTimeByErrorType(applicationName, errorType, beginDate, endDate, false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Fault_Count_Over_Time_By_ApplicationResult> GetFaultCountOverTimeByApplication(string applicationName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetFaultCountOverTimeByApplication(applicationName, beginDate, endDate, false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Fault_Count_Over_Time_By_Application_ServiceNameResult> GetFaultCountOverTimeByApplicationServiceName(string applicationName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetFaultCountOverTimeByApplicationServiceName(applicationName, beginDate, endDate, false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Fault_Count_Over_Time_By_ErrorTypeResult> GetFaultCountOverTimeByErrorType(string applications, string errorType, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetFaultCountOverTimeByErrorType(applications, errorType, beginDate, endDate, false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Resubmission_Count_Over_Time_By_Application_ServiceNameResult> GetResubmissionCountOverTimeByApplicationServiceName(string application, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetResubmissionCountOverTimeByApplicationServiceName(application, beginDate, endDate, false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Resubmission_Count_Over_Time_By_ApplicationResult> GetResubmissionCountOverTimeByApplication(string application, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetResubmissionCountOverTimeByApplication(application, beginDate, endDate, false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Faults_By_Application_And_ErrorTypeResult> GetFaultsByApplicationAndErrorType(string application, string errorType, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetFaultsByApplicationAndErrorType(application, errorType, beginDate, endDate).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Faults_By_Application_And_ServicesResult> GetFaultsByApplicationAndService(string application, string serviceName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetFaultsByApplicationAndServices(application, serviceName, beginDate, endDate).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Reports_ResubmissionsResult> GetReportsResubmissions(DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetReportsResubmissions(beginDate.ToString(), endDate.ToString(), false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<usp_select_Reports_ResubmissionsByServiceResult> GetReportsResubmissionsByService(string application, string serviceName, DateTime beginDate, DateTime endDate)
        {
            var dataContext = GetDataContext();
            return dataContext.GetReportsResubmissionsByService(application, serviceName, beginDate, endDate, false).ToList();
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public void SaveUserSettings(UserSetting userSetting)
        {
            var dataContext = GetDataContext();
            dataContext.InsertUserSetting(userSetting.UserName, userSetting.SettingName, userSetting.SettingValue);
        }

        [OperationBehavior(Impersonation = ImpersonationOption.Required)]
        public List<UserSetting> GetUserSettings(string username)
        {
            if(string.IsNullOrEmpty(username))
            {
                throw new ArgumentNullException("username");
            }
            var dataContext = GetDataContext();            
            var result = from u in dataContext.UserSettings
                         where u.UserName == username
                         select u;
            return result.ToList();
        }

        #endregion

		private ExceptionDataContext GetDataContext()
		{
			if (dataContextInstance == null)
			{
				string defaultConnectionString = ConfigurationManager.ConnectionStrings["EsbExceptionDbConnectionString"].ConnectionString;
				dataContextInstance = new ExceptionDataContext(defaultConnectionString);
			}

			return dataContextInstance;
		}
    }
}
