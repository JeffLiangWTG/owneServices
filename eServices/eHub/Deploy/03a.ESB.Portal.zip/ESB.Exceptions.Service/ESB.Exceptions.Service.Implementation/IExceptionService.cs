﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;

namespace ESB.Exceptions.Service.Implementation
{
    [ServiceContract]
    public interface IExceptionService
    {
        [OperationContract]
        [WebGet(BodyStyle = WebMessageBodyStyle.Bare)]
        List<usp_select_AlertHistoryResult> GetAlertHistory(int rowNumber);

        [OperationContract]
        [WebGet(BodyStyle = WebMessageBodyStyle.Bare)]
        List<AlertHistory> GetAlertHistoryByName(string alertName);

        [OperationContract]
        [WebGet(BodyStyle = WebMessageBodyStyle.Bare)]
        Alert GetAlertById(Guid alertId);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void DeleteAlertById(Guid alertId);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void InsertAlert(Alert alert);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void InsertAlertCondition(AlertCondition alertCondition);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void DeleteAlertConditionById(Guid alertConditionId);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void InsertAlertSubscription(AlertSubscription alertSubscription);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void InsertAuditLog(AuditLog auditLog);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void UpdateAlertSubscription(AlertSubscription alertSubscription);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void UpdateAlert(Alert alert);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void UpdateAlertCondition(AlertCondition alertCondition);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void InsertConfiguration(List<ConfigurationItem> configuration);

        [OperationContract]
        [WebGet]
        Dictionary<string, ConfigurationItem> GetConfiguration();

        [OperationContract]
        [WebGet]
        ConfigurationItem GetConfigurationByName(string name);

        [OperationContract]
        [WebGet]
        List<Fault> GetFaults(Guid faultID, string application, DateTime startDate, DateTime endDate, string faultCode, string failureCategory, string errorType, int maxFaultSeverity);

        [OperationContract]
        [WebGet]
        List<usp_select_MessagesResult> GetMessages(string faultID, string messageID);

        [OperationContract]
        [WebGet]
        List<usp_select_Faults_By_Application_And_ServicesResult> GetFaultsByApplicationAndService(string application, string serviceName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Wrapped)]
        void InsertMessage(string messageID, bool resubmitAttemped, bool resubmitSuccessful);

        [OperationContract]
        [WebGet]
        List<usp_select_ContextPropertiesResult> GetContextProperties(Guid messageID);

        [OperationContract]
        [WebGet]
        List<usp_select_Reports_ResubmissionsByServiceResult> GetReportsResubmissionsByService(string application, string serviceName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_Reports_ResubmissionsResult> GetReportsResubmissions(DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        Fault GetFault(Guid faultID);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void DeleteAlertSubscriptionById(Guid alertSubscriptionId);

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Bare)]
        void SaveUserSettings(UserSetting userSetting);

        [OperationContract]
        [WebGet]
        List<UserSetting> GetUserSettings(string username);

        [OperationContract]
        [WebGet]
        List<ErrorFault> GetFaultCountByErrorType(DateTime startDate, DateTime endDate, string application);

        [OperationContract]
        [WebGet]
        List<AlertSubscription> GetAlertSubscriptionsByAlertId(Guid alertId);

        [OperationContract]
        [WebGet]
        List<AlertCondition> GetAlertConditionsByAlertId(Guid alertId);

        [OperationContract]
        [WebGet]
        List<ErrorFault> GetFaultCountByApplication(string applicationName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<ErrorFault> GetFaultCountByErrorTypeByApplication(string errorType, string applicationName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        AlertSubscription GetAlertSubscriptionById(Guid alertSubscriptionId);

        [OperationContract]
        [WebGet]
        List<AlertSubscription> GetAlertSubscriptionsBySubscriber(string subscriber);

        [OperationContract]
        [WebGet]
        List<usp_select_AuditLogResult> GetAuditLog(string actionName, string messageId, string faultId, string auditUserName, DateTime startDate, DateTime endDate, string application);

        [OperationContract]
        [WebGet]
        List<usp_select_AlertHistoryReportByApplication_Over_TimeResult> GetAlertHistoryReportByApplicationOverTime(string applicationName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_AlertHistoryReportByApplicationResult> GetAlertHistoryReportByApplication(string applicationName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_AlertHistoryReportByServiceFaultResult> GetAlertHistoryReportByServiceFault(string applicationName, string serviceName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_AlertHistoryReportByServiceResult> GetAlertHistoryReportByService(string applicationName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_AlertsResult> GetAlerts();

        [OperationContract]
        [WebGet]
        List<usp_select_AlertStatisticsResult> GetAlertStatistics();

        [OperationContract]
        [WebGet]
        List<usp_select_AlertSubscription_Count_Over_Time_By_Application_ServiceNameResult> GetAlertSubscriptionCountOverTimeByApplicationServiceName(string applicationName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_AlertSubscription_Count_Over_Time_By_ApplicationResult> GetAlertSubscriptionCountOverTimeByApplication(string applicationName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_Fault_Count_By_Application_GroupByServicesResult> GetFaultCountByApplicationGroupByServices(string applicationName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_Fault_Count_Over_Time_By_ErrorTypeResult> GetFaultCountOverTimeByErrorType(string errorType, DateTime beginDate, DateTime endDate, string applicationName);

        [OperationContract]
        [WebGet]
        List<usp_select_Fault_Count_Over_Time_By_ApplicationResult> GetFaultCountOverTimeByApplication(string applicationName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_Fault_Count_Over_Time_By_Application_ServiceNameResult> GetFaultCountOverTimeByApplicationServiceName(string applicationName, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_Resubmission_Count_Over_Time_By_Application_ServiceNameResult> GetResubmissionCountOverTimeByApplicationServiceName(string application, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_Resubmission_Count_Over_Time_By_ApplicationResult> GetResubmissionCountOverTimeByApplication(string application, DateTime beginDate, DateTime endDate);

        [OperationContract]
        [WebGet]
        List<usp_select_Faults_By_Application_And_ErrorTypeResult> GetFaultsByApplicationAndErrorType(string application, string errorType, DateTime beginDate, DateTime endDate);
    }

    [DataContract]
    public class ErrorFault
    {
        [DataMember]
        public int ErrorCount { get; set; }
        [DataMember]
        public string ErrorType { get; set; }
        [DataMember]
        public string Application { get; set; }
    }
}