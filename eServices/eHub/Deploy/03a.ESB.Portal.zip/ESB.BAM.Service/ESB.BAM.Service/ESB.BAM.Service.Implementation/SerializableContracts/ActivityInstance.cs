﻿using System;
using System.Xml;
using System.Xml.Serialization;

namespace ESB.BAM.Service.Implementation.SerializableContracts
{
    [XmlRoot("ActivityInstance", Namespace = "http://ESB.BAM.Service.Implementation.SerializableContracts")]
    public class ActivityInstance
    {
        [XmlAttribute("ActivityId")]
        public string ActivityId { get; set; }

        [XmlAttribute("ActivityUri")]
        public string ActivityUri { get; set; }

        [XmlElement("ActivityContent")]
        public XmlDocument ActivityContent { get; set; }
    }
}