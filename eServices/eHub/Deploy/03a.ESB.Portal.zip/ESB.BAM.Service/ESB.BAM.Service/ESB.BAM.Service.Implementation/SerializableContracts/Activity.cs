﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace ESB.BAM.Service.Implementation.SerializableContracts
{
    [XmlRoot("Activity", Namespace = "http://ESB.BAM.Service.Implementation.SerializableContracts")]
    public class Activity
    {
        [XmlAttribute("ActivityName")]
        public string ActivityName { get; set; }

        [XmlAttribute("ActivityDefinition")]
        public string ActivityDefinition { get; set; }

        [XmlAttribute("ActivityUri")]
        public string ActivityUri { get; set; }
    }
}