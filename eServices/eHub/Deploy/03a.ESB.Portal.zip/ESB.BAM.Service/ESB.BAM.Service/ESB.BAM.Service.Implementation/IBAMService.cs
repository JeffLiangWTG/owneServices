﻿using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Web;
using ESB.BAM.Service.Implementation.DAL;
using ESB.BAM.Service.Implementation.SerializableContracts;

namespace ESB.BAM.Service.Implementation
{
    [ServiceContract]
    [XmlSerializerFormat]
    public interface IBAMService
    {
        [OperationContract]
        [WebGet(UriTemplate = "/activities", BodyStyle = WebMessageBodyStyle.Bare)]
        List<Activity> GetActivities();

        [OperationContract]
        [WebGet(UriTemplate = "/activities/{activityName}/{instanceId}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<ActivityInstance> GetActivityInstances(string activityName, string instanceId);

        [OperationContract]
        [WebGet(UriTemplate = "/itineraries/{serviceUuid}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<Itinerary> GetItinerariesByServiceUuid(string serviceUuid);

		[OperationContract]
		[WebGet(UriTemplate = "/itinerary/{itineraryUuid}", BodyStyle = WebMessageBodyStyle.Bare)]
		List<Itinerary> GetItinerariesByItineraryUuid(string itineraryUuid);

        [OperationContract]
        [WebGet(UriTemplate = "/itineraries", BodyStyle = WebMessageBodyStyle.Bare)]
        List<Itinerary> GetItineraries();
    }
}
