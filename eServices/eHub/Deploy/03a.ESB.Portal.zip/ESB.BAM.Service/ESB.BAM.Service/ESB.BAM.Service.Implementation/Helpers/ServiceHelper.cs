﻿using System.ServiceModel;
using System.Xml;
using System.Data;
using ESB.BAM.Service.Implementation.Properties;

namespace ESB.BAM.Service.Implementation.Helpers
{
    public static class ServiceHelper
    {
        public static string GetActivityUri(string activityName)
        {
            string baseAddress = OperationContext.Current.Host.BaseAddresses[0].ToString();
            return string.Concat(baseAddress, "/activities/", activityName, "/_all_");
        }

        public static string GetInstanceUri(string activityName, string activityId)
        {
            string baseAddress = OperationContext.Current.Host.BaseAddresses[0].ToString();
            return string.Concat(baseAddress, "/activities/", activityName, "/", activityId);
        }

        public static XmlDocument SerializeActivityInstance(IDataReader reader)
        {
            XmlDocument activityContent = new XmlDocument();
            activityContent.LoadXml(Resources.ActivityRoot);
            for (int index = 1; index <= reader.FieldCount - 1; index++)
            {
                XmlElement element = activityContent.CreateElement(reader.GetName(index).Replace("$", ""), null);
                element.InnerText = reader.GetValue(index).ToString();
                activityContent.DocumentElement.AppendChild(element);
            }
            return activityContent;
        }
    }
}
