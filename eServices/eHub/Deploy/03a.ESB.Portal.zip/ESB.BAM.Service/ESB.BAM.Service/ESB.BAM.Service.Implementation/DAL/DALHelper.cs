﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ESB.BAM.Service.Implementation.SerializableContracts;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data.SqlClient;
using ESB.BAM.Service.Implementation.Properties;
using System.Data;
using ESB.BAM.Service.Implementation.Helpers;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;

namespace ESB.BAM.Service.Implementation.DAL
{
    public static class DALHelper
    {
        public static List<Activity> GetBAMActivities()
        {            
            IConfigurationSource system = new SystemConfigurationSource();
            DatabaseProviderFactory dbFactory = new DatabaseProviderFactory(system);

            Database db = dbFactory.CreateDefault();
            
            SqlCommand command = new SqlCommand();
            command.CommandText = Resources.GetActivities;

            List<Activity> activities = new List<Activity>();

            using (IDataReader reader = db.ExecuteReader(command))
            {
                while (reader.Read())
                {
                    Activity activity = new Activity();
                    activity.ActivityName = reader.GetString(0);
                    activity.ActivityDefinition = reader.GetString(1);
                    activity.ActivityUri = ServiceHelper.GetActivityUri(activity.ActivityName);
                    activities.Add(activity);
                }
            }

            return activities;
        }

        public static List<ActivityInstance> GetBAMActivityInstances(string activityName, string activityId)
        {
            Database db = DatabaseFactory.CreateDatabase();

            SqlCommand command = new SqlCommand();
            command.CommandText = string.Format(Resources.GetInstances, activityName);

            if (!string.IsNullOrEmpty(activityId) && activityId.Equals(Resources.AllKeyWord))
            {
                command.CommandText += string.Format(Resources.GetInstancesWhereCondition, activityId);
            }

            SqlDataReader reader = command.ExecuteReader();
            List<ActivityInstance> instances = new List<ActivityInstance>();
            while (reader.Read())
            {
                ActivityInstance instance = new ActivityInstance();
                instance.ActivityId = reader.GetString(1);
                instance.ActivityUri = ServiceHelper.GetInstanceUri(activityName, activityId);
                instance.ActivityContent = ServiceHelper.SerializeActivityInstance(reader);
                instances.Add(instance);
            }
            return instances;
        }
    }
}
