﻿using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using ESB.BAM.Service.Implementation.DAL;
using ESB.BAM.Service.Implementation.SerializableContracts;
using Microsoft.Practices.EnterpriseLibrary.Data.Configuration;

namespace ESB.BAM.Service.Implementation
{
    public class BAMService : IBAMService
    {
        #region IBAMService Members

        [System.ServiceModel.OperationBehavior(Impersonation = System.ServiceModel.ImpersonationOption.Required)]
        public List<Activity> GetActivities()
        {
            return DALHelper.GetBAMActivities();
        }

        [System.ServiceModel.OperationBehavior(Impersonation = System.ServiceModel.ImpersonationOption.Required)]
        public List<ActivityInstance> GetActivityInstances(string activityName, string instanceId)
        {
            return DALHelper.GetBAMActivityInstances(activityName, instanceId);
        }

        [System.ServiceModel.OperationBehavior(Impersonation = System.ServiceModel.ImpersonationOption.Required)]
        public List<Itinerary> GetItinerariesByServiceUuid(string serviceUuid)
        {
            ItineraryDataContext ctx = GetItineraryDataContext();
            var result = from itinerary in ctx.Itineraries
                         where itinerary.Serviceuuid.Equals(serviceUuid)
                         select itinerary;

            return result == null ? new List<Itinerary>() : result.ToList<Itinerary>();
        }

		[System.ServiceModel.OperationBehavior(Impersonation = System.ServiceModel.ImpersonationOption.Required)]
		public List<Itinerary> GetItinerariesByItineraryUuid(string itineraryUuid)
		{
			ItineraryDataContext ctx = GetItineraryDataContext();
			var result = from itinerary in ctx.Itineraries
						 where itinerary.Itineraryuuid.Equals(itineraryUuid)
						 select itinerary;

			return result == null ? new List<Itinerary>() : result.ToList<Itinerary>();
		}

        [System.ServiceModel.OperationBehavior(Impersonation = System.ServiceModel.ImpersonationOption.Required)]
        public List<Itinerary> GetItineraries()
        {
            ItineraryDataContext ctx = GetItineraryDataContext();
            var result = from itinerary in ctx.Itineraries
                         select itinerary;

            return result == null ? new List<Itinerary>() : result.ToList<Itinerary>();
        }

        #endregion

        private ItineraryDataContext GetItineraryDataContext()
        {
            DatabaseSettings dbSettings = ConfigurationManager.GetSection("dataConfiguration") as DatabaseSettings;
            string defaultConnectionString = ConfigurationManager.ConnectionStrings[dbSettings.DefaultDatabase].ConnectionString;

            return new ItineraryDataContext(defaultConnectionString);
        }
    }
}
