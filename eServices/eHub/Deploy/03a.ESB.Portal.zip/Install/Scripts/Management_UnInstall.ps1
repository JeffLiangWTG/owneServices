﻿$websiteName =  $Args[0]

$relativePath = "..\.."
. .\ESBFunctions.ps1

StopAppPool EsbPortalNetworkAppPool

DeleteVirtualDirectory $websiteName ESB.BAM.Service
DeleteVirtualDirectory $websiteName ESB.Exceptions.Service  
DeleteVirtualDirectory $websiteName ESB.Portal

DeleteAppPool "EsbPortalNetworkAppPool"
