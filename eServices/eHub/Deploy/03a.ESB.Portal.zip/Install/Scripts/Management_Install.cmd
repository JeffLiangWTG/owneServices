powershell .\Management_Install.ps1 1
pause