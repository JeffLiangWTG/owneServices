powershell .\Management_UnInstall.ps1 1
pause