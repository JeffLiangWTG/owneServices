﻿
$websiteName =  $Args[0]
$authFlagsIntegrated = 4

. .\ESBFunctions.ps1

$currentPath = Get-Location
$servicesPath = Split-Path  -Parent $currentPath
$servicesPath = Split-Path  -Parent $servicesPath 

CreateAppPool "EsbPortalNetworkAppPool" "Network Service" "" 2

CreateVirtualDirectory $websiteName ESB.BAM.Service $servicesPath"\ESB.BAM.Service\ESB.BAM.Service\ESB.BAM.Service" "EsbPortalNetworkAppPool" $authFlagsIntegrated
CreateVirtualDirectory $websiteName ESB.Exceptions.Service $servicesPath"\ESB.Exceptions.Service\ESB.Exceptions.Service" "EsbPortalNetworkAppPool" $authFlagsIntegrated
CreateVirtualDirectory $websiteName ESB.Portal $servicesPath"\ESB.Portal" "EsbPortalNetworkAppPool" $authFlagsIntegrated