﻿if((test-path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\MSBuild") -eq $True)
{
	 Write-Output "64 bit Machine"
 
	$BizTalkPath = (Get-ItemProperty  "hklm:SOFTWARE\Wow6432Node\Microsoft\Biztalk Server\3.0\").InstallPath
	$BizTalkPathTracking = $BizTalkPath+"Tracking"
	[System.Reflection.Assembly]::LoadFrom($BizTalkPath +"Developer Tools\Microsoft.BizTalk.ExplorerOM.dll") | Out-Null
	$DevEnvPath=(Get-ItemProperty  "hklm:SOFTWARE\Wow6432Node\Microsoft\VisualStudio\").InstallDir
	$FrameworkPath=(Get-ItemProperty  "hklm:SOFTWARE\Wow6432Node\Microsoft\.NETFramework\").InstallRoot
	$SdkKeyName="sdkInstallRootv2.0"
	$SDKPath=(Get-ItemProperty  "hklm:SOFTWARE\Wow6432Node\Microsoft\.NETFramework\").$SdkKeyName
	
	if ($SDKPath -eq $null)
	{
	$SDKPath=(Get-ItemProperty  "hklm:SOFTWARE\Wow6432Node\Microsoft\Microsoft SDKs\Windows\v6.0A").InstallationFolder
	}
	
		if((Test-Path "hklm:\SOFTWARE\Wow6432Node\Microsoft\BizTalk ESB Toolkit\2.0\") -eq $True)
	
{
	$installPath = (Get-ItemProperty "hklm:\SOFTWARE\Wow6432Node\Microsoft\BizTalk ESB Toolkit\2.0\").InstallPath
	Write-Output "Using registry install path: " $installPath
	
	if ($installPath -ne $null)
	{
		if ((Test-Path $installPath) -eq $True)
		{
			Write-Output "Install path found with value: " $installPath
			$rulesDeployerPath = $installPath+"bin"
			Write-Output "RulesDeployer Path" $rulesDeployerPath
		}
		else	
		{
			Write-Output "Install path found in registry but not on file system with value: " $installPath
		}
	}
	else
	{
		Write-Output "ESB registry path found, but install path entry not found."
	}
}
else
{
	Write-Output "Registry for Installed ESB Guidance not found."
}
	
}

else
{
	Write-Output "32 bit Machine"
	$BizTalkPath = (Get-ItemProperty  "hklm:SOFTWARE\Microsoft\Biztalk Server\3.0\").InstallPath
	$BizTalkPathTracking = $BizTalkPath+"Tracking"
	[System.Reflection.Assembly]::LoadFrom($BizTalkPath +"Developer Tools\Microsoft.BizTalk.ExplorerOM.dll") | Out-Null
	$DevEnvPath=(Get-ItemProperty  "hklm:SOFTWARE\Microsoft\VisualStudio\").InstallDir
	$FrameworkPath=(Get-ItemProperty  "hklm:SOFTWARE\Microsoft\.NETFramework\").InstallRoot
	$SdkKeyName="sdkInstallRootv2.0"
	$SDKPath=(Get-ItemProperty  "hklm:SOFTWARE\Microsoft\.NETFramework\").$SdkKeyName
	if ($SDKPath -eq $null)
	{
		$SDKPath=(Get-ItemProperty  "hklm:SOFTWARE\Microsoft\Microsoft SDKs\Windows\v6.0A").InstallationFolder
	}
	
	
	if((Test-Path "hklm:\SOFTWARE\Microsoft\BizTalk ESB Toolkit\2.0\") -eq $True)
	
{
	$installPath = (Get-ItemProperty "hklm:\SOFTWARE\Microsoft\BizTalk ESB Toolkit\2.0\").InstallPath
	if ($installPath -ne $null)
	{
		if ((Test-Path $installPath) -eq $True)
		{
			Write-Output "Install path found with value: " $installPath
			$rulesDeployerPath = $installPath+"bin"
		}
		else	
		{
			Write-Output "Install path found in registry but not on file system with value: " $installPath
		}
	}
	else
	{
		Write-Output "ESB registry path found, but install path entry not found."
	}
}
else
{
	Write-Output "Registry for Installed ESB Guidance not found."
}
	
}

$solutionPath = Get-Location
$solutionPath = Split-Path  -Parent $solutionPath 
$solutionPath = Split-Path  -Parent $solutionPath 
$solutionPath = Split-Path -Parent $solutionPath

if ($solutionPath.EndsWith("\"))
{
	$solutionPath = $solutionPath.Substring(0, $solutionPath.Length - 1) 
}

Write-Output "Solution Path: "$solutionPath


$btsConnectionString = "server=.;database=BizTalkMgmtDb;Integrated Security=SSPI";
if ((Test-Path "hklm:SOFTWARE\Microsoft\Biztalk Server\3.0\Administration") -eq $true)
{
	Write-Output "Found registry entry for BizTalk Management DB."
	$btsDBServer =  (Get-ItemProperty "hklm:SOFTWARE\Microsoft\Biztalk Server\3.0\Administration").MgmtDBServer
	$btsMgmtDB =  (Get-ItemProperty "hklm:SOFTWARE\Microsoft\Biztalk Server\3.0\Administration").MgmtDBName
	$btsConnectionString = "server="+$btsDBServer+";database="+$btsMgmtDB+";Integrated Security=SSPI"
}

Write-Output "BizTalk connection string is " $btsConnectionString


[System.Reflection.Assembly]::Load("Microsoft.SqlServer.Smo, Version=10.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91") | Out-Null
[System.Reflection.Assembly]::Load("Microsoft.SqlServer.SqlEnum, Version=10.0.0.0, Culture=neutral, PublicKeyToken=89845dcd8080cc91") | Out-Null
function DatabaseExists

{
    param([System.String] $serverInstance, [System.String] $databaseName)
    $server = new-object Microsoft.SqlServer.Management.Smo.Server($serverInstance)
    foreach ($d in $server.Databases)
    {
        if ($d.Name.Equals($databaseName, [System.StringComparison]::InvariantCultureIgnoreCase))
        {
            return $true
        }
    }
    return $false
}



function VirtualDirectoryExists
{
	param([string] $webSiteName, [string] $vDirName)
	
	$vDirPath = "IIS://localhost/W3SVC/" + $webSiteName +"/Root/" + $vDirName	
	$vDir = [adsi]$vDirPath
	
	if($vDir.Name -eq $null)
	{
		return $false
	}
	else
	{
		return $true
	}
}

function CreateVirtualDirectory
{
	param([string] $webSiteName = "", [string]$vDirName = "", [string]$path = "", [string] $appPool = "", [int]$authFlags)
	
	if($webSiteName.length -ceq 0)
	{
		Write-Output("Must specify a Web Site name")
		exit
	}
	
	if($vDirName.length -ceq 0)
	{
		Write-Output("Must specify a Virtual Directory name")
		exit
	}
	
	if($path.length -ceq 0)
	{
		Write-Output("Must specify a path name")
		exit
	}
	
	$dirExists = [System.IO.Directory]::Exists($path)
	
	if(!$dirExists)
	{
		Write-Output("Must specify an existing path")
		Write-Output($path)
		exit
	}
	
	if(VirtualDirectoryExists -webSiteName $webSiteName -vDirName $vDirName)
	{
		return
	}
	
	$adsiPath = "IIS://localhost/W3SVC/" + $webSiteName + "/Root"	
	$iisMgr = [adsi]$adsiPath
	$V1 = $iisMgr.psbase.children.add($vDirName, $iisMgr.psbase.SchemaClassName)
	$iisMgr.psbase.CommitChanges()
	$V1.psbase.Invoke("AppCreate", $true)
	$V1.psbase.CommitChanges()
	$V1.put("AppFriendlyName", $vDirName)
	$V1.psbase.CommitChanges()
	$V1.put("Path", $path)
	$V1.psbase.CommitChanges()
	$V1.put("AccessRead", $true)
	$V1.psbase.CommitChanges()
	$V1.put("AccessWrite", $false)
	$V1.psbase.CommitChanges()
	$V1.put("AccessExecute", $true)
	$V1.psbase.CommitChanges()
	$V1.put("AccessScript", $true)
	$V1.psbase.CommitChanges()
	
	if($authFlags -ne 1)
	{
		$V1.put("AuthFlags", $authFlags)
		$V1.psbase.CommitChanges()
	}
	
	Write-Output "The Virtual Directory "$vDirName" has been successfully created."
	
	AssignAppPool $webSiteName $vDirName $appPool
}

function GetWindowsVersion
{
	param()
	
	$strComputer = "."

	$colItems = get-wmiobject -class "Win32_OperatingSystem" -namespace "root\CIMV2" -computername $strComputer
	
	foreach ($objItem in $colItems) {
		return $objItem.Version
	}
}

function CreateAppPool
{
	param([System.String] $appPoolName, [System.String] $appPoolSvcAccount, [System.String] $appPoolSvcAccountPwd, [System.Int16] $identityType)
	
	$adsiPath = "IIS://localhost/W3SVC/AppPools/" + $appPoolName
	$app = [adsi]$adsiPath
	
	if($app.Name -eq $null)
	{
		$appPool = [adsi]"IIS://localhost/W3SVC/AppPools"
		$newApp = $appPool.Create("IISApplicationPool", $appPoolName)
		$newApp.AppPoolIdentityType = $identityType
		
		if($identityType -eq 3)
		{
			$newApp.WAMUserName = $appPoolSvcAccount
			$newApp.WAMUserPass = $appPoolSvcAccountPwd
		}
		
		# ManagedPipeLineMode = 0 Integrated Security | 1 Classic (this is the default one)
		$version = GetWindowsVersion
		if ($version.ToString().StartsWith("6.0"))
		{
			$newApp.ManagedPipelineMode = 0
		}		
		
		# If 64bit processor then enable 32bit applications for ESB.BizTalkOperationsService
		if($appPoolName -eq "ESB.BizTalkOperationsService" -and [IntPtr]::Size -eq 8)
		{
			$newApp.Enable32BitAppOnWin64 = $true;
		}
		
		$newApp.SetInfo()
		
		Write-Output "The Application Pool "$appPoolName" has been successfully created."
	}
}

function AssignAppPool
{
	param([string] $webSiteName = "",[System.String] $vDirName, [System.String] $appPoolName)
	
	$vDirPath = "IIS://localhost/W3SVC/" + $webSiteName + "/Root/" + $vDirName	
	$vDir = [adsi]$vDirPath
	
	$vDir.AppPoolId = $appPoolName
   	$vDir.SetInfo()
   	
   	Write-Output "The application pool "$appPoolName" has been assigned"
}

function CreateDatabase
{
	param ([string] $name)
	
	$script = "create database "+$name
	Write-Output $script
	sqlcmd -Q $script

}

function RunDatabaseScript
{
	param([string] $script)
	
	Write-Output "Running requested script "+$script
	
	sqlcmd -i $script

}

function StopBTSServices
{
	Write-Output "Stopping BizTalk Services"
	Stop-Service -DisplayName "BizTalk Service*"	
}

function StartBTSServices
{
	Write-Output "Starting BizTalk Services"
	Start-Service -DisplayName "BizTalk Service*"	
}

function Get-ScriptDirectory
{
	$Invocation = (Get-Variable MyInvocation -Scope 1).Value
	Split-Path $Invocation.MyCommand.Path
}

function script:StopAppPool
{
	param([System.String] $appPoolName)
	
	$adsiPath = "IIS://localhost/W3SVC/AppPools/" + $appPoolName
	$app = [adsi]$adsiPath
	
	if($app -ne $null)
	{		
		$app.Stop()
		Write-Output "The Application Pool "$appPoolName" has been successfully stopped."
	}
	else
	{
		Write-Output "App Pool "$app.Name" was not found."
	}
}

function StartAppPool
{
	param([System.String] $appPoolName)
	
	$adsiPath = "IIS://localhost/W3SVC/AppPools/" + $appPoolName
	$app = [adsi]$adsiPath
	
	if($app -ne $null)
	{		
		$app.Start()
		Write-Output "The Application Pool "$appPoolName" has been successfully started."
	}
	else
	{
		Write-Output "App Pool "$app.Name" was not found."
	}
}

function StartBTSApplication
{ 
	param([string]$appName)
	trap { Write-Output "Error" }

	$exp = New-Object Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer
	$exp.ConnectionString = $btsConnectionString
	$app = $exp.Applications[$appName]
	
	if($app -eq $null)
	{
		Write-Host "Application " $appName " not found" -fore Red
	}
	else
	{
		
		if($app.Status -ne 1)
		{		
			#full start of application
			$null = $app.Start(63)
			$null = $exp.SaveChanges()
			Write-Host "Started application: " $appName
		}
	}
}

function CreateBTSApplication
{ 
	param([string]$appName)
	
	
	
	$exp = New-Object Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer
	$exp.ConnectionString = $btsConnectionString
	$app = $exp.Applications[$appName]
	
	if($app -eq $null)
	{
		Write-Output "Creating BizTalk Application "$appName  
		BTSTask.exe AddApp /A:$appName 
	}
	else
	{
		Write-Host "Application " $appName " exists"
	
	}
}

function BAMActivityOperation
{
	param([System.String]$command, [System.String]$fileName, [System.String]$loc)
	
	$definitionFile = "-DefinitionFile:"+$loc+$fileName
	Write-Output "Performing "$command" on "$definitionFile
	
	$execute = $BizTalkPathTracking+"\bm.exe"
	&$execute $command $definitionFile
	
}

function ImportBinding
{
	param([string]$appName, [string]$bindingFilePath)

	BTSTask.exe ImportBindings  /A:$appName /So:$bindingFilePath
}

function AddPipeLineComponents
{
	param([string]$appName,[string]$source, [string]$assemblyName)

	$destination = "%PROGRAMFILES%\Microsoft BizTalk Server 2009\Pipeline Components\" + $assemblyName
		
	BTSTask.exe AddResource /ApplicationName:$appName /Type:System.BizTalk:Assembly /Overwrite /Source:$source /Destination:"$destination"
}


function AddVirtualDirectory
{
	param([string]$appName,[string]$virtualDirectory)
	#BTSTask AddResource /ApplicationName:MyApplication /Type:System.BizTalk:WebDirectory/Overwrite /Source:http://Host1:90/MyVirtualDirectory /Destination:http://Host2:90/MyVirtualDirectory /Server:MyDatabaseServer /Database:BizTalkMgmtDb
	BTSTask AddResource /ApplicationName:$appName /Type:System.BizTalk:WebDirectory /Overwrite /Source:$virtualDirectory /Destination:$virtualDirectory /Server:. /Database:BizTalkMgmtDb
}

function AddProcessingScript
{
	param([string] $appName, [string] $scriptName)
	
	BTSTask AddResource /ApplicationName:$appName /Type:System.BizTalk:PostProcessingScript  /Overwrite /Source:$scriptName
}

function ImportBTSResource
{
	param([string]$appName, [string]$resType, [string]$srcPath)
	$gacOptions="/Options:GacOnAdd,GacOnInstall,GacOnImport"
	BTSTask.exe AddResource /Source:$srcPath /ApplicationName:$appName /Type:$resType /Overwrite $gacOptions
}


function ExportCurrentBindings
{
	param([string]$appName,[string]$source)
	#BTSTask ExportBindings /Destination:"..\install\Binding\Microsoft.Practices.ESB.CORE_Bindings.xml" /ApplicationName:Microsoft.Practices.ESB 
	BTSTask ExportBindings /Destination:$source /ApplicationName:$appName 
}

function AddBinding
{
	param([string]$appName,[string]$source)
	#BTSTask AddResource /ApplicationName:Microsoft.Practices.ESB /Type:System.BizTalk:BizTalkBinding  /Overwrite /Source:"..\install\Binding\Microsoft.Practices.ESB.CORE_Bindings.xml" /Property:TargetEnvironment="DEV_CORE"
	BTSTask AddResource /ApplicationName:$appName /Type:System.BizTalk:BizTalkBinding  /Overwrite /Source:$source /Property:TargetEnvironment="DEV_CORE"
}

function RemoveBinding
{
	param([string]$appName,[string]$source)
	#BTSTask AddResource /ApplicationName:Microsoft.Practices.ESB /Type:System.BizTalk:BizTalkBinding  /Overwrite /Source:"..\install\Binding\Microsoft.Practices.ESB.CORE_Bindings.xml" /Property:TargetEnvironment="DEV_CORE"
	BTSTask RemoveResource /ApplicationName:$appName /Type:System.BizTalk:BizTalkBinding  /Overwrite /Source:$source /Property:TargetEnvironment="DEV_CORE"
}

function DeleteReceivePort
{ 
	param([string]$recPortName)
	trap { Write-Output "Error" }

	$exp = New-Object Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer
	$exp.ConnectionString = $btsConnectionString
	$port = $exp.ReceivePorts[$recPortName]
	
	if($port -eq $null)
	{
		Write-Host "Receive Port " $recPortName " not found" -fore Red
	}
	else
	{
		$exp.RemoveReceivePort($port)
		$null = $exp.SaveChanges()
		Write-Host "Deleted ReceivePort: " $recPortName
	}
}

function DeleteAssembly
{ 
	param([string]$assemblyName)
	trap { Write-Output "Error" }

	$exp = New-Object Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer
	$exp.ConnectionString = $btsConnectionString
	$assembly = $exp.Assemblies[$assemblyName]
	
	if($assembly -eq $null)
	{
		Write-Host "Assembly " $assembly " not found" -fore Red
	}
	else
	{
		$exp.RemoveReceivePort($port)
		$null = $exp.SaveChanges()
		Write-Host "Deleted ReceivePort: " $recPortName
	}
}

function DeleteSendPort
{ 
	param([string]$sndPortName)
	trap { Write-Output "Error" }

	$exp = New-Object Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer
	$exp.ConnectionString = $btsConnectionString
	$port = $exp.SendPorts[$sndPortName]
	
	if($port -eq $null)
	{
		Write-Host "Send Port " $sndPortName " not found" -fore Red
	}
	else
	{
		$exp.RemoveSendPort($port)
		$null = $exp.SaveChanges()
		Write-Host "Deleted SendPort: " $sndPortName
	}
}


function GenerateArtifactsListWithBinding
{
	param([string]$appName,[string]$source)
	#BTSTask ListApp /ApplicationName:Microsoft.Practices.ESB /ResourceSpec:"..\Install\Microsoft.Practices.ESB.CORE_Artifacts.xml"
	BTSTask ListApp /ApplicationName:$appName /ResourceSpec:$source
	
	RemoveNodesFromArtifactList $source "System.BizTalk:WebDirectory"
}



function GenerateArtifactsListWithOutBinding
{
	param([string]$appName,[string]$source)
	BTSTask ListApp /ApplicationName:$appName /ResourceSpec:$source
	
	#Remove 
	RemoveNodesFromArtifactList $source "System.BizTalk:WebDirectory"
	RemoveNodesFromArtifactList $source "System.BizTalk:BizTalkBinding"
	
}

function RemoveNodesFromArtifactList
{
	param([string]$source, [string] $type)
	
	$doc = New-Object System.Xml.XmlDocument
    $doc.Load($source)   
	#Write-Output "Document loaded"
	$results = $doc.SelectNodes("//*[local-name()='Resource'][@Type="""+$type+"""]")
    $parentNode = $doc.SelectSingleNode("//*[local-name()='Resources']")
	foreach ($node in $results)
    {
		#Write-Output "Found node"		
		if ($parentNode -ne $null)
		{
			#Write-Output "Parent node is not null"
			$parentNode.RemoveChild($node)
		}
		else		
		{
			#Write-Output "Parent node is null"
		}
		
		#Write-Output $node
    	
    }
    $doc.Save($source);
}


function GenerateMSIWithBinding
{
	param([string]$appName,[string]$msiLocation,[string]$bindingFilePath)
	BTSTask ExportApp /ApplicationName:$appName /Package:$msiLocation /ResourceSpec:$bindingFilePath
}

function GenerateMSIWithOutBinding
{
	param([string]$appName,[string]$msiLocation,[string]$bindingFilePath)
	BTSTask ExportApp /ApplicationName:$appName /Package:$msiLocation /ResourceSpec:$bindingFilePath
}

function GenerateMSI
{
	param([string]$appName,[string]$msiLocation,[string]$bindingFilePath)
	BTSTask ExportApp /ApplicationName:$appName /Package:$msiLocation /ResourceSpec:$bindingFilePath
}

function RemoveDatabase
{
	param ([string] $name)
	
	$script = "drop database "+$name
	Write-Output $script
	sqlcmd -Q $script

}

function GacOperation
{
	param([System.String]$command, [System.String]$assembly)
	$execute = $SDKPath+"bin\gacutil.exe"
	&$execute $command $assembly
}

function RunInstallUtil
{
	param([string] $assembly)
	$execute = $FrameworkPath+"\v2.0.50727\InstallUtil.exe"
	&$execute $assembly 
}

function DeleteAppPool
{
	param([System.String] $appPoolName)
	
	$adsiPath = "IIS://localhost/W3SVC/AppPools" 
	$apps = [adsi]$adsiPath	
	
	Write-Output "Deleting app pool "$appPoolName
	
	if($apps -ne $null)
	{				
		$apps.Delete("IISApplicationPool", $appPoolName)
		
		Write-Output "The Application Pool "$appPoolName" has been successfully deleted."
	}	
}

function StopBTSApplication
{ 
	param([string]$appName)

	$exp = New-Object Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer
	$exp.ConnectionString = $btsConnectionString
	$app = $exp.Applications[$appName]
	if($app -eq $null)
	{
		Write-Host "Application " $appName " not found" -fore Red
	}
	else
	{
		if($app.Status -ne 2)
		{
			#full stop of application
			$null = $app.Stop(63)
			$null = $exp.SaveChanges()
			Write-Host "Stopped application: " $appName
		}
	}

}

function RemoveBTSApplication
{ 
	param([string]$appName)

	Write-Output "Removing BTS Application "+ $appName
	BTSTask.exe RemoveApp /A:$appName 
}

function RemoveOrchestration
{ 
	param([string]$appName,[string]$luID)

	Write-Output "Removing Orchestration "+ $luID
	BTSTask RemoveResource /ApplicationName:$appName /Luid:$luID
}

function RemoveResource
{ 
	param([string]$appName,[string]$luID)

	Write-Output "Removing Resource "+ $luID
	BTSTask RemoveResource /ApplicationName:$appName /Luid:$luID
}


function DeleteVirtualDirectory
{
	param([string] $webSiteName, [System.String] $vDirName)

	if(VirtualDirectoryExists -webSiteName $webSiteName -vDirName $vDirName)
	{
		$vDirPath = "IIS://localhost/W3SVC/" + $webSiteName +"/Root"
		$iisMgr = [adsi]$vDirPath
		$found = $iisMgr.psbase.children.find($vDirName, $iisMgr.psbase.SchemaClassName)
		$iisMgr.psbase.children.remove($found)
	}
}

function AddApplicationReference
{ 
	param([string]$appName, [string]$referencedAppName)

	$exp = New-Object Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer
	$exp.ConnectionString = $btsConnectionString
	$app = $exp.Applications[$appName]
	$referenceApp = $exp.Applications[$referencedAppName]
	if($app -eq $null -or $referenceApp -eq $null)
	{
		Write-Host "Application " $appName " or " $referencedAppName "not found" -fore Red
	}
	else
	{
		$app.AddReference($referenceApp);
		$exp.SaveChanges()		
	}

}

#BRE functions
function GetRulesDeployerPath
{
	#because solution path is adjusted for samples, path to rules cannot be determined automatically at top of script
	if ($rulesDeployerPath -ne $null)
	{
		return $rulesDeployerPath
	}
	else
	{
		return $solutionPath+"\Core\Install\BRE"
	}
}

function RemovePolicy
{
	param([string] $ruleNAme)
	
	$path = GetRulesDeployerPath
	&$path\Microsoft.Practices.ESB.RulesDeployer.exe -rp $ruleName 

}

function RemoveVocab
{
	param([string] $vocab)
	
	$path = GetRulesDeployerPath
	&$path\Microsoft.Practices.ESB.RulesDeployer.exe -rv $vocab 

}

function AddPolicy
{
	param([string] $file)
	
	$path = GetRulesDeployerPath
	&$path\Microsoft.Practices.ESB.RulesDeployer.exe -p $file 

}

function AddVocab
{
	param([string] $file)
	
	$path = GetRulesDeployerPath
	&$path\Microsoft.Practices.ESB.RulesDeployer.exe -v $file 

}

function AddPolicyAsResource
{
	param ([string] $appName, [string]$policyName, [string] $version)
	
	BtsTask AddResource /Application:$appName /Name:$policyName /Version:$version /Type:System.BizTalk:Rules 
}
#end BRE functions